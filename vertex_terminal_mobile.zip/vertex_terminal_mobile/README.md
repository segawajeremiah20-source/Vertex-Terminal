# Vertex Terminal (desktop + mobile)

One code base that runs on Windows, macOS, Linux, Android and iOS. Wide screens show the original frame unchanged: same sidebar, pages, colours, stat cards, tables and settings cards. On phones (narrow screens or Android/iOS), that same sidebar turns into a slide-in drawer. You open it with the ☰ button in a slim top bar, and the Android Back button closes it.

```
main.py              the app (entry file must be called main.py for Android)
build_android.py     Android build wrapper (adds requests + cryptography to the APK)
requirements.txt     pip dependencies
app_icon.png/.ico    app icon
tests/test_core.py   23 tests (Solana signing checked byte-for-byte against solders)
```

## Run on desktop

```bash
pip install -r requirements.txt        # or just: pip install PySide6 requests cryptography
python main.py
python -m unittest discover -s tests -v
```

Data (config, encrypted wallet, models, portfolio, logs) is stored in your home folder. On Android it goes in the app's private storage, and on iOS in `Documents/`.

## What was fixed

Crashes and errors
- Removed `solders`, `solana` and `base58`, which have no Android/iOS builds. Transactions are now built and signed natively with `cryptography`. The output is byte-identical to solders, which the tests verify.
- Jupiter v6 (`quote-api.jup.ag/v6`) has been retired ([Chainstack](https://docs.chainstack.com/docs/solana-priority-fees-for-a-jupiter-in-python)). The app now uses the current `lite-api.jup.ag/swap/v1` endpoints ([Jupiter docs](https://developers.jup.ag/docs/swap/v1/get-quote)). If you set an optional API key, it switches to `api.jup.ag`.
- Paper and live exits passed UI token amounts where raw units (decimals) were required, so P&L was wrong by a factor of 10^decimals. Decimals now come from the chain via `getTokenSupply`.
- Network calls ran on the GUI thread and froze the window. All network work, buys and closes now run in workers, and results come back through signals.
- An old or newer `config.json` with unknown keys crashed start-up. Unknown keys are now ignored.
- ML confidence sizing never ran, because the code used `hasattr()` on a dict.
- The ML model needed scikit-learn, which can't be installed on phones. A pure-Python online model now takes over automatically.
- Micro-cap prices printed as `0.00000001`. Values now keep their significant digits.
- `SAVE & ENCRYPT KEY` showed an underscore (Qt mnemonic). Long settings labels clipped on narrow windows.
- "Segoe UI" only exists on Windows. The app now falls back to Roboto, Helvetica Neue or Arial, and the logo shrinks to fit.
- Removed a dead RPC (projectserum). RPC calls now fail over between endpoints, and the rate limiter no longer blocks forever.
- Audit and app logs now rotate instead of growing without limit. Writes are thread-safe and the wallet file is written atomically.
- Live mode is crypto-only. Forex and stock remain paper trading, valued in USD.

Mobile
- Responsive layout: the drawer, a 2×2 stat grid, and phone tables that hide secondary columns. Tap any row to see every field.
- Kinetic touch scrolling, bigger touch targets, labels above fields, and support for rotation and the Back button.
- Portfolio is saved when the app goes to the background and restored on launch. Online/offline detection uses `QNetworkInformation`.

## Build for Android (Linux or macOS host)

Tested here on Ubuntu with PySide6 6.12.0 and produces a ~39 MB arm64 APK. `pyside6-android-deploy` needs a Linux or macOS host, JDK 17+, and the entry file named `main.py` ([Qt for Python docs](https://doc.qt.io/qtforpython-6/deployment/deployment-pyside6-android-deploy.html)). It downloads Android NDK r28c and the SDK by itself on the first run.

```bash
# 1. Host tools (Ubuntu/Debian)
sudo apt install openjdk-17-jdk-headless git zip unzip autoconf automake libtool \
    pkg-config cmake libffi-dev libssl-dev zlib1g-dev
curl https://sh.rustup.rs -sSf | sh -s -- -y -t aarch64-linux-android   # cryptography is Rust
pip install PySide6==6.12.0 buildozer cython jinja2 pkginfo tqdm

# 2. Open-source PySide6 Android wheels (same version as your desktop PySide6).
#    `qtpip` only serves commercial wheels; the LGPL ones are on download.qt.io:
mkdir wheels && cd wheels
curl -LO https://download.qt.io/official_releases/QtForPython/pyside6/pyside6-6.12.0-6.12.0-cp310-abi3-android_aarch64.whl
curl -LO https://download.qt.io/official_releases/QtForPython/shiboken6/shiboken6-6.12.0-6.12.0-cp310-abi3-android_aarch64.whl
cd ..

# 3. Build (first run ~15 min: compiles Python, OpenSSL, cryptography)
python build_android.py \
  --wheel-pyside   wheels/pyside6-6.12.0-6.12.0-cp310-abi3-android_aarch64.whl \
  --wheel-shiboken wheels/shiboken6-6.12.0-6.12.0-cp310-abi3-android_aarch64.whl \
  --name VertexTerminal -f

# 4. Install on a phone (USB debugging on) or copy the .apk over and open it
adb install -r VertexTerminal-0.1-arm64-v8a-debug.apk
```

Use `x86_64` wheels instead of `aarch64` to build for the Android emulator.

What `build_android.py` adds on top of the stock tool:
- **Packages:** `requests`, `openssl` and `cryptography` are added to the APK. The stock tool only includes `python3,shiboken6,PySide6`.
- **Settings:** INTERNET and network-state permissions, the app title and icon, and non-interactive SDK licence acceptance.
- **Size trimming (175 MB → 39 MB):** the stock recipe copies the whole PySide6 wheel (QML, 3D, WebEngine, Multimedia, Designer) and every Qt library twice. The wrapper keeps only the libraries that QtCore, QtGui, QtWidgets and QtNetwork actually link to, found by reading their ELF dependencies. It also copies the Android network-status, image-format and style plugins, which the stock recipe leaves out. Set `VERTEX_NO_TRIM=1` to turn trimming off.
- **charset_normalizer fix:** the build would otherwise install x86-64 desktop binaries for it, and `import requests` would crash on a phone. Those binaries are excluded, so the pure-Python version is used.

The result is a debug-signed APK for sideloading. For Google Play you need a signed release build. After one run, the generated `buildozer.spec` is next to `main.py`: set your keystore via the `P4A_RELEASE_KEYSTORE*` environment variables and run `buildozer android release`.

## If the app crashes or shows a blank screen

The app has a built-in crash reporter. Any Python error, including a failed import at startup, opens an error screen with the full traceback. Tap **Copy** and send the text. Native (Qt/C++) crashes are recorded too and shown the next time you open the app. With USB debugging on, `adb logcat -s python:* Qt:* AndroidRuntime:*` shows the same output live.

## Build for iOS (macOS + Xcode)

Use `pyside6-ios-deploy` (Qt for Python 6.12+) ([Qt for Python docs](https://doc.qt.io/qtforpython-6/deployment/deployment-pyside6-ios-deploy.html)):

```bash
qtpip download PySide6 --ios --arch arm64 --platform device
pyside6-ios-deploy main.py      # then open the generated Xcode project, sign, run
```

`cryptography` must be available as an iOS wheel for LIVE mode. Without it the app runs in paper mode only.

## Honest notes

- Live trading uses real money and carries real risk. Most memecoins go to zero. Use a dedicated hot wallet holding only what you can afford to lose. Nothing here guarantees profit.
- Android and iOS pause or kill apps in the background. Autopilot only runs reliably while the app is in the foreground. For 24/7 trading, run the desktop version on an always-on machine.
- Sentiment is a neutral placeholder (0.0) until you connect a real data source.
- Forex and stocks use Alpha Vantage. The `demo` key only serves a few symbols, and a free key is limited to about 25 requests a day. Enter your own key in Settings → Scanner. Results are cached for an hour.
- Listing Watch is a heuristic based on public data. It is not insider information.
