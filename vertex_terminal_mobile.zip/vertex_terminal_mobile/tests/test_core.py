"""Core tests for Vertex Terminal.

Run from the project folder:
    python -m unittest discover -s tests -v

The Solana byte-level tests compare against `solders` (the reference
implementation) when it is installed; they are skipped otherwise.
"""
import base64
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

# Isolate all app data (config, wallet, models) in a temp HOME
_TMP_HOME = tempfile.mkdtemp(prefix="vertex_test_")
os.environ["HOME"] = _TMP_HOME
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import main as M  # noqa: E402

try:
    from solders.keypair import Keypair
    from solders.pubkey import Pubkey
    from solders.hash import Hash
    from solders.message import Message, MessageV0, to_bytes_versioned
    from solders.transaction import Transaction, VersionedTransaction
    from solders.system_program import transfer, TransferParams
    from solders.instruction import Instruction, AccountMeta
    HAVE_SOLDERS = True
except Exception:  # pragma: no cover
    HAVE_SOLDERS = False


class Base58Tests(unittest.TestCase):
    def test_roundtrip_and_leading_zeros(self):
        for data in [b"", b"\x00", b"\x00\x00\x01", os.urandom(32), os.urandom(64), bytes(32)]:
            self.assertEqual(M.b58decode(M.b58encode(data)), data)
        self.assertEqual(M.b58encode(bytes(32)), "1" * 32)  # System Program id

    def test_invalid_char(self):
        with self.assertRaises(ValueError):
            M.b58decode("0OIl")

    @unittest.skipUnless(HAVE_SOLDERS, "solders not installed")
    def test_matches_solders_pubkeys(self):
        for _ in range(20):
            kp = Keypair()
            self.assertEqual(M.b58encode(bytes(kp.pubkey())), str(kp.pubkey()))
            self.assertEqual(M.b58decode(str(kp.pubkey())), bytes(kp.pubkey()))

    def test_compact_u16(self):
        for v in [0, 1, 127, 128, 255, 16383, 16384, 65535]:
            enc = M.encode_compact_u16(v)
            self.assertEqual(M.decode_compact_u16(enc), (v, len(enc)))

    def test_address_validation(self):
        self.assertTrue(M.validate_solana_address(M.SOL_MINT))
        self.assertFalse(M.validate_solana_address("not-an-address"))
        self.assertFalse(M.validate_solana_address(""))


@unittest.skipUnless(M.CRYPTO_AVAILABLE, "cryptography not installed")
class KeyTests(unittest.TestCase):
    @unittest.skipUnless(HAVE_SOLDERS, "solders not installed")
    def test_parse_formats_match_solders(self):
        kp = Keypair()
        full = bytes(kp)  # 64 bytes: seed + pubkey
        expected = str(kp.pubkey())
        self.assertEqual(M.parse_private_key(M.b58encode(full)).pubkey(), expected)
        self.assertEqual(M.parse_private_key(json.dumps(list(full))).pubkey(), expected)
        self.assertEqual(M.parse_private_key(M.b58encode(full[:32])).pubkey(), expected)

    def test_rejects_bad_keys(self):
        for bad in ["", "abc", "[1,2,3]", "[not json"]:
            with self.assertRaises(ValueError):
                M.parse_private_key(bad)
        seed = os.urandom(32)
        kp = M.SolKeypair(seed)
        corrupted = seed + bytes(32)  # wrong public half
        self.assertNotEqual(kp.pubkey_bytes, bytes(32))
        with self.assertRaises(ValueError):
            M.SolKeypair.from_secret(corrupted)

    def test_wallet_encrypt_roundtrip(self):
        kp = M.SolKeypair(os.urandom(32))
        secret = M.b58encode(kp._sk.private_bytes(
            M.serialization.Encoding.Raw, M.serialization.PrivateFormat.Raw,
            M.serialization.NoEncryption()) + kp.pubkey_bytes)
        wm = M.WalletManager()
        result = wm.save_private_key(secret, "Str0ng!Passw0rd")
        self.assertIn(kp.pubkey(), str(result))
        wm2 = M.WalletManager()
        with self.assertRaises(Exception):
            wm2.unlock("wrong-password-1A!")
        wm2.unlock("Str0ng!Passw0rd")
        self.assertEqual(wm2.pubkey(), kp.pubkey())
        wm2.clear()


@unittest.skipUnless(HAVE_SOLDERS and M.CRYPTO_AVAILABLE, "solders/cryptography not installed")
class TransactionTests(unittest.TestCase):
    def setUp(self):
        self.sk = Keypair()
        self.kp = M.SolKeypair.from_secret(bytes(self.sk))
        self.blockhash = Hash.new_unique()

    def test_sol_transfer_is_byte_identical_to_solders(self):
        to = Keypair().pubkey()
        lamports = 123_456_789
        ours = M.build_sol_transfer_tx(self.kp, str(to), lamports, str(self.blockhash))
        ix = transfer(TransferParams(from_pubkey=self.sk.pubkey(), to_pubkey=to, lamports=lamports))
        msg = Message.new_with_blockhash([ix], self.sk.pubkey(), self.blockhash)
        ref = bytes(Transaction([self.sk], msg, self.blockhash))
        self.assertEqual(ours, ref)

    def test_transfer_to_self_rejected(self):
        with self.assertRaises(ValueError):
            M.build_sol_transfer_tx(self.kp, str(self.sk.pubkey()), 1, str(self.blockhash))

    def _unsigned(self, versioned: bool) -> bytes:
        """Build a Jupiter-style unsigned tx (zeroed signature slot)."""
        prog = Pubkey.new_unique()
        ix = Instruction(prog, b"\x01\x02\x03",
                         [AccountMeta(self.sk.pubkey(), True, True),
                          AccountMeta(Pubkey.new_unique(), False, True)])
        if versioned:
            msg = MessageV0.try_compile(self.sk.pubkey(), [ix], [], self.blockhash)
        else:
            msg = Message.new_with_blockhash([ix], self.sk.pubkey(), self.blockhash)
        body = to_bytes_versioned(msg) if versioned else bytes(msg)
        return M.encode_compact_u16(1) + bytes(64) + body, msg

    def test_sign_v0_matches_solders(self):
        raw, msg = self._unsigned(True)
        ours = M.sign_versioned_transaction(raw, self.kp)
        ref = bytes(VersionedTransaction(msg, [self.sk]))
        self.assertEqual(ours, ref)
        # Round-trips through the official parser and verifies
        parsed = VersionedTransaction.from_bytes(ours)
        self.assertTrue(parsed.verify_with_results()[0])

    def test_sign_legacy_matches_solders(self):
        raw, msg = self._unsigned(False)
        ours = M.sign_versioned_transaction(raw, self.kp)
        ref = bytes(Transaction([self.sk], msg, self.blockhash))
        self.assertEqual(ours, ref)

    def test_wrong_fee_payer_rejected(self):
        raw, _ = self._unsigned(True)
        other = M.SolKeypair(os.urandom(32))
        with self.assertRaises(ValueError):
            M.sign_versioned_transaction(raw, other)

    def test_sign_and_send_base64_path(self):
        raw, msg = self._unsigned(True)
        trader = M.LiveTrader.__new__(M.LiveTrader)
        trader.wallet = mock.Mock(keypair=self.kp)
        trader.wallet_manager = trader.wallet
        trader.rpc = mock.Mock()
        trader.rpc.send_transaction.return_value = "SIG"
        trader.metrics = M.PerformanceMetrics()
        trader._require_ready = lambda: None
        sig = trader.sign_and_send(base64.b64encode(raw).decode())
        self.assertEqual(sig, "SIG")
        sent = trader.rpc.send_transaction.call_args[0][0]
        sent = base64.b64decode(sent) if isinstance(sent, str) else sent
        self.assertEqual(sent, bytes(VersionedTransaction(msg, [self.sk])))


class ConfigTests(unittest.TestCase):
    def test_unknown_keys_ignored(self):
        with open(M.CONFIG_FILE, "w") as f:
            json.dump({"buy_score": 81, "removed_option": 1, "another": "x"}, f)
        cfg = M.Config.load()
        self.assertEqual(cfg.buy_score, 81)
        os.remove(M.CONFIG_FILE)

    def test_corrupt_file_uses_defaults(self):
        with open(M.CONFIG_FILE, "w") as f:
            f.write("{broken")
        self.assertEqual(M.Config.load().buy_score, M.Config().buy_score)
        os.remove(M.CONFIG_FILE)


class RLTests(unittest.TestCase):
    def test_update_save_load(self):
        agent = M.ReinforcementLearningAgent()
        token = {"score": 80, "liquidity": 50000, "change_1h": 12, "volume": 90000, "risk": "LOWER"}
        action = agent.get_action(token)
        self.assertIn(action, agent.actions if hasattr(agent, "actions") else [action])
        agent.update_q_value(token, "BUY", agent.calculate_reward(0.2, 30))
        path = os.path.join(_TMP_HOME, "rl_test.pkl")
        agent.save(path)
        other = M.ReinforcementLearningAgent()
        other.load(path)
        self.assertEqual(dict(other.q_table), dict(agent.q_table))

    def test_reward_sign(self):
        agent = M.ReinforcementLearningAgent()
        self.assertGreater(agent.calculate_reward(0.3, 20), 0)
        self.assertLess(agent.calculate_reward(-0.3, 20), 0)


class MLTests(unittest.TestCase):
    TOKEN = {"liquidity": 40000, "volume": 120000, "txns": 900, "buys": 600, "sells": 300,
             "change_1h": 15, "change_6h": 30, "change_24h": 60, "age_hours": 5}

    def _train(self, scorer, n=40):
        for i in range(n):
            t = dict(self.TOKEN, change_1h=(30 if i % 2 else -20))
            scorer.record_outcome(t, won=bool(i % 2))

    def test_pure_python_fallback(self):
        with mock.patch.object(M, "ML_AVAILABLE", False):
            scorer = M.AdvancedMLScorer()
            scorer.sklearn = False
            self._train(scorer)
            score, conf = scorer.adjust_score(self.TOKEN, 70)
            self.assertTrue(0 <= score <= 100)
            self.assertIsNotNone(conf)
            self.assertEqual(scorer.samples_seen, 40)

    @unittest.skipUnless(M.ML_AVAILABLE, "scikit-learn not installed")
    def test_sklearn_backend(self):
        scorer = M.AdvancedMLScorer()
        self._train(scorer, 30)
        p, parts = scorer.predict_ensemble(self.TOKEN)
        self.assertTrue(0.0 <= p <= 1.0)

    def test_rules_only_before_min_samples(self):
        scorer = M.AdvancedMLScorer()
        scorer.samples_seen = 0
        self.assertEqual(scorer.adjust_score(self.TOKEN, 66), (66, None))


class MoneyTests(unittest.TestCase):
    def test_formats(self):
        f = M.MainWindow.money
        self.assertEqual(f(0), "0.00")
        self.assertIn("0.00001234", f(0.00001234))
        self.assertNotEqual(f(0.000000012), "0.00000001")
        self.assertEqual(f("bad"), f("bad"))  # never raises


class PaperTradingTests(unittest.TestCase):
    """Paper buy -> close math with a mocked Jupiter quote."""

    @classmethod
    def setUpClass(cls):
        from PySide6.QtWidgets import QApplication
        cls.app = QApplication.instance() or QApplication(sys.argv)
        with mock.patch.object(M.MainWindow, "start_scanner", lambda self: None):
            cls.w = M.MainWindow()

    @classmethod
    def tearDownClass(cls):
        cls.w.close()

    def test_buy_then_close_units(self):
        w = self.w
        w.positions.clear()
        w.balances["CRYPTO"] = 5.0
        mint = M.b58encode(os.urandom(32))
        token = {"address": mint, "symbol": "TEST", "price": 0.001, "price_sol": 0.00001,
                 "price_native": 0.00001, "quote_symbol": "SOL"}
        size = w._paper_size_sol(token)
        decimals = 6
        out_raw = int(size / 0.00001 * 10 ** decimals)  # tokens received in raw units

        def quote(inp, outp, amount, slippage, *a, **k):
            if inp == M.SOL_MINT:
                return {"outAmount": str(out_raw), "priceImpactPct": "0.001"}
            self.assertEqual(amount, out_raw)  # exit uses raw units, not UI amount
            return {"outAmount": str(int(amount / 10 ** decimals * 0.000012 * M.LAMPORTS_PER_SOL)),
                    "priceImpactPct": "0.001"}

        with mock.patch.object(w.live_trader, "get_quote", side_effect=quote), \
             mock.patch.object(w.live_trader, "get_token_decimals", return_value=decimals):
            w.paper_buy(token, manual=True)
            self.assertIn(mint, w.positions)
            pos = w.positions[mint]
            self.assertAlmostEqual(pos["qty"], size / 0.00001, places=3)
            self.assertAlmostEqual(w.balances["CRYPTO"], 5.0 - size, places=9)
            pnl = w._paper_close(mint)
        self.assertAlmostEqual(pnl, size * 0.2, places=6)  # +20% price move
        self.assertAlmostEqual(w.balances["CRYPTO"], 5.0 + size * 0.2, places=6)


if __name__ == "__main__":
    unittest.main(verbosity=2)
