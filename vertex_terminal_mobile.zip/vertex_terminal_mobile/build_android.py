#!/usr/bin/env python3
"""Build the Vertex Terminal Android APK/AAB.

Thin wrapper around PySide6's `pyside6-android-deploy`. The stock tool
hard-codes the python-for-android requirements to
"python3,shiboken6,PySide6", which would leave out `requests` and
`cryptography` (needed for market data and wallet encryption/signing).
This wrapper patches that one setting and adds the network permissions,
then runs the official deploy tool unchanged.

Usage (Linux or macOS host; see README.md for the full setup):

    python build_android.py \
        --wheel-pyside  wheels/PySide6-*-android_aarch64.whl \
        --wheel-shiboken wheels/shiboken6-*-android_aarch64.whl \
        --ndk-path ~/.pyside6_android_deploy/android-ndk/android-ndk-r28c \
        --sdk-path ~/.pyside6_android_deploy/android-sdk \
        --name "Vertex Terminal" -f

All arguments are passed straight through to pyside6-android-deploy.
"""
import os
import runpy
import sys
from pathlib import Path

APP_REQUIREMENTS = [
    "python3", "shiboken6", "PySide6",
    # market data / RPC
    "requests", "urllib3", "certifi", "idna", "charset-normalizer",
    # wallet encryption + Ed25519 signing (p4a ships a recipe)
    "openssl", "cryptography",
]
APP_PERMISSIONS = ["INTERNET", "ACCESS_NETWORK_STATE"]
APP_TITLE = "Vertex Terminal"

# Files kept out of the APK (python-for-android blacklist, fnmatch on full
# paths). charset_normalizer gets installed with *host* (x86-64) mypyc
# binaries, which would fail to load on a phone and break `import requests`;
# without them it uses its bundled pure-Python modules.
APK_BLACKLIST = [
    "site-packages/charset_normalizer/*.so",
    "site-packages/PySide6/libpyside6qml*",
    "site-packages/setuptools/*",
    "site-packages/pkg_resources/*",
    "site-packages/_distutils_hack/*",
    "site-packages/distutils-precedence.pth",
    "site-packages/docs/*",
    "site-packages/bin/*",
    "site-packages/CHANGELOG.rst",
    "site-packages/CONTRIBUTING.rst",
    "*.pyi",
    # project files that are not part of the app
    "android/app/deployment/*", "android/app/tests/*", "build_android.py", "run_build.sh", "build.log",
    "buildozer.spec", "pysidedeploy.spec", "README.md", "requirements.txt",
    "app_icon.ico", "vertex_blacklist.txt",
]

# Code appended to the generated PySide6 python-for-android recipe.
# The stock recipe copies the *whole* PySide6 wheel (QML, 3D, WebView,
# Multimedia, Designer, headers...) into the APK, and every Qt library
# twice. This keeps only the dependency closure of the Qt modules the
# app imports (resolved from the real ELF DT_NEEDED entries), so
# nothing the app links against can go missing.
PRUNE_CODE = r'''

# ---- added by Vertex Terminal build_android.py: APK size trimming ----
import glob as _glob
import re as _re
import subprocess as _sp

_KEEP_MODULES = ("QtCore", "QtGui", "QtWidgets", "QtNetwork")
_KEEP_PLUGIN_TYPES = ("platforms", "imageformats", "iconengines", "styles",
                      "networkinformation", "tls")
# Android uses the system keyboard; these would drag in QML/Quick/PDF engines
_DROP_PLUGINS = ("qpdf", "qtvirtualkeyboard", "qicns", "qtga", "qwbmp", "qtiff")


def _vt_needed(readelf, path):
    try:
        out = _sp.run([readelf, "-d", str(path)], capture_output=True, text=True).stdout
    except Exception:
        return []
    return _re.findall(r"\(NEEDED\).*\[(.+?)\]", out)


def _vt_prune(self, arch):
    libs = Path(self.ctx.get_libs_dir(arch.arch))
    site = Path(self.ctx.get_python_install_dir(arch.arch)) / "PySide6"
    tools = _glob.glob(str(Path(self.ctx.ndk_dir) / "toolchains/llvm/prebuilt/*/bin/llvm-readelf"))
    if not tools:
        info("[vertex] llvm-readelf not found - skipping APK trimming")
        return
    readelf = tools[0]

    plugins_dir = site / "Qt" / "plugins"
    kept_plugins = []
    if plugins_dir.exists():
        for d in plugins_dir.iterdir():
            if d.is_dir() and d.name not in _KEEP_PLUGIN_TYPES:
                shutil.rmtree(d, ignore_errors=True)
        for plug in list(plugins_dir.rglob("*.so")):
            if any(x in plug.name for x in _DROP_PLUGINS):
                plug.unlink()
        kept_plugins = list(plugins_dir.rglob("*.so"))
        # Qt for Android loads plugins from the native lib dir; the stock
        # recipe only copies the platform plugin, so QNetworkInformation,
        # image formats and styles would otherwise never be found.
        for plug in kept_plugins:
            target = libs / plug.name
            if not target.exists():
                shutil.copyfile(plug, target)

    roots = [libs / f"{m}.abi3.so" for m in _KEEP_MODULES]
    roots += [libs / "libpyside6.abi3.so", libs / "libshiboken6.abi3.so"]
    roots += list(libs.glob("libplugins_platforms_qtforandroid_*.so"))
    roots += kept_plugins
    keep, todo = set(), [r for r in roots if r.exists()]
    while todo:
        f = todo.pop()
        for name in _vt_needed(readelf, f):
            if name not in keep:
                keep.add(name)
                cand = libs / name
                if cand.exists():
                    todo.append(cand)
    keep.update(r.name for r in roots)

    removed = 0
    for f in list(libs.iterdir()):
        n = f.name
        prunable = (n.startswith("libQt6") or n.startswith("libplugins_")
                    or _re.match(r"lib(av|sw)[a-z]+\.so", n)
                    or (n.endswith(".abi3.so") and n.startswith("Qt")))
        if prunable and n not in keep:
            removed += f.stat().st_size
            f.unlink()

    # Python side: drop unused modules, stubs, headers, QML, duplicate Qt libs
    if site.exists():
        for f in site.glob("Qt*.abi3.so"):
            if f.name.split(".")[0] not in _KEEP_MODULES:
                removed += f.stat().st_size
                f.unlink()
        for f in site.glob("*.pyi"):
            f.unlink()
        for sub in ("include", "typesystems", "glue", "scripts", "support/generate_pyi.py",
                    "Qt/qml", "Qt/lib", "Qt/translations", "Qt/metatypes", "Qt/modules",
                    "Qt/libexec", "Qt/resources", "Qt/jar", "jar", "Qt/mkspecs"):
            p = site / sub
            if p.is_dir():
                removed += sum(x.stat().st_size for x in p.rglob("*") if x.is_file())
                shutil.rmtree(p, ignore_errors=True)
            elif p.exists():
                p.unlink()
    info(f"[vertex] APK trimming removed {removed / 1e6:.1f} MB of unused Qt files; "
         f"kept {len(keep)} libraries")


_vt_orig_build_arch = PySideRecipe.build_arch


def _vt_build_arch(self, arch):
    _vt_orig_build_arch(self, arch)
    _vt_prune(self, arch)


PySideRecipe.build_arch = _vt_build_arch
'''


def _scripts_dir() -> Path:
    try:
        import PySide6
    except ImportError:
        sys.exit("PySide6 is not installed on this machine: pip install PySide6")
    d = Path(PySide6.__file__).parent / "scripts"
    if not (d / "android_deploy.py").exists():
        sys.exit(f"pyside6-android-deploy not found in {d}")
    return d


def _patch(scripts: Path) -> None:
    sys.path.insert(0, str(scripts))
    from deploy_lib.android import buildozer  # noqa: E402

    original_init = buildozer.BuildozerConfig.__init__

    def patched_init(self, buildozer_spec_file, pysidedeploy_config):
        original_init(self, buildozer_spec_file, pysidedeploy_config)
        self.set_value("app", "requirements", ",".join(APP_REQUIREMENTS))
        try:
            current = self.get_value("app", "android.permissions", ignore_fail=True) or ""
        except Exception:
            current = ""
        perms = [p.strip() for p in current.split(",") if p.strip()]
        for p in APP_PERMISSIONS:
            if p not in perms and f"android.permission.{p}" not in perms:
                perms.append(p)
        self.set_value("app", "android.permissions", ", ".join(perms))
        self.set_value("app", "orientation", "portrait, landscape", raise_warning=False)
        self.set_value("app", "title", APP_TITLE, raise_warning=False)
        blacklist = Path(__file__).resolve().parent / "vertex_blacklist.txt"
        blacklist.write_text("\n".join(APK_BLACKLIST) + "\n", encoding="utf-8")
        self.set_value("app", "android.blacklist_src", str(blacklist), raise_warning=False)
        icon = Path(__file__).resolve().parent / "app_icon.png"
        if icon.exists():
            self.set_value("app", "icon.filename", str(icon), raise_warning=False)
        # Non-interactive builds (CI / headless): accept the SDK licence
        self.set_value("app", "android.accept_sdk_license", "True", raise_warning=False)
        self.update_config()
        print("[vertex] buildozer requirements:", ",".join(APP_REQUIREMENTS))
        print("[vertex] android permissions:", ", ".join(perms))

    buildozer.BuildozerConfig.__init__ = patched_init

    # Trim the APK: append the pruning step to the generated PySide6 recipe
    from deploy_lib.android import android_config, android_helper  # noqa: E402
    original_create_recipe = android_helper.create_recipe

    def patched_create_recipe(version, component, wheel_path, generated_files_path, *a, **k):
        original_create_recipe(version, component, wheel_path, generated_files_path, *a, **k)
        if component.startswith("PySide") and os.environ.get("VERTEX_NO_TRIM") != "1":
            recipe = Path(generated_files_path) / "recipes" / component / "__init__.py"
            text = recipe.read_text(encoding="utf-8")
            marker = "\nrecipe = PySideRecipe()"
            if "_vt_prune" not in text and marker in text:
                text = text.replace(marker, PRUNE_CODE + marker)
                recipe.write_text(text, encoding="utf-8")
                print("[vertex] PySide6 recipe: APK trimming enabled")

    android_helper.create_recipe = patched_create_recipe
    android_config.create_recipe = patched_create_recipe


def main() -> None:
    here = Path(__file__).resolve().parent
    os.chdir(here)  # pyside6-android-deploy expects main.py in the cwd
    if not (here / "main.py").exists():
        sys.exit("main.py not found next to build_android.py")

    # A stale buildozer.spec would bypass the patched settings
    spec = here / "buildozer.spec"
    if spec.exists() and "--keep-spec" not in sys.argv:
        spec.unlink()
    sys.argv = [a for a in sys.argv if a != "--keep-spec"]

    scripts = _scripts_dir()
    _patch(scripts)

    argv = sys.argv[1:]
    if "--extra-modules" not in " ".join(argv):
        argv += ["--extra-modules", "Network"]  # QNetworkInformation (online/offline)
    sys.argv = [str(scripts / "android_deploy.py")] + argv
    runpy.run_path(str(scripts / "android_deploy.py"), run_name="__main__")


if __name__ == "__main__":
    main()
