"""
Vertex Terminal - AI-powered trading terminal (desktop + mobile).

Runs on Windows / macOS / Linux and is packaged for Android
(pyside6-android-deploy) and iOS (pyside6-ios-deploy). The same
sidebar + stacked-pages frame is used everywhere; on narrow (phone)
screens the sidebar slides in as a drawer from a hamburger button.
"""

import sys
import os

# ------------------------------------------------------------
# Vendored pure-python packages (requests, urllib3, ...) are placed in
# ./vendor by build_android.py so the APK works even when pip
# requirements are not resolved by python-for-android.
# ------------------------------------------------------------
_VENDOR_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "vendor")
if os.path.isdir(_VENDOR_DIR) and _VENDOR_DIR not in sys.path:
    sys.path.insert(0, _VENDOR_DIR)

# ------------------------------------------------------------
# Crash reporter (installed before any third-party import).
# Any uncaught Python error - even a failed import on a phone - is
# written to crash.log and shown on screen with a "Copy" button instead
# of the app silently closing or staying blank. Native crashes are
# captured by faulthandler and shown on the next start.
# ------------------------------------------------------------
import traceback as _traceback
import faulthandler as _faulthandler


def _crash_dir() -> str:
    for base in (os.environ.get("ANDROID_PRIVATE"), os.path.expanduser("~"), os.getcwd()):
        if base and os.path.isdir(base) and os.access(base, os.W_OK):
            return base
    return os.getcwd()


_CRASH_LOG = os.path.join(_crash_dir(), "vertex_crash.log")
_NATIVE_LOG = os.path.join(_crash_dir(), "vertex_native_crash.log")
_crash_dialog_open = False


def _show_crash_text(title: str, text: str, fatal: bool) -> None:
    """Show `text` in a scrollable window with Copy/Close buttons."""
    global _crash_dialog_open
    if _crash_dialog_open:
        return
    try:
        from PySide6.QtWidgets import (QApplication as _QA, QDialog as _QD,
                                       QVBoxLayout as _QV, QHBoxLayout as _QH,
                                       QLabel as _QL, QTextEdit as _QT,
                                       QPushButton as _QP)
        app = _QA.instance()
        own_app = app is None
        if own_app:
            app = _QA(sys.argv)
        dlg = _QD()
        dlg.setWindowTitle(title)
        dlg.setStyleSheet("QDialog{background:#0b0f19;color:#e5e7eb;}"
                          "QTextEdit{background:#111827;color:#fca5a5;font-family:monospace;}"
                          "QPushButton{background:#2563eb;color:white;padding:10px;border-radius:6px;}"
                          "QLabel{color:#e5e7eb;}")
        lay = _QV(dlg)
        info = _QL("Vertex Terminal hit an error. Tap Copy and send this text "
                   "so it can be fixed.\nSaved to: " + _CRASH_LOG)
        info.setWordWrap(True)
        lay.addWidget(info)
        box = _QT()
        box.setReadOnly(True)
        box.setPlainText(text)
        lay.addWidget(box, 1)
        row = _QH()
        copy_btn = _QP("Copy")
        copy_btn.clicked.connect(lambda: _QA.clipboard().setText(text))
        close_btn = _QP("Close app" if fatal else "Close")
        close_btn.clicked.connect(dlg.accept)
        row.addWidget(copy_btn)
        row.addWidget(close_btn)
        lay.addLayout(row)
        _crash_dialog_open = True
        try:
            if own_app or fatal:
                dlg.showMaximized()
            dlg.exec()
        finally:
            _crash_dialog_open = False
    except Exception:
        pass  # Qt itself is broken - crash.log / logcat still have the error


def _crash_hook(exc_type, exc, tb):
    text = "".join(_traceback.format_exception(exc_type, exc, tb))
    stamp = __import__("time").strftime("%Y-%m-%d %H:%M:%S")
    try:
        with open(_CRASH_LOG, "a", encoding="utf-8") as fh:
            fh.write("\n==== %s ====\n%s" % (stamp, text))
    except Exception:
        pass
    try:
        sys.stderr.write(text)  # also visible in `adb logcat -s python`
    except Exception:
        pass
    if issubclass(exc_type, (KeyboardInterrupt, SystemExit)):
        return
    # Errors inside a running UI (slots, timers) are not fatal.
    running = False
    try:
        from PySide6.QtWidgets import QApplication as _QA
        running = _QA.instance() is not None and _MAIN_WINDOW_UP
    except Exception:
        pass
    _show_crash_text("Vertex Terminal - error", text, fatal=not running)


_MAIN_WINDOW_UP = False
sys.excepthook = _crash_hook
try:
    _NATIVE_FH = open(_NATIVE_LOG, "a+", encoding="utf-8")
    _NATIVE_FH.seek(0)
    _PREVIOUS_NATIVE_CRASH = _NATIVE_FH.read().strip()
    _NATIVE_FH.seek(0)
    _NATIVE_FH.truncate()
    _faulthandler.enable(_NATIVE_FH)
except Exception:
    _PREVIOUS_NATIVE_CRASH = ""

import json
import base64
import pickle
import time
import math
import struct
import logging
import logging.handlers
import threading
import random
import concurrent.futures
from collections import deque
from datetime import datetime
from typing import Optional, Dict, List, Any, Tuple, Callable
from functools import wraps
from dataclasses import dataclass, asdict, fields

import requests

from PySide6.QtCore import Qt, QThread, Signal, QObject, QTimer, QPropertyAnimation, QEasingCurve, QRect
from PySide6.QtGui import QBrush, QColor, QIcon, QFont, QFontMetrics, QGuiApplication
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QBoxLayout,
    QGridLayout,
    QFormLayout,
    QScrollArea,
    QScroller,
    QLabel,
    QPushButton,
    QButtonGroup,
    QTableWidget,
    QTableWidgetItem,
    QStackedWidget,
    QFrame,
    QSpinBox,
    QDoubleSpinBox,
    QMessageBox,
    QHeaderView,
    QTextEdit,
    QLineEdit,
    QCheckBox,
    QAbstractItemView,
)

try:
    # Importing QtNetwork also makes pyside6-android-deploy add the
    # INTERNET / ACCESS_NETWORK_STATE permissions to the APK manifest.
    from PySide6.QtNetwork import QNetworkInformation
    QTNETWORK_AVAILABLE = True
except Exception:
    QTNETWORK_AVAILABLE = False


# ------------------------------------------------------------
# Platform detection
# ------------------------------------------------------------
IS_ANDROID = (
    sys.platform == "android"
    or hasattr(sys, "getandroidapilevel")
    or "ANDROID_ARGUMENT" in os.environ
    or "ANDROID_PRIVATE" in os.environ
)
IS_IOS = sys.platform == "ios"
IS_MOBILE = IS_ANDROID or IS_IOS

# Width (logical px) under which the UI switches to the phone layout.
COMPACT_BREAKPOINT = 1000


def _app_data_dir() -> str:
    """Writable per-app directory on every platform."""
    if IS_ANDROID:
        base = os.environ.get("ANDROID_PRIVATE") or os.environ.get("HOME") or os.getcwd()
    elif IS_IOS:
        base = os.path.join(os.path.expanduser("~"), "Documents")
    else:
        base = os.path.expanduser("~")
    try:
        os.makedirs(base, exist_ok=True)
    except Exception:
        base = os.getcwd()
    return base


DATA_DIR = _app_data_dir()

# ------------------------------------------------------------
# Optional live-trading / ML dependencies.
# The app still runs in PAPER mode without these installed.
# Live trading only needs `cryptography` (wallet encryption + Ed25519
# signing). Solana transactions are built/signed natively below, so the
# heavy `solders` / `solana` packages are no longer required - which is
# what makes LIVE mode possible on Android/iOS.
# ------------------------------------------------------------
try:
    from cryptography.fernet import Fernet, InvalidToken
    from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
    from cryptography.hazmat.primitives import hashes
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization
    CRYPTO_AVAILABLE = True
except Exception:
    CRYPTO_AVAILABLE = False

    class InvalidToken(Exception):
        pass

# Kept for backwards compatibility with code/messages that check it.
SOLANA_AVAILABLE = CRYPTO_AVAILABLE

try:
    from sklearn.linear_model import SGDClassifier
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    import numpy as np
    ML_AVAILABLE = True
except Exception:
    ML_AVAILABLE = False
    np = None

# ============================================================
# SETTINGS
# ============================================================

STARTING_BALANCE = 1000.00          # legacy, unused now that paper mode is SOL-denominated
STARTING_BALANCE_SOL = 5.0          # simulated paper wallet balance, mirrors a live wallet
STARTING_BALANCE_USD = 10000.0     # Forex/Stock paper balance

DEFAULT_POSITION_SIZE = 50.00
DEFAULT_BUY_SCORE = 70
DEFAULT_SCAN_INTERVAL = 60

TAKE_PROFIT = 0.30       # +30%
STOP_LOSS = -0.15        # -15%

MIN_LIQUIDITY = 20_000
MIN_VOLUME = 25_000
MIN_TXNS = 100

PROFILE_URL = "https://api.dexscreener.com/token-profiles/latest/v1"
BOOST_URL = "https://api.dexscreener.com/token-boosts/latest/v1"

SOLANA = "solana"

# Asset Classes
ASSET_CLASSES = {
    "CRYPTO": {
        "name": "Cryptocurrency",
        "base_currency": "USD",
        "data_sources": ["dexscreener", "coingecko"],
        "min_position": 0.007,  # SOL
        "broker": "jupiter"
    },
    "FOREX": {
        "name": "Forex",
        "base_currency": "USD",
        "data_sources": ["alphavantage", "forex"],
        "min_position": 100,  # USD
        "broker": "oanda"
    },
    "STOCK": {
        "name": "Stocks",
        "base_currency": "USD",
        "data_sources": ["alphavantage", "yahoo"],
        "min_position": 100,  # USD
        "broker": "alpaca"
    }
}

# Forex Data Sources
FOREX_API_URL = "https://www.alphavantage.co/query"
FOREX_API_KEY = "demo"  # Default; set your own key in Settings -> Scanner

# Stock Data Sources
STOCK_API_URL = "https://www.alphavantage.co/query"
STOCK_API_KEY = "demo"  # Default; set your own key in Settings -> Scanner

# Alpha Vantage only publishes daily bars for these functions and the
# free tier allows ~25 calls/day, so cache each symbol for an hour.
ALPHAVANTAGE_CACHE_TTL = 3600

# ------------------------------------------------------------
# LIVE TRADING SETTINGS
# ------------------------------------------------------------

WALLET_FILE = os.path.join(DATA_DIR, ".meme_trader_wallet.enc")
ML_STATE_FILE = os.path.join(DATA_DIR, ".meme_trader_model.pkl")
RL_STATE_FILE = os.path.join(DATA_DIR, ".meme_trader_rl_agent.pkl")
CONFIG_FILE = os.path.join(DATA_DIR, ".meme_trader_config.json")
PORTFOLIO_FILE = os.path.join(DATA_DIR, ".meme_trader_portfolio.json")
AUDIT_LOG_FILE = os.path.join(DATA_DIR, ".meme_trader_audit.log")
APP_LOG_FILE = os.path.join(DATA_DIR, ".meme_trader_app.log")

SOLANA_RPC_URL = "https://api.mainnet-beta.solana.com"

# The old quote-api.jup.ag/v6 endpoints were retired by Jupiter on
# 2025-10-01. lite-api.jup.ag is the keyless public endpoint.
JUPITER_QUOTE_URL = "https://lite-api.jup.ag/swap/v1/quote"
JUPITER_SWAP_URL = "https://lite-api.jup.ag/swap/v1/swap"

LAMPORTS_PER_SOL = 1_000_000_000
SYSTEM_PROGRAM_ID = "11111111111111111111111111111111"
TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGqPx2wR6y2wsdKrZCSpCq"
TOKEN_2022_PROGRAM_ID = "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"

SOL_MINT = "So11111111111111111111111111111111111111112"

DEFAULT_SLIPPAGE_BPS = 300          # 3%
DEFAULT_PROFIT_WITHDRAW_PCT = 50    # % of realized profit auto-swept to payout wallet
MIN_LIVE_POSITION_SOL = 0.007       # hard floor per trade - bot will never size below this
MAX_LIVE_POSITION_SOL = 1.0         # hard safety cap per trade, editable in Settings
FEE_RESERVE_SOL = 0.01              # always left unspent in the wallet for network fees
MAX_PRICE_IMPACT_PCT = 5.0          # refuse a swap if Jupiter's quoted impact exceeds this
DEFAULT_MAX_DAILY_LOSS_SOL = 0.5    # circuit breaker: auto-disable live trading past this

# Public, non-insider signals only. This does NOT know about
# private/upcoming exchange listings - it flags tokens showing the
# kind of social/volume acceleration that sometimes precedes a listing.
TRENDING_URL = "https://api.coingecko.com/api/v3/search/trending"

# Multiple data sources for real-time streaming
DATA_SOURCES = {
    "dexscreener": {
        "base_url": "https://api.dexscreener.com",
        "endpoints": {
            "profiles": "/token-profiles/latest/v1",
            "boosts": "/token-boosts/latest/v1",
            "pairs": "/token-pairs/v1/solana/{}"
        },
        "priority": 1
    },
    "geckoterminal": {
        "base_url": "https://api.geckoterminal.com/api/v2",
        "endpoints": {
            "trending": "/networks/solana/tokens",
            "pools": "/networks/solana/pools/{}"
        },
        "priority": 2
    },
    "birdeye": {
        "base_url": "https://public-api.birdeye.so",
        "endpoints": {
            "token_list": "/defi/tokenlist",
            "token_price": "/defi/price",
            "token_overview": "/defi/token_overview"
        },
        "priority": 3
    }
}

# Fallback RPC endpoints for Solana
SOLANA_RPC_URLS = [
    "https://api.mainnet-beta.solana.com",
    "https://rpc.ankr.com/solana",
    "https://solana.publicnode.com",
]

# Logging configuration.
# The application log is separate from the trade audit log (the original
# wrote both to the same file) and rotates so it can't fill a phone.
def _setup_logging() -> logging.Logger:
    handlers: List[logging.Handler] = [logging.StreamHandler()]
    try:
        handlers.insert(0, logging.handlers.RotatingFileHandler(
            APP_LOG_FILE, maxBytes=1_000_000, backupCount=2, encoding="utf-8"))
    except Exception:
        pass
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=handlers,
    )
    return logging.getLogger("vertex")


logger = _setup_logging()


# ============================================================
# UTILITY CLASSES
# ============================================================

@dataclass
class Config:
    """Application configuration that persists between sessions."""
    buy_score: int = DEFAULT_BUY_SCORE
    scan_interval: int = DEFAULT_SCAN_INTERVAL
    live_position_size_sol: float = 0.05
    payout_address: str = ""
    profit_withdraw_pct: int = DEFAULT_PROFIT_WITHDRAW_PCT
    auto_trade: bool = False
    max_daily_loss_sol: float = DEFAULT_MAX_DAILY_LOSS_SOL
    take_profit: float = 0.30
    stop_loss: float = -0.15
    trailing_stop_pct: float = 0.0
    max_open_live_positions: int = 3
    cooldown_after_loss_min: int = 15
    prioritize_new_memes: bool = True
    max_token_age_hours: int = 48
    min_liquidity_usd: int = MIN_LIQUIDITY
    min_volume_usd: int = MIN_VOLUME
    min_txns: int = MIN_TXNS
    max_price_impact_pct: float = MAX_PRICE_IMPACT_PCT
    slippage_bps: int = DEFAULT_SLIPPAGE_BPS
    wallet_session_timeout_min: int = 30
    alphavantage_api_key: str = "demo"
    usd_position_size: float = 100.0
    jupiter_api_key: str = ""

    def save(self) -> bool:
        """Save configuration to file."""
        try:
            with open(CONFIG_FILE, 'w') as f:
                json.dump(asdict(self), f, indent=2)
            logger.info("Configuration saved successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to save configuration: {e}")
            return False

    @classmethod
    def load(cls) -> 'Config':
        """Load configuration from file or return defaults."""
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r') as f:
                    data = json.load(f)
                # Ignore unknown/removed keys so an old or newer config
                # file never crashes start-up.
                known = {f.name for f in fields(cls)}
                clean = {k: v for k, v in (data or {}).items() if k in known}
                logger.info("Configuration loaded successfully")
                return cls(**clean)
        except Exception as e:
            logger.error(f"Failed to load configuration: {e}, using defaults")
        return cls()


class RateLimiter:
    """Rate limiter for API calls to prevent abuse."""
    def __init__(self, max_calls: int = 60, time_window: int = 60):
        self.max_calls = max_calls
        self.time_window = time_window
        self.calls: List[float] = []
        self.lock = threading.Lock()

    def acquire(self, block: bool = False, timeout: float = 30.0) -> bool:
        """Try to acquire a rate limit slot (optionally waiting for one)."""
        deadline = time.time() + timeout
        while True:
            if self._try_acquire():
                return True
            if not block or time.time() >= deadline:
                return False
            time.sleep(min(0.5, max(0.05, self.wait_time())))

    def _try_acquire(self) -> bool:
        with self.lock:
            now = time.time()
            # Remove calls outside the time window
            self.calls = [call_time for call_time in self.calls if now - call_time < self.time_window]
            if len(self.calls) < self.max_calls:
                self.calls.append(now)
                return True
            return False

    def wait_time(self) -> float:
        """Get time to wait before next call is allowed."""
        with self.lock:
            if not self.calls:
                return 0.0
            oldest = min(self.calls)
            return max(0.0, self.time_window - (time.time() - oldest))


class CircuitBreaker:
    """Circuit breaker pattern for failing APIs."""
    def __init__(self, failure_threshold: int = 5, recovery_timeout: int = 60):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failures = 0
        self.last_failure_time: Optional[float] = None
        self.state = "closed"  # closed, open, half-open
        self.lock = threading.Lock()

    def call(self, func: Callable, *args, **kwargs) -> Any:
        """Execute function with circuit breaker protection."""
        with self.lock:
            if self.state == "open":
                if time.time() - self.last_failure_time > self.recovery_timeout:
                    self.state = "half-open"
                    logger.info("Circuit breaker transitioning to half-open")
                else:
                    raise Exception("Circuit breaker is OPEN - calls blocked")

        try:
            result = func(*args, **kwargs)
            with self.lock:
                if self.state == "half-open":
                    self.state = "closed"
                    self.failures = 0
                    logger.info("Circuit breaker recovered to closed state")
            return result
        except Exception:
            with self.lock:
                self.failures += 1
                self.last_failure_time = time.time()
                if self.failures >= self.failure_threshold:
                    self.state = "open"
                    logger.error(f"Circuit breaker opened after {self.failures} failures")
            raise


def retry_with_backoff(max_retries: int = 3, base_delay: float = 1.0):
    """Decorator for retry logic with exponential backoff."""
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            last_exception = None
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        delay = base_delay * (2 ** attempt)
                        logger.warning(f"Attempt {attempt + 1} failed for {func.__name__}: {e}, retrying in {delay}s")
                        time.sleep(delay)
            logger.error(f"All {max_retries} attempts failed for {func.__name__}")
            raise last_exception
        return wrapper
    return decorator


class RequestCache:
    """Simple in-memory cache for API responses."""
    def __init__(self, ttl: int = 300):  # 5 minutes default TTL
        self.cache: Dict[str, Tuple[Any, float]] = {}
        self.ttl = ttl
        self.lock = threading.Lock()

    def get(self, key: str) -> Optional[Any]:
        """Get cached value if still valid."""
        with self.lock:
            if key in self.cache:
                value, timestamp = self.cache[key]
                if time.time() - timestamp < self.ttl:
                    return value
                else:
                    del self.cache[key]
        return None

    def set(self, key: str, value: Any) -> None:
        """Cache a value with current timestamp."""
        with self.lock:
            self.cache[key] = (value, time.time())

    def clear(self) -> None:
        """Clear all cached values."""
        with self.lock:
            self.cache.clear()


def validate_password_strength(password: str) -> Tuple[bool, str]:
    """Validate password strength. Returns (is_valid, message)."""
    if len(password) < 8:
        return False, "Password must be at least 8 characters"
    if not any(c.isupper() for c in password):
        return False, "Password must contain at least one uppercase letter"
    if not any(c.islower() for c in password):
        return False, "Password must contain at least one lowercase letter"
    if not any(c.isdigit() for c in password):
        return False, "Password must contain at least one digit"
    return True, "Password is strong"


def validate_solana_address(address: str) -> bool:
    """Basic validation of Solana address format."""
    if not address or len(address) < 32 or len(address) > 44:
        return False
    try:
        # Solana addresses are base58 encoded 32-byte public keys
        return len(b58decode(address)) == 32
    except Exception:
        return False


_CONNECTIVITY_URLS = (
    "https://api.dexscreener.com/token-profiles/latest/v1",
    "https://www.gstatic.com/generate_204",
)


def check_network_connectivity() -> bool:
    """Check if network connectivity is available (works where google.com is blocked)."""
    for url in _CONNECTIVITY_URLS:
        try:
            response = requests.get(url, timeout=5)
            if response.status_code < 500:
                return True
        except Exception:
            continue
    return False


_AUDIT_LOCK = threading.Lock()


class AuditLogger:
    """Audit logger for all trading actions."""
    @staticmethod
    def log_action(action: str, details: Dict[str, Any]) -> None:
        """Log a trading action to the audit log."""
        log_entry = {
            "timestamp": datetime.now().isoformat(),
            "action": action,
            "details": details
        }
        try:
            with _AUDIT_LOCK:
                # Keep the audit log bounded on phones (rotate at ~2 MB)
                try:
                    if os.path.getsize(AUDIT_LOG_FILE) > 2_000_000:
                        os.replace(AUDIT_LOG_FILE, AUDIT_LOG_FILE + ".1")
                except OSError:
                    pass
                with open(AUDIT_LOG_FILE, 'a', encoding="utf-8") as f:
                    f.write(json.dumps(log_entry, default=str) + '\n')
        except Exception as e:
            logger.error(f"Failed to write to audit log: {e}")


class PerformanceMetrics:
    """Track performance metrics for monitoring."""
    def __init__(self):
        self.metrics: Dict[str, List[float]] = {}
        self.lock = threading.Lock()

    def record(self, metric_name: str, value: float) -> None:
        """Record a metric value."""
        with self.lock:
            if metric_name not in self.metrics:
                self.metrics[metric_name] = []
            self.metrics[metric_name].append(value)
            # Keep only last 1000 values
            if len(self.metrics[metric_name]) > 1000:
                self.metrics[metric_name] = self.metrics[metric_name][-1000:]

    def get_average(self, metric_name: str) -> Optional[float]:
        """Get average value for a metric."""
        with self.lock:
            if metric_name in self.metrics and self.metrics[metric_name]:
                return sum(self.metrics[metric_name]) / len(self.metrics[metric_name])
        return None

    def get_stats(self, metric_name: str) -> Optional[Dict[str, float]]:
        """Get statistics for a metric."""
        with self.lock:
            if metric_name not in self.metrics or not self.metrics[metric_name]:
                return None
            values = self.metrics[metric_name]
            return {
                "count": len(values),
                "min": min(values),
                "max": max(values),
                "avg": sum(values) / len(values),
                "last": values[-1]
            }


class RealTimeDataStream:
    """High-speed real-time data streaming from multiple sources."""
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "MemeTraderV5/2.0"})
        self.data_cache: Dict[str, Tuple[Dict, float]] = {}  # address -> (data, timestamp)
        self.cache_ttl = 10  # 10 seconds
        self.lock = threading.Lock()
        self.active_streams: Dict[str, bool] = {}
        self.stream_threads: Dict[str, threading.Thread] = {}

    def fetch_from_source(self, source_name: str, endpoint: str, params: Dict = None) -> Optional[Dict]:
        """Fetch data from a specific source with retry logic."""
        source_config = DATA_SOURCES.get(source_name)
        if not source_config:
            logger.warning(f"Unknown data source: {source_name}")
            return None

        url = source_config["base_url"] + endpoint

        try:
            response = self.session.get(url, params=params, timeout=5)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.error(f"Failed to fetch from {source_name}: {e}")
            return None

    def fetch_all_sources(self, endpoint_key: str, params: Dict = None) -> List[Dict]:
        """Fetch data from all available sources in parallel."""
        results = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = []
            for source_name, config in DATA_SOURCES.items():
                if endpoint_key in config["endpoints"]:
                    future = executor.submit(
                        self.fetch_from_source,
                        source_name,
                        config["endpoints"][endpoint_key],
                        params
                    )
                    futures.append((future, source_name, config["priority"]))

            for future, source_name, priority in futures:
                try:
                    result = future.result(timeout=10)
                    if result:
                        results.append({"source": source_name, "priority": priority, "data": result})
                except Exception as e:
                    logger.error(f"Parallel fetch failed for {source_name}: {e}")

        # Sort by priority
        results.sort(key=lambda x: x["priority"])
        return results

    def get_token_data(self, address: str) -> Optional[Dict]:
        """Get cached or fresh token data from best available source."""
        with self.lock:
            cached_data, timestamp = self.data_cache.get(address, (None, 0))
            if cached_data and (time.time() - timestamp) < self.cache_ttl:
                return cached_data

        # Fetch fresh data (the endpoint templates need the address filled in)
        for source_name in ("dexscreener", "geckoterminal"):
            cfg = DATA_SOURCES[source_name]
            key = "pairs" if "pairs" in cfg["endpoints"] else "pools"
            endpoint = cfg["endpoints"].get(key)
            if not endpoint:
                continue
            data = self.fetch_from_source(source_name, endpoint.format(address))
            if data:
                with self.lock:
                    self.data_cache[address] = (data, time.time())
                return data

        return None

    def start_streaming(self, callback: Callable) -> None:
        """Start continuous data streaming."""
        def stream_worker():
            while self.active_streams.get("main", False):
                try:
                    data = self.fetch_all_sources("profiles", {})
                    if data:
                        callback(data)
                    time.sleep(5)  # Poll every 5 seconds
                except Exception as e:
                    logger.error(f"Streaming error: {e}")
                    time.sleep(10)

        self.active_streams["main"] = True
        thread = threading.Thread(target=stream_worker, daemon=True)
        thread.start()
        self.stream_threads["main"] = thread
        logger.info("Real-time data streaming started")

    def stop_streaming(self) -> None:
        """Stop data streaming."""
        self.active_streams["main"] = False
        logger.info("Real-time data streaming stopped")


class PriorityTradeQueue:
    """Priority queue for high-speed trade execution."""
    def __init__(self):
        self.queue = []
        self.lock = threading.Lock()
        self.condition = threading.Condition(self.lock)
        self.running = False
        self.worker_thread = None

    def add_trade(self, token: Dict, priority: int, callback: Callable) -> None:
        """Add a trade to the queue with priority (higher = more urgent)."""
        with self.lock:
            self.queue.append((priority, time.time(), token, callback))
            self.queue.sort(key=lambda x: (-x[0], x[1]))  # Sort by priority (desc) then time (asc)
            self.condition.notify()
        logger.info(f"Trade added to queue: {token.get('symbol', 'UNKNOWN')} priority {priority}")

    def start_worker(self) -> None:
        """Start the trade execution worker."""
        def worker():
            self.running = True
            while self.running:
                with self.lock:
                    while not self.queue and self.running:
                        self.condition.wait(timeout=1)

                    if not self.running:
                        break

                    if self.queue:
                        priority, timestamp, token, callback = self.queue.pop(0)

                try:
                    callback(token)
                except Exception as e:
                    logger.error(f"Trade execution failed: {e}")

        self.worker_thread = threading.Thread(target=worker, daemon=True)
        self.worker_thread.start()
        logger.info("Priority trade queue worker started")

    def stop_worker(self) -> None:
        """Stop the trade execution worker."""
        self.running = False
        with self.lock:
            self.condition.notify_all()
        if self.worker_thread:
            self.worker_thread.join(timeout=5)
        logger.info("Priority trade queue worker stopped")

    def get_queue_size(self) -> int:
        """Get current queue size."""
        with self.lock:
            return len(self.queue)


class ReinforcementLearningAgent:
    """Q-learning agent for adaptive trade decision making."""
    def __init__(self, learning_rate: float = 0.1, discount_factor: float = 0.95, epsilon: float = 0.1):
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.epsilon = epsilon  # Exploration rate
        self.q_table: Dict[str, Dict[str, float]] = {}  # state -> action -> q-value
        self.state_history: deque = deque(maxlen=10000)  # (state, action, reward)
        self.actions = ["BUY", "WAIT", "SELL"]
        self.lock = threading.Lock()

    def _get_state(self, token: Dict) -> str:
        """Discretize token state into a string representation."""
        score = int(token.get("score", 0) / 10) * 10  # Round to nearest 10
        risk = token.get("risk", "HIGH")
        liquidity_tier = "HIGH" if token.get("liquidity", 0) > 100000 else "LOW"
        volume_tier = "HIGH" if token.get("volume", 0) > 50000 else "LOW"
        momentum = "UP" if token.get("change_1h", 0) > 0 else "DOWN"

        return f"{score}_{risk}_{liquidity_tier}_{volume_tier}_{momentum}"

    def get_action(self, token: Dict, force_explore: bool = False) -> str:
        """Get action using epsilon-greedy policy."""
        state = self._get_state(token)

        # Epsilon-greedy exploration
        if force_explore or (random.random() < self.epsilon):
            return random.choice(self.actions)

        with self.lock:
            if state not in self.q_table:
                self.q_table[state] = {action: 0.0 for action in self.actions}

            # Choose action with highest Q-value
            q_values = self.q_table[state]
            max_q = max(q_values.values())
            best_actions = [a for a, q in q_values.items() if q == max_q]
            return random.choice(best_actions)

    def update_q_value(self, token: Dict, action: str, reward: float, next_token: Dict = None) -> None:
        """Update Q-value using Q-learning update rule."""
        state = self._get_state(token)
        next_state = self._get_state(next_token) if next_token else state

        with self.lock:
            if state not in self.q_table:
                self.q_table[state] = {a: 0.0 for a in self.actions}
            if next_state not in self.q_table:
                self.q_table[next_state] = {a: 0.0 for a in self.actions}

            current_q = self.q_table[state][action]
            max_next_q = max(self.q_table[next_state].values())

            # Q-learning update: Q(s,a) = Q(s,a) + α[r + γmax(Q(s',a')) - Q(s,a)]
            new_q = current_q + self.learning_rate * (reward + self.discount_factor * max_next_q - current_q)
            self.q_table[state][action] = new_q

            # deque(maxlen=10000) drops the oldest entry automatically
            # (the original list.pop(0) crashed after load() made it a deque)
            self.state_history.append((state, action, reward))

    def calculate_reward(self, pnl: float, hold_time: float) -> float:
        """Calculate reward based on P&L and hold time."""
        # Base reward from P&L
        reward = pnl * 10  # Scale up for better learning

        # Time penalty (encourage faster decisions)
        time_penalty = -hold_time * 0.01

        # Bonus for quick profitable trades
        if pnl > 0 and hold_time < 60:  # Less than 1 hour
            reward += 5

        return reward + time_penalty

    def decay_epsilon(self) -> None:
        """Decay exploration rate over time."""
        self.epsilon = max(0.01, self.epsilon * 0.9995)

    def get_statistics(self) -> Dict[str, Any]:
        """Get RL agent statistics."""
        with self.lock:
            return {
                "epsilon": self.epsilon,
                "q_table_size": len(self.q_table),
                "state_history_size": len(self.state_history),
                "total_updates": len(self.state_history)
            }

    def save(self, filepath: str) -> None:
        """Save Q-table to file."""
        with self.lock:
            try:
                with open(filepath, 'wb') as f:
                    pickle.dump({
                        "q_table": self.q_table,
                        "epsilon": self.epsilon,
                        "state_history": list(self.state_history)
                    }, f)
                logger.info("RL agent state saved")
            except Exception as e:
                logger.error(f"Failed to save RL agent: {e}")

    def load(self, filepath: str) -> None:
        """Load Q-table from file."""
        try:
            if os.path.exists(filepath):
                with open(filepath, 'rb') as f:
                    data = pickle.load(f)
                with self.lock:
                    self.q_table = data.get("q_table", {})
                    self.epsilon = data.get("epsilon", 0.1)
                    self.state_history = deque(data.get("state_history", []), maxlen=10000)
                logger.info("RL agent state loaded")
        except Exception as e:
            logger.error(f"Failed to load RL agent: {e}")


class SentimentAnalyzer:
    """Analyze social media sentiment for meme coins."""
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "MemeTraderV5/2.0"
        })
        self.sentiment_cache: Dict[str, Tuple[float, float]] = {}  # symbol -> (sentiment, timestamp)
        self.cache_ttl = 300  # 5 minutes
        self.lock = threading.Lock()

    def _fetch_external_sentiment(self, source: str, symbol: str) -> float:
        """Hook for a real sentiment provider. Returns 0.0 (neutral) by default."""
        return 0.0

    def analyze_twitter_sentiment(self, symbol: str) -> float:
        """Analyze Twitter sentiment for a token symbol.

        Returns:
            Sentiment score between -1 (negative) and 1 (positive)
        """
        # This would typically use Twitter API or a sentiment analysis service
        # For now, we'll use a placeholder implementation
        # In production, integrate with Twitter API v2 or use services like:
        # - Twitter API with sentiment analysis
        # - Brandwatch
        # - Hootsuite Insights
        # - Custom NLP models on tweets

        cache_key = f"twitter_{symbol}"
        with self.lock:
            cached_sentiment, timestamp = self.sentiment_cache.get(cache_key, (0, 0))
            if (time.time() - timestamp) < self.cache_ttl:
                return cached_sentiment

        # Placeholder: no social API is configured, so stay NEUTRAL.
        # (The original used hash(), which is randomized per process and
        # injected fake +/-10 score noise into every token.)
        sentiment = self._fetch_external_sentiment("twitter", symbol)

        with self.lock:
            self.sentiment_cache[cache_key] = (sentiment, time.time())

        return sentiment

    def analyze_reddit_sentiment(self, symbol: str) -> float:
        """Analyze Reddit sentiment for a token symbol.

        Returns:
            Sentiment score between -1 (negative) and 1 (positive)
        """
        # This would typically use Reddit API (PRAW) or sentiment analysis service
        # For now, placeholder implementation

        cache_key = f"reddit_{symbol}"
        with self.lock:
            cached_sentiment, timestamp = self.sentiment_cache.get(cache_key, (0, 0))
            if (time.time() - timestamp) < self.cache_ttl:
                return cached_sentiment

        # Placeholder: neutral until a real data source is plugged in
        sentiment = self._fetch_external_sentiment("reddit", symbol)

        with self.lock:
            self.sentiment_cache[cache_key] = (sentiment, time.time())

        return sentiment

    def analyze_telegram_sentiment(self, symbol: str) -> float:
        """Analyze Telegram sentiment for a token symbol.

        Returns:
            Sentiment score between -1 (negative) and 1 (positive)
        """
        # This would typically monitor Telegram groups/channels
        # For now, placeholder implementation

        cache_key = f"telegram_{symbol}"
        with self.lock:
            cached_sentiment, timestamp = self.sentiment_cache.get(cache_key, (0, 0))
            if (time.time() - timestamp) < self.cache_ttl:
                return cached_sentiment

        # Placeholder: neutral until a real data source is plugged in
        sentiment = self._fetch_external_sentiment("telegram", symbol)

        with self.lock:
            self.sentiment_cache[cache_key] = (sentiment, time.time())

        return sentiment

    def get_combined_sentiment(self, symbol: str) -> Dict[str, float]:
        """Get combined sentiment from all sources.

        Returns:
            Dictionary with individual and combined sentiment scores
        """
        twitter = self.analyze_twitter_sentiment(symbol)
        reddit = self.analyze_reddit_sentiment(symbol)
        telegram = self.analyze_telegram_sentiment(symbol)

        # Weighted average (Twitter has more weight for meme coins)
        combined = (twitter * 0.5 + reddit * 0.3 + telegram * 0.2)

        return {
            "twitter": twitter,
            "reddit": reddit,
            "telegram": telegram,
            "combined": combined
        }

    def add_sentiment_to_token(self, token: Dict) -> Dict:
        """Add sentiment analysis to token data."""
        symbol = token.get("symbol", "")
        if not symbol:
            return token

        sentiment = self.get_combined_sentiment(symbol)
        token["sentiment"] = sentiment

        # Adjust score based on sentiment
        sentiment_boost = sentiment["combined"] * 10  # Max +/- 10 points
        token["score"] = int(round(max(0, min(100, token.get("score", 0) + sentiment_boost))))

        return token


# ============================================================
# COLORS
# ============================================================

BG = "#0b0f14"
SIDEBAR = "#111720"
CARD = "#151c25"
CARD_2 = "#19222d"
TEXT = "#f2f5f7"
MUTED = "#8793a1"
GREEN = "#36d399"
RED = "#ff5c70"
BLUE = "#4da3ff"
YELLOW = "#f5c451"
PURPLE = "#a78bfa"


# ============================================================
# NATIVE SOLANA LAYER
# ------------------------------------------------------------
# Minimal, dependency-light replacement for solders/solana/base58 so
# LIVE trading also works on Android/iOS. Uses only `requests` and
# `cryptography` (Ed25519). Transaction bytes are byte-identical to
# what solders produces (verified by the test-suite in tests/).
# ============================================================

_B58_ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"
_B58_INDEX = {c: i for i, c in enumerate(_B58_ALPHABET)}


def b58encode(data: bytes) -> str:
    n = int.from_bytes(data, "big")
    out = []
    while n > 0:
        n, r = divmod(n, 58)
        out.append(_B58_ALPHABET[r])
    pad = len(data) - len(data.lstrip(b"\0"))
    return "1" * pad + "".join(reversed(out))


def b58decode(text: str) -> bytes:
    text = text.strip()
    n = 0
    for c in text:
        if c not in _B58_INDEX:
            raise ValueError(f"Invalid base58 character: {c!r}")
        n = n * 58 + _B58_INDEX[c]
    body = n.to_bytes((n.bit_length() + 7) // 8, "big") if n else b""
    pad = len(text) - len(text.lstrip("1"))
    return b"\0" * pad + body


def encode_compact_u16(value: int) -> bytes:
    out = bytearray()
    while True:
        b = value & 0x7F
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def decode_compact_u16(data: bytes, offset: int = 0) -> Tuple[int, int]:
    """Returns (value, bytes_consumed)."""
    value = 0
    for i in range(3):
        b = data[offset + i]
        value |= (b & 0x7F) << (7 * i)
        if not b & 0x80:
            return value, i + 1
    raise ValueError("Invalid compact-u16")


class SolKeypair:
    """Ed25519 keypair (32-byte seed + 32-byte public key)."""

    def __init__(self, seed: bytes):
        if not CRYPTO_AVAILABLE:
            raise RuntimeError("The 'cryptography' package is required for signing.")
        if len(seed) != 32:
            raise ValueError("Ed25519 seed must be 32 bytes")
        self._sk = Ed25519PrivateKey.from_private_bytes(seed)
        self.pubkey_bytes = self._sk.public_key().public_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PublicFormat.Raw,
        )

    @classmethod
    def from_secret(cls, secret: bytes) -> "SolKeypair":
        if len(secret) == 64:
            kp = cls(secret[:32])
            if kp.pubkey_bytes != secret[32:]:
                raise ValueError("Private key is corrupted (public half does not match)")
            return kp
        if len(secret) == 32:
            return cls(secret)
        raise ValueError(f"Private key must be 32 or 64 bytes, got {len(secret)}")

    def pubkey(self) -> str:
        return b58encode(self.pubkey_bytes)

    def sign(self, message: bytes) -> bytes:
        return self._sk.sign(message)


def parse_private_key(text: str) -> SolKeypair:
    """Accepts base58 (Phantom/Solflare export) or a JSON byte array (solana-keygen)."""
    text = (text or "").strip()
    if not text:
        raise ValueError("Private key is empty")
    if text.startswith("["):
        try:
            arr = json.loads(text)
            secret = bytes(int(x) & 0xFF for x in arr)
        except Exception:
            raise ValueError("Could not parse the JSON key array")
    else:
        try:
            secret = b58decode(text)
        except ValueError as e:
            raise ValueError(f"Not a valid base58 private key ({e})")
    return SolKeypair.from_secret(secret)


def sign_versioned_transaction(raw_tx: bytes, keypair: SolKeypair) -> bytes:
    """Sign a serialized (legacy or v0) transaction from Jupiter as fee payer."""
    num_sigs, n = decode_compact_u16(raw_tx, 0)
    if num_sigs < 1:
        raise ValueError("Transaction has no signature slots")
    sig_start = n
    msg_start = sig_start + 64 * num_sigs
    message = raw_tx[msg_start:]
    # Verify we are the fee payer (first static account key)
    off = 1 if message[0] & 0x80 else 0  # versioned prefix
    off += 3  # header
    _nkeys, k = decode_compact_u16(message, off)
    first_key = message[off + k: off + k + 32]
    if first_key != keypair.pubkey_bytes:
        raise ValueError("Swap transaction fee payer does not match the unlocked wallet")
    signature = keypair.sign(message)
    return raw_tx[:sig_start] + signature + raw_tx[sig_start + 64:]


def build_sol_transfer_tx(keypair: SolKeypair, to_address: str, lamports: int,
                          recent_blockhash: str) -> bytes:
    """Legacy System Program transfer, identical to solders' output."""
    to_pub = b58decode(to_address)
    if len(to_pub) != 32:
        raise ValueError("Invalid destination address")
    system_id = bytes(32)
    blockhash = b58decode(recent_blockhash)
    if len(blockhash) != 32:
        raise ValueError("Invalid blockhash")
    if to_pub == keypair.pubkey_bytes:
        raise ValueError("Payout address is the trading wallet itself")
    header = bytes([1, 0, 1])  # 1 signer, 0 ro-signed, 1 ro-unsigned (system)
    keys = encode_compact_u16(3) + keypair.pubkey_bytes + to_pub + system_id
    data = struct.pack("<IQ", 2, int(lamports))
    ix = bytes([2]) + encode_compact_u16(2) + bytes([0, 1]) + encode_compact_u16(len(data)) + data
    message = header + keys + blockhash + encode_compact_u16(1) + ix
    return encode_compact_u16(1) + keypair.sign(message) + message


class SolanaRPC:
    """Tiny JSON-RPC client with automatic fail-over across endpoints."""

    def __init__(self, urls: List[str]):
        self.urls = list(urls)
        self.index = 0
        self.session = requests.Session()
        self.session.headers.update({"Content-Type": "application/json"})
        self._id = 0
        self.lock = threading.Lock()

    @property
    def url(self) -> str:
        return self.urls[self.index]

    def switch(self) -> None:
        self.index = (self.index + 1) % len(self.urls)
        logger.warning(f"Switching to RPC endpoint {self.index + 1}/{len(self.urls)}: {self.url}")

    def call(self, method: str, params: list = None, timeout: int = 20) -> Any:
        last_err = None
        for _ in range(len(self.urls)):
            with self.lock:
                self._id += 1
                req_id = self._id
                url = self.url
            try:
                r = self.session.post(url, json={
                    "jsonrpc": "2.0", "id": req_id, "method": method, "params": params or []
                }, timeout=timeout)
                if r.status_code == 429 or r.status_code >= 500:
                    raise RuntimeError(f"RPC HTTP {r.status_code}")
                body = r.json()
                if "error" in body:
                    err = body["error"]
                    # Program/transaction errors are real failures - don't fail-over
                    raise SolanaRPCError(err.get("message", str(err)), err)
                return body.get("result")
            except SolanaRPCError:
                raise
            except Exception as e:
                last_err = e
                with self.lock:
                    self.switch()
        raise RuntimeError(f"All RPC endpoints failed for {method}: {last_err}")

    def get_balance(self, pubkey: str) -> int:
        return int(self.call("getBalance", [pubkey, {"commitment": "confirmed"}])["value"])

    def get_latest_blockhash(self) -> str:
        return self.call("getLatestBlockhash", [{"commitment": "finalized"}])["value"]["blockhash"]

    def send_transaction(self, raw_tx: bytes, skip_preflight: bool = False) -> str:
        return self.call("sendTransaction", [
            base64.b64encode(raw_tx).decode(),
            {"encoding": "base64", "skipPreflight": skip_preflight,
             "preflightCommitment": "confirmed", "maxRetries": 3},
        ])

    def get_signature_status(self, signature: str) -> Optional[Dict]:
        res = self.call("getSignatureStatuses", [[signature], {"searchTransactionHistory": False}])
        vals = (res or {}).get("value") or [None]
        return vals[0]

    def get_token_supply(self, mint: str) -> Dict:
        return self.call("getTokenSupply", [mint])["value"]

    def get_token_balance(self, owner: str, mint: str) -> Tuple[int, int]:
        """Returns (raw_amount, decimals) summed over all token accounts for the mint."""
        res = self.call("getTokenAccountsByOwner", [
            owner, {"mint": mint}, {"encoding": "jsonParsed", "commitment": "confirmed"}
        ])
        total, decimals = 0, None
        for acc in (res or {}).get("value", []):
            try:
                info = acc["account"]["data"]["parsed"]["info"]["tokenAmount"]
                total += int(info["amount"])
                decimals = int(info["decimals"])
            except Exception:
                continue
        return total, (decimals if decimals is not None else -1)


class SolanaRPCError(Exception):
    def __init__(self, message: str, payload: Any = None):
        super().__init__(message)
        self.payload = payload


# ============================================================
# WALLET MANAGER
# ------------------------------------------------------------
# Encrypts the private key at rest with a password-derived key
# (PBKDF2 -> Fernet). The key is only ever decrypted in memory,
# never logged, never transmitted anywhere by this app.
# ============================================================

class WalletManager:

    def __init__(self, session_timeout_min: int = 30):
        self.keypair: Optional[SolKeypair] = None
        self._unlock_time: Optional[float] = None
        self.session_timeout_min = session_timeout_min

    @staticmethod
    def _derive_key(password, salt):
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=390_000,
        )
        return base64.urlsafe_b64encode(
            kdf.derive(password.encode())
        )

    def save_private_key(self, private_key_text, password):
        if not CRYPTO_AVAILABLE:
            raise RuntimeError(
                "The 'cryptography' package is required to store a wallet key."
            )

        # Validate BEFORE saving so a typo is caught now, not at unlock time.
        keypair = parse_private_key(private_key_text)

        salt = os.urandom(16)
        fkey = self._derive_key(password, salt)
        token = Fernet(fkey).encrypt(private_key_text.strip().encode())

        tmp = WALLET_FILE + ".tmp"
        with open(tmp, "wb") as f:
            f.write(salt + b"::" + token)
        os.replace(tmp, WALLET_FILE)

        try:
            os.chmod(WALLET_FILE, 0o600)
        except Exception:
            pass  # not supported on every filesystem (e.g. some Android storage)

        return keypair.pubkey()

    def unlock(self, password):
        if not CRYPTO_AVAILABLE:
            raise RuntimeError(
                "The 'cryptography' package is required to unlock the wallet."
            )

        if not os.path.exists(WALLET_FILE):
            raise RuntimeError("No wallet key has been saved yet.")

        with open(WALLET_FILE, "rb") as f:
            raw = f.read()

        try:
            salt, token = raw.split(b"::", 1)
        except ValueError:
            raise RuntimeError("Wallet file is corrupted. Clear it and save the key again.")
        fkey = self._derive_key(password, salt)

        try:
            private_key_text = Fernet(fkey).decrypt(token).decode()
        except InvalidToken:
            raise RuntimeError("Wrong password.")

        self.keypair = parse_private_key(private_key_text)
        self._unlock_time = time.time()

        logger.info(f"Wallet unlocked: {self.pubkey()}")
        AuditLogger.log_action("wallet_unlocked", {"pubkey": self.pubkey()})

        return self.keypair.pubkey()

    def is_session_valid(self) -> bool:
        """Check if the wallet session is still valid (not timed out)."""
        if self._unlock_time is None:
            return False
        elapsed_min = (time.time() - self._unlock_time) / 60
        if elapsed_min > self.session_timeout_min:
            self.keypair = None
            self._unlock_time = None
            logger.warning("Wallet session timed out")
            return False
        return True

    def extend_session(self) -> None:
        """Extend the current session timeout."""
        if self._unlock_time is not None:
            self._unlock_time = time.time()

    def has_saved_key(self):
        return os.path.exists(WALLET_FILE)

    def lock(self):
        self.keypair = None
        self._unlock_time = None

    def clear(self):
        self.lock()
        if os.path.exists(WALLET_FILE):
            os.remove(WALLET_FILE)

    def pubkey(self):
        return self.keypair.pubkey() if self.keypair else None


# ============================================================
# LIVE TRADER (Jupiter swaps on Solana)
# ------------------------------------------------------------
# Handles real on-chain swaps and SOL transfers. Every method
# fails loudly (raises) rather than silently - a live trading
# path should never guess. All methods are blocking and are only
# ever called from worker threads, never from the GUI thread.
# ============================================================

class LiveTrader:

    def __init__(self, wallet_manager, rpc_urls: List[str] = None):
        self.wallet = wallet_manager
        self.rpc = SolanaRPC(rpc_urls or SOLANA_RPC_URLS)
        self.rate_limiter = RateLimiter(max_calls=120, time_window=60)
        self.circuit_breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=60)
        # Quotes go stale within seconds; keep the cache very short and
        # bypass it entirely for anything that will actually execute.
        self.request_cache = RequestCache(ttl=5)
        self.decimals_cache: Dict[str, int] = {}
        self.metrics = PerformanceMetrics()
        self.jupiter_api_key = ""

    @property
    def rpc_url(self) -> str:
        return self.rpc.url

    def _jup_urls(self) -> Tuple[str, str, Dict[str, str]]:
        if self.jupiter_api_key:
            return ("https://api.jup.ag/swap/v1/quote", "https://api.jup.ag/swap/v1/swap",
                    {"x-api-key": self.jupiter_api_key})
        return JUPITER_QUOTE_URL, JUPITER_SWAP_URL, {}

    @retry_with_backoff(max_retries=3, base_delay=1.0)
    def _call_with_protection(self, func: Callable, *args, **kwargs) -> Any:
        """Execute a function with rate limiting and circuit breaker protection."""
        self.rate_limiter.acquire(block=True, timeout=30)
        return self.circuit_breaker.call(func, *args, **kwargs)

    def _require_ready(self):
        if not CRYPTO_AVAILABLE:
            raise RuntimeError(
                "Live trading requires the 'cryptography' package (pip install cryptography)."
            )
        if not self.wallet.keypair:
            raise RuntimeError("Wallet is locked. Unlock it in Settings first.")

    def get_sol_balance(self) -> float:
        self._require_ready()
        start_time = time.time()
        try:
            lamports = self._call_with_protection(self.rpc.get_balance, self.wallet.pubkey())
            self.metrics.record("get_sol_balance_duration", time.time() - start_time)
            self.metrics.record("get_sol_balance_success", 1)
            return lamports / LAMPORTS_PER_SOL
        except Exception as e:
            self.metrics.record("get_sol_balance_success", 0)
            logger.error(f"Failed to get SOL balance: {e}")
            raise

    def get_token_decimals(self, mint: str) -> int:
        if mint == SOL_MINT:
            return 9
        if mint in self.decimals_cache:
            return self.decimals_cache[mint]
        info = self._call_with_protection(self.rpc.get_token_supply, mint)
        dec = int(info["decimals"])
        self.decimals_cache[mint] = dec
        return dec

    def get_token_balance(self, mint: str) -> Tuple[int, int]:
        """On-chain (raw_amount, decimals) of `mint` held by the wallet."""
        self._require_ready()
        raw, dec = self._call_with_protection(self.rpc.get_token_balance, self.wallet.pubkey(), mint)
        if dec >= 0:
            self.decimals_cache[mint] = dec
        return raw, dec

    def get_quote(self, input_mint: str, output_mint: str, amount_lamports: int,
                  slippage_bps: int = DEFAULT_SLIPPAGE_BPS, use_cache: bool = True) -> Dict[str, Any]:

        cache_key = f"quote_{input_mint}_{output_mint}_{amount_lamports}_{slippage_bps}"
        if use_cache:
            cached = self.request_cache.get(cache_key)
            if cached:
                return cached

        quote_url, _swap_url, headers = self._jup_urls()
        params = {
            "inputMint": input_mint,
            "outputMint": output_mint,
            "amount": int(amount_lamports),
            "slippageBps": int(slippage_bps),
            "restrictIntermediateTokens": "true",
        }

        start_time = time.time()
        try:
            response = self._call_with_protection(
                requests.get, quote_url, params=params, headers=headers, timeout=15
            )
            if response.status_code >= 400:
                try:
                    msg = response.json().get("error") or response.text[:200]
                except Exception:
                    msg = response.text[:200]
                raise RuntimeError(f"Jupiter quote HTTP {response.status_code}: {msg}")
            result = response.json()
            if "error" in result:
                raise RuntimeError(f"Jupiter quote error: {result['error']}")
            self.request_cache.set(cache_key, result)
            self.metrics.record("get_quote_duration", time.time() - start_time)
            self.metrics.record("get_quote_success", 1)
            return result
        except Exception as e:
            self.metrics.record("get_quote_success", 0)
            logger.error(f"Failed to get quote: {e}")
            raise

    def build_swap_transaction(self, quote: Dict[str, Any]) -> str:

        self._require_ready()
        _quote_url, swap_url, headers = self._jup_urls()

        body = {
            "quoteResponse": quote,
            "userPublicKey": self.wallet.pubkey(),
            "wrapAndUnwrapSol": True,
            "dynamicComputeUnitLimit": True,
            "dynamicSlippage": False,
            "prioritizationFeeLamports": {
                "priorityLevelWithMaxLamports": {
                    "maxLamports": 1_000_000,
                    "priorityLevel": "high",
                }
            },
        }

        start_time = time.time()
        try:
            response = self._call_with_protection(
                requests.post, swap_url, json=body, headers=headers, timeout=20
            )
            if response.status_code >= 400:
                raise RuntimeError(f"Jupiter swap HTTP {response.status_code}: {response.text[:200]}")
            data = response.json()
            if "swapTransaction" not in data:
                raise RuntimeError(f"Jupiter swap error: {data.get('error', data)}")
            self.metrics.record("build_swap_duration", time.time() - start_time)
            self.metrics.record("build_swap_success", 1)
            return data["swapTransaction"]
        except Exception as e:
            self.metrics.record("build_swap_success", 0)
            logger.error(f"Failed to build swap transaction: {e}")
            raise

    def sign_and_send(self, swap_transaction_b64: str) -> str:

        self._require_ready()

        raw = base64.b64decode(swap_transaction_b64)
        signed = sign_versioned_transaction(raw, self.wallet.keypair)

        start_time = time.time()
        try:
            # Not wrapped in retry: re-sending a signed tx is safe, but a
            # preflight failure should surface immediately.
            signature = self.rpc.send_transaction(signed, skip_preflight=False)
            self.metrics.record("sign_and_send_duration", time.time() - start_time)
            self.metrics.record("sign_and_send_success", 1)
            logger.info(f"Transaction sent: {signature[:12]}...")
            return signature
        except Exception as e:
            self.metrics.record("sign_and_send_success", 0)
            logger.error(f"Failed to sign and send transaction: {e}")
            raise

    def confirm_transaction(self, signature: str, timeout_s: float = 45.0) -> bool:
        """Poll until the tx is confirmed. Raises if it failed on-chain."""
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            try:
                status = self.rpc.get_signature_status(signature)
            except SolanaRPCError:
                status = None
            except Exception:
                status = None
            if status:
                if status.get("err"):
                    raise RuntimeError(f"Transaction failed on-chain: {status['err']}")
                if status.get("confirmationStatus") in ("confirmed", "finalized"):
                    return True
            time.sleep(1.5)
        return False

    def swap(self, input_mint: str, output_mint: str, amount_lamports: int,
             slippage_bps: int = DEFAULT_SLIPPAGE_BPS, confirm: bool = True) -> Tuple[str, Dict[str, Any]]:
        """Full quote -> build -> sign -> send (-> confirm) pipeline."""

        start_time = time.time()
        try:
            quote = self.get_quote(input_mint, output_mint, amount_lamports,
                                   slippage_bps, use_cache=False)
            swap_tx = self.build_swap_transaction(quote)
            signature = self.sign_and_send(swap_tx)

            if confirm and not self.confirm_transaction(signature):
                raise RuntimeError(
                    f"Transaction {signature[:12]}... not confirmed in time - check an explorer."
                )

            self.metrics.record("swap_total_duration", time.time() - start_time)
            self.metrics.record("swap_success", 1)

            AuditLogger.log_action("swap_executed", {
                "input_mint": input_mint[:8] + "...",
                "output_mint": output_mint[:8] + "...",
                "amount_raw": int(amount_lamports),
                "signature": signature,
            })

            return signature, quote
        except Exception as e:
            self.metrics.record("swap_success", 0)
            logger.error(f"Swap failed: {e}")
            raise

    def send_sol(self, to_address: str, amount_sol: float) -> str:
        """Used to sweep realized profit to a separate payout wallet."""

        self._require_ready()

        if not validate_solana_address(to_address):
            raise ValueError(f"Invalid Solana address: {to_address}")

        lamports = int(amount_sol * LAMPORTS_PER_SOL)
        if lamports <= 0:
            raise ValueError("Amount too small")

        start_time = time.time()
        try:
            blockhash = self._call_with_protection(self.rpc.get_latest_blockhash)
            tx = build_sol_transfer_tx(self.wallet.keypair, to_address, lamports, blockhash)
            signature = self.rpc.send_transaction(tx, skip_preflight=False)

            self.metrics.record("send_sol_duration", time.time() - start_time)
            self.metrics.record("send_sol_success", 1)

            AuditLogger.log_action("sol_transfer", {
                "to_address": to_address[:8] + "...",
                "amount_sol": amount_sol,
                "signature": signature,
            })

            logger.info(f"SOL transfer sent: {signature[:12]}...")
            return signature
        except Exception as e:
            self.metrics.record("send_sol_success", 0)
            logger.error(f"Failed to send SOL: {e}")
            raise


# ============================================================
# ADVANCED ML SCORER - ENSEMBLE & ONLINE LEARNING
# ------------------------------------------------------------
# Multi-model ensemble with real-time learning, feature engineering,
# and performance tracking. Uses Random Forest, Gradient Boosting,
# and online SGD for high-speed adaptive trading.
# ============================================================

class OnlineLogisticRegression:
    """Pure-python online logistic regression (SGD).

    Used when scikit-learn/numpy are unavailable (e.g. the Android/iOS
    build) so the adaptive model still learns from every closed trade.
    """

    def __init__(self, n_features: int, lr: float = 0.05, l2: float = 1e-4):
        self.w = [0.0] * n_features
        self.b = 0.0
        self.lr = lr
        self.l2 = l2
        self.n = 0

    @staticmethod
    def _sigmoid(z: float) -> float:
        if z >= 0:
            return 1.0 / (1.0 + math.exp(-z))
        ez = math.exp(z)
        return ez / (1.0 + ez)

    def predict_proba(self, x: List[float]) -> float:
        if len(x) != len(self.w):
            return 0.5
        return self._sigmoid(sum(wi * xi for wi, xi in zip(self.w, x)) + self.b)

    def partial_fit(self, x: List[float], y: int) -> None:
        if len(x) != len(self.w):
            self.w = [0.0] * len(x)
        err = self.predict_proba(x) - y
        self.w = [wi - self.lr * (err * xi + self.l2 * wi) for wi, xi in zip(self.w, x)]
        self.b -= self.lr * err
        self.n += 1


class AdvancedMLScorer:

    # Extended feature set for better pattern recognition
    FEATURES = [
        "liquidity", "volume", "txns", "buy_ratio",
        "change_1h", "change_6h", "change_24h", "age_hours",
        "volume_liquidity_ratio", "txn_volume_ratio", "momentum_score",
        "volatility_score", "liquidity_trend", "volume_trend"
    ]

    MIN_SAMPLES_TO_PREDICT = 20
    MIN_SAMPLES_TO_TRAIN_ENSEMBLE = 100

    def __init__(self):
        self.lock = threading.RLock()
        self.models = {}
        self.samples_seen = 0
        self.wins = 0
        self.losses = 0
        self.sklearn = ML_AVAILABLE
        # The adaptive model is ALWAYS available now (pure-python fallback)
        self.enabled = True
        self.online = OnlineLogisticRegression(len(self.FEATURES))
        self.feature_history = deque(maxlen=10000)  # Keep last 10k samples
        self.outcome_history = deque(maxlen=10000)
        self.performance_history = deque(maxlen=100)  # Track recent performance
        self.model_weights = {"rf": 0.4, "gb": 0.4, "sgd": 0.2}  # Ensemble weights
        self._load()

        if self.sklearn and not self.models:
            self._initialize_models()

    @property
    def backend(self) -> str:
        return "scikit-learn ensemble" if self.sklearn else "online logistic (built-in)"

    def _initialize_models(self):
        """Initialize all models in the ensemble."""
        if not self.sklearn:
            return

        # Random Forest - good for capturing complex patterns
        self.models["rf"] = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            min_samples_split=5,
            random_state=42,
            n_jobs=1 if IS_MOBILE else -1
        )

        # Gradient Boosting - sequential learning for refinement
        self.models["gb"] = GradientBoostingClassifier(
            n_estimators=50,
            max_depth=5,
            learning_rate=0.1,
            random_state=42
        )

        # SGD - online learning for real-time updates
        self.models["sgd"] = SGDClassifier(
            loss="log_loss",
            random_state=42
        )

        logger.info("Advanced ML models initialized")

    @staticmethod
    def _is_fitted(model) -> bool:
        return hasattr(model, "classes_")

    def _engineer_features(self, token: Dict[str, Any]) -> List[float]:
        """Engineer features from raw token data (already normalized to ~[0,1]).

        Scaling is intentionally NOT applied: the original called
        scaler.fit_transform() on a single sample, which turns every
        feature into 0 and made the models useless.
        """
        liquidity = float(token.get("liquidity", 0) or 0)
        volume = float(token.get("volume", 0) or 0)
        txns = int(token.get("txns", 0) or 0)
        buys = int(token.get("buys", 0) or 0)
        change_1h = float(token.get("change_1h", 0) or 0)
        change_6h = float(token.get("change_6h", 0) or 0)
        change_24h = float(token.get("change_24h", 0) or 0)
        age_hours = float(token.get("age_hours", 999) or 999)

        # Basic ratios
        buy_ratio = buys / txns if txns > 0 else 0
        volume_liquidity_ratio = volume / liquidity if liquidity > 0 else 0
        txn_volume_ratio = txns / volume if volume > 0 else 0

        # Momentum score (weighted recent price changes)
        momentum_score = (change_1h * 0.5 + change_6h * 0.3 + change_24h * 0.2)

        # Volatility score (standard deviation approximation)
        volatility_score = abs(change_1h - change_6h) + abs(change_6h - change_24h)

        # Trend indicators (simple)
        liquidity_trend = 1 if liquidity > 100000 else 0
        volume_trend = 1 if volume > 50000 else 0

        return [
            min(liquidity, 2_000_000) / 2_000_000,
            min(volume, 2_000_000) / 2_000_000,
            min(txns, 5000) / 5000,
            buy_ratio,
            math.tanh(change_1h / 50),
            math.tanh(change_6h / 100),
            math.tanh(change_24h / 200),
            min(age_hours, 500) / 500,
            min(volume_liquidity_ratio, 10) / 10,
            min(txn_volume_ratio, 0.01) / 0.01,
            math.tanh(momentum_score / 50),
            min(volatility_score, 100) / 100,
            liquidity_trend,
            volume_trend,
        ]

    def _vectorize(self, token: Dict[str, Any]):
        features = self._engineer_features(token)
        if self.sklearn:
            return np.array(features, dtype=float).reshape(1, -1)
        return features

    def record_outcome(self, token: Dict[str, Any], won: bool) -> None:
        """Record trade outcome and update models in real-time."""
        if not self.enabled:
            return

        with self.lock:
            features = self._engineer_features(token)
            y = 1 if won else 0

            self.feature_history.append(features)
            self.outcome_history.append(y)

            self.samples_seen += 1
            if won:
                self.wins += 1
            else:
                self.losses += 1

            # deque(maxlen=100) trims itself
            self.performance_history.append(y)

            # Pure-python online model always learns
            self.online.partial_fit(features, y)

            if self.sklearn:
                try:
                    X = np.array(features, dtype=float).reshape(1, -1)
                    self.models["sgd"].partial_fit(X, [y], classes=np.array([0, 1]))
                except Exception as e:
                    logger.warning(f"SGD partial fit failed: {e}")

                if (self.samples_seen >= self.MIN_SAMPLES_TO_TRAIN_ENSEMBLE
                        and self.samples_seen % 25 == 0):
                    self._retrain_ensemble()

            self._adjust_weights()

        self._save()

    def _retrain_ensemble(self) -> None:
        """Retrain ensemble models with accumulated data."""
        if not self.sklearn or len(self.feature_history) < 50:
            return
        y_batch = np.array(list(self.outcome_history))
        if len(set(y_batch.tolist())) < 2:
            return  # need both classes to fit a classifier
        try:
            X_batch = np.array(list(self.feature_history), dtype=float)
            self.models["rf"].fit(X_batch, y_batch)
            self.models["gb"].fit(X_batch, y_batch)
            logger.info(f"Ensemble retrained with {len(X_batch)} samples")
        except Exception as e:
            logger.error(f"Ensemble retraining failed: {e}")

    def _adjust_weights(self) -> None:
        """Adjust ensemble weights based on recent performance."""
        if len(self.performance_history) < 20:
            return

        recent_win_rate = sum(self.performance_history) / len(self.performance_history)

        if recent_win_rate < 0.4:
            self.model_weights["sgd"] = min(0.5, self.model_weights["sgd"] + 0.05)
            self.model_weights["rf"] = max(0.2, self.model_weights["rf"] - 0.025)
            self.model_weights["gb"] = max(0.2, self.model_weights["gb"] - 0.025)
        elif recent_win_rate > 0.6:
            self.model_weights["rf"] = min(0.5, self.model_weights["rf"] + 0.025)
            self.model_weights["gb"] = min(0.5, self.model_weights["gb"] + 0.025)
            self.model_weights["sgd"] = max(0.1, self.model_weights["sgd"] - 0.05)

        total = sum(self.model_weights.values())
        for key in self.model_weights:
            self.model_weights[key] /= total

    def predict_ensemble(self, token: Dict[str, Any]) -> Tuple[float, Dict[str, float]]:
        """Get ensemble prediction with individual model probabilities."""
        if not self.enabled or self.samples_seen < self.MIN_SAMPLES_TO_PREDICT:
            return 0.5, {}

        with self.lock:
            features = self._engineer_features(token)
            predictions: Dict[str, float] = {}
            try:
                if not self.sklearn:
                    p = self.online.predict_proba(features)
                    return p, {"online": p}

                X = np.array(features, dtype=float).reshape(1, -1)
                weights = {}
                for name in ("rf", "gb", "sgd"):
                    model = self.models.get(name)
                    if model is not None and self._is_fitted(model):
                        proba = model.predict_proba(X)[0]
                        classes = list(model.classes_)
                        predictions[name] = float(proba[classes.index(1)]) if 1 in classes else 0.0
                        weights[name] = self.model_weights[name]
                if not predictions:
                    p = self.online.predict_proba(features)
                    return p, {"online": p}
                total_w = sum(weights.values()) or 1.0
                ensemble = sum(predictions[k] * weights[k] for k in predictions) / total_w
                return ensemble, predictions
            except Exception as e:
                logger.error(f"Ensemble prediction failed: {e}")
                return 0.5, {}

    def adjust_score(self, token: Dict[str, Any], base_score: float) -> Tuple[float, Optional[float]]:
        """Blend ensemble prediction into the rule-based score."""
        if not self.enabled or self.samples_seen < self.MIN_SAMPLES_TO_PREDICT:
            return base_score, None

        try:
            ensemble_proba, _individual = self.predict_ensemble(token)

            base_weight = max(0.3, min(0.7, 1 - self.samples_seen / 1000))
            ml_weight = 1 - base_weight

            if len(self.performance_history) >= 20:
                recent_win_rate = sum(self.performance_history) / len(self.performance_history)
                if recent_win_rate > 0.6:
                    ml_weight = min(0.7, ml_weight + 0.1)
                elif recent_win_rate < 0.4:
                    ml_weight = max(0.3, ml_weight - 0.1)
                base_weight = 1 - ml_weight

            blended = base_score * base_weight + (ensemble_proba * 100) * ml_weight

            return int(max(0, min(100, round(blended)))), round(ensemble_proba * 100, 1)

        except Exception as e:
            logger.error(f"Score adjustment failed: {e}")
            return base_score, None

    def get_statistics(self) -> Dict[str, Any]:
        """Get current ML statistics."""
        with self.lock:
            win_rate = self.wins / self.samples_seen if self.samples_seen > 0 else 0
            recent = list(self.performance_history)
            recent_win_rate = sum(recent) / len(recent) if recent else 0

            return {
                "total_trades": self.samples_seen,
                "wins": self.wins,
                "losses": self.losses,
                "win_rate": win_rate,
                "recent_win_rate": recent_win_rate,
                "model_weights": self.model_weights.copy(),
                "recent_performance": recent,
                "backend": self.backend,
            }

    def _save(self) -> None:
        """Save model state to disk (atomic write)."""
        try:
            with self.lock:
                state = {
                    "version": 2,
                    "models": self.models if self.sklearn else {},
                    "online": {"w": self.online.w, "b": self.online.b, "n": self.online.n},
                    "samples_seen": self.samples_seen,
                    "wins": self.wins,
                    "losses": self.losses,
                    "model_weights": self.model_weights,
                    "feature_history": [list(map(float, f)) for f in self.feature_history],
                    "outcome_history": list(self.outcome_history),
                    "performance_history": list(self.performance_history),
                }
            tmp = ML_STATE_FILE + ".tmp"
            with open(tmp, "wb") as f:
                pickle.dump(state, f)
            os.replace(tmp, ML_STATE_FILE)
        except Exception as e:
            logger.error(f"Failed to save ML state: {e}")

    def _load(self) -> None:
        """Load model state from disk."""
        if not os.path.exists(ML_STATE_FILE):
            return
        try:
            with open(ML_STATE_FILE, "rb") as f:
                state = pickle.load(f)
        except Exception as e:
            # e.g. a desktop pickle with sklearn objects opened on mobile
            logger.error(f"Failed to load ML state: {e}")
            return
        try:
            if self.sklearn:
                models = state.get("models") or {}
                if all(k in models for k in ("rf", "gb", "sgd")):
                    self.models = models
            online = state.get("online")
            if online:
                self.online.w = list(online.get("w", self.online.w))
                self.online.b = float(online.get("b", 0.0))
                self.online.n = int(online.get("n", 0))
            self.samples_seen = int(state.get("samples_seen", 0))
            self.wins = int(state.get("wins", 0))
            self.losses = int(state.get("losses", 0))
            self.model_weights = state.get("model_weights", {"rf": 0.4, "gb": 0.4, "sgd": 0.2})
            self.feature_history = deque(
                [list(map(float, f)) for f in state.get("feature_history", [])], maxlen=10000)
            self.outcome_history = deque(state.get("outcome_history", []), maxlen=10000)
            self.performance_history = deque(state.get("performance_history", []), maxlen=100)
            # Older state files had no online model - warm it up from history
            if not online and self.feature_history:
                for f, y in zip(self.feature_history, self.outcome_history):
                    self.online.partial_fit(list(f), int(y))
            logger.info(f"ML model state loaded: {self.samples_seen} samples")
        except Exception as e:
            logger.error(f"Failed to restore ML state: {e}")


# Backward compatibility alias
MLScorer = AdvancedMLScorer


# ============================================================
# LISTING WATCHER
# ------------------------------------------------------------
# Flags tokens showing PUBLIC signals that sometimes precede a
# big-exchange listing (search/social trending + volume & buy
# acceleration). This is a heuristic on public data only - it has
# no access to and does not seek non-public listing information.
# ============================================================

class ListingWatcher:

    def __init__(self):
        self.session = requests.Session()

    def trending_symbols(self):
        """Best-effort public trending list. Returns a set of upper-case
        symbols, or an empty set if the source is unreachable."""

        try:
            response = self.session.get(TRENDING_URL, timeout=10)
            response.raise_for_status()
            data = response.json()

            symbols = set()
            for item in data.get("coins", []):
                symbol = item.get("item", {}).get("symbol", "")
                if symbol:
                    symbols.add(symbol.upper())

            return symbols

        except Exception:
            return set()

    def flag_candidates(self, tokens):
        """Given already-scored tokens, mark which ones show
        pre-listing-style public momentum."""

        trending = self.trending_symbols()

        flagged = []

        for token in tokens:

            reasons = []

            if token["symbol"].upper() in trending:
                reasons.append("Trending (public search data)")

            # Volume accelerating hard relative to liquidity, with strong
            # sustained buy pressure across multiple windows - the pattern
            # that often shows up before a token gets picked up by a
            # bigger venue.
            if (
                token["liquidity"] > 0
                and token["volume"] / token["liquidity"] > 3
                and token["buy_ratio"] > 0.6
                and token["change_1h"] > 5
                and token["change_6h"] > 15
            ):
                reasons.append("Volume/momentum acceleration")

            if reasons:
                flagged.append({**token, "listing_signals": reasons})

        return flagged


# ============================================================
# MARKET ENGINE
# ============================================================

class MarketEngine:

    def __init__(self, asset_class: str = "CRYPTO"):
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "VertexTerminal/2.0"
        })

        self.asset_class = asset_class
        self.asset_config = ASSET_CLASSES.get(asset_class, ASSET_CLASSES["CRYPTO"])

        # User-configurable thresholds - pushed from MainWindow whenever
        # the user clicks "SAVE SETTINGS". Defaults match the module
        # constants so behavior is unchanged until the user customizes.
        self.min_liquidity_usd = MIN_LIQUIDITY
        self.min_volume_usd = MIN_VOLUME
        self.min_txns = MIN_TXNS
        self.max_token_age_hours = 48      # 0 = no age cap; default = 2 days
        self.prioritize_new_memes = True
        self._rugcheck_cache = {}          # mint -> {ts, result}; 10-min TTL

        self.alphavantage_api_key = FOREX_API_KEY
        self.last_api_notice = ""
        self._long_cache: Dict[str, Tuple[Any, float]] = {}
        self._sol_usd: Tuple[float, float] = (0.0, 0.0)  # (price, timestamp)

        # New utilities. DexScreener allows ~300 req/min on the pairs
        # endpoints; we use batch calls so 60/min is plenty.
        self.rate_limiter = RateLimiter(max_calls=60, time_window=60)
        self.request_cache = RequestCache(ttl=20)
        self.metrics = PerformanceMetrics()
        self.data_stream = RealTimeDataStream()
        self.max_workers = 10  # Parallel processing workers

    def set_asset_class(self, asset_class: str) -> None:
        """Switch between asset classes (CRYPTO, FOREX, STOCK)."""
        self.asset_class = asset_class
        self.asset_config = ASSET_CLASSES.get(asset_class, ASSET_CLASSES["CRYPTO"])
        logger.info(f"Asset class switched to: {asset_class}")

    def get_json(self, url: str, timeout: int = 15, use_cache: bool = True,
                 params: Optional[Dict[str, Any]] = None,
                 ttl: Optional[float] = None) -> Optional[Any]:
        """Fetch JSON from URL with caching and rate limiting.

        (The original had no `params` argument even though the forex and
        stock paths passed one, so those always raised TypeError.)
        """
        cache_key = url + ("?" + json.dumps(params, sort_keys=True) if params else "")
        if use_cache:
            if ttl is not None:
                hit = self._long_cache.get(cache_key)
                if hit and time.time() - hit[1] < ttl:
                    return hit[0]
            else:
                cached = self.request_cache.get(cache_key)
                if cached:
                    return cached

        # Block (briefly) for a slot instead of firing anyway
        self.rate_limiter.acquire(block=True, timeout=20)

        start_time = time.time()
        try:
            response = self.session.get(url, params=params, timeout=timeout)
            response.raise_for_status()
            result = response.json()
            if use_cache:
                if ttl is not None:
                    self._long_cache[cache_key] = (result, time.time())
                else:
                    self.request_cache.set(cache_key, result)
            self.metrics.record("get_json_duration", time.time() - start_time)
            self.metrics.record("get_json_success", 1)
            return result
        except Exception as e:
            self.metrics.record("get_json_success", 0)
            logger.error(f"Failed to fetch JSON from {url}: {e}")
            return None

    def candidate_addresses(self) -> List[str]:
        """Get candidate token addresses from multiple sources in parallel."""
        if self.asset_class == "CRYPTO":
            return self._get_crypto_candidates()
        elif self.asset_class == "FOREX":
            return self._get_forex_pairs()
        elif self.asset_class == "STOCK":
            return self._get_stock_symbols()
        return []

    def _get_crypto_candidates(self) -> List[str]:
        """Get cryptocurrency token addresses."""
        addresses = []

        # Fetch from all sources in parallel
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            futures = [
                executor.submit(self.get_json, PROFILE_URL),
                executor.submit(self.get_json, BOOST_URL)
            ]

            for future in futures:
                try:
                    data = future.result(timeout=30)
                    if isinstance(data, list):
                        for item in data:
                            if item.get("chainId") == SOLANA:
                                address = item.get("tokenAddress")
                                if address:
                                    addresses.append(address)
                except Exception as e:
                    logger.error(f"Failed to fetch candidate addresses: {e}")

        # Remove duplicates
        return list(dict.fromkeys(addresses))

    def _get_forex_pairs(self) -> List[str]:
        """Get forex currency pairs."""
        # Major forex pairs
        pairs = [
            "EUR/USD", "GBP/USD", "USD/JPY", "USD/CHF",
            "AUD/USD", "USD/CAD", "NZD/USD", "EUR/GBP",
            "EUR/JPY", "GBP/JPY", "EUR/CHF", "GBP/CHF"
        ]
        return pairs

    def _get_stock_symbols(self) -> List[str]:
        """Get stock symbols for trading."""
        # Popular stocks (can be expanded)
        symbols = [
            "AAPL", "GOOGL", "MSFT", "AMZN", "TSLA",
            "META", "NVDA", "JPM", "V", "WMT"
        ]
        return symbols

    def get_pairs(self, address: str) -> List[Dict]:
        """Get trading pairs for a token address."""
        if self.asset_class == "CRYPTO":
            url = f"https://api.dexscreener.com/token-pairs/v1/solana/{address}"
            data = self.get_json(url)
            if isinstance(data, list):
                return data
        elif self.asset_class == "FOREX":
            return self._get_forex_data(address)
        elif self.asset_class == "STOCK":
            return self._get_stock_data(address)
        return []

    def get_pairs_batch(self, addresses: List[str]) -> Dict[str, List[Dict]]:
        """DexScreener batch endpoint: up to 30 token addresses per request."""
        grouped: Dict[str, List[Dict]] = {}
        chunks = [addresses[i:i + 30] for i in range(0, len(addresses), 30)]

        def fetch(chunk):
            url = "https://api.dexscreener.com/tokens/v1/solana/" + ",".join(chunk)
            return self.get_json(url) or []

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as ex:
            for data in ex.map(fetch, chunks):
                if not isinstance(data, list):
                    continue
                for pair in data:
                    addr = (pair.get("baseToken") or {}).get("address")
                    if addr:
                        grouped.setdefault(addr, []).append(pair)
        return grouped

    def _alphavantage(self, params: Dict[str, Any]) -> Optional[Dict]:
        key = self.alphavantage_api_key or "demo"
        data = self.get_json(FOREX_API_URL, params={**params, "apikey": key},
                             ttl=ALPHAVANTAGE_CACHE_TTL)
        if isinstance(data, dict):
            for k in ("Note", "Information", "Error Message"):
                if k in data:
                    self.last_api_notice = str(data[k])[:160]
                    # Don't keep the throttle message cached for an hour
                    self._long_cache.pop(
                        FOREX_API_URL + "?" + json.dumps({**params, "apikey": key}, sort_keys=True), None)
                    return None
        return data

    @staticmethod
    def _daily_to_pair(series: Dict[str, Dict[str, str]], ident: str, symbol: str,
                       liquidity: float, txns: Tuple[int, int]) -> List[Dict]:
        dates = sorted(series.keys(), reverse=True)[:7]
        if len(dates) < 2:
            return []
        closes = [float(series[d]["4. close"]) for d in dates]
        close, prev_close = closes[0], closes[1]
        change_24h = ((close - prev_close) / prev_close) * 100 if prev_close else 0
        change_week = ((close - closes[-1]) / closes[-1]) * 100 if closes[-1] else 0
        volume = float(series[dates[0]].get("5. volume", 0) or 0)
        if volume <= 0:
            volume = liquidity * 0.1  # FX_DAILY has no volume column
        return [{
            "pairAddress": ident,
            "baseToken": {"symbol": symbol, "name": ident, "address": ident},
            "quoteToken": {"symbol": "USD"},
            "priceUsd": close,
            "liquidity": {"usd": liquidity},
            "volume": {"h24": volume},
            "txns": {"h24": {"buys": txns[0], "sells": txns[1]}},
            "priceChange": {"h24": change_24h, "h1": change_24h / 24, "h6": change_week / 7},
            "pairCreatedAt": None,
        }]

    def _get_forex_data(self, pair: str) -> List[Dict]:
        """Get forex data for a currency pair."""
        try:
            base_ccy, quote_ccy = pair.split("/")
            data = self._alphavantage({
                "function": "FX_DAILY", "from_symbol": base_ccy, "to_symbol": quote_ccy,
            })
            # FX_DAILY uses this key (the original looked for "Time Series (Daily)")
            if data and "Time Series FX (Daily)" in data:
                return self._daily_to_pair(data["Time Series FX (Daily)"], pair, pair,
                                           1_000_000, (1000, 500))
        except Exception as e:
            logger.error(f"Failed to get forex data for {pair}: {e}")
        return []

    def _get_stock_data(self, symbol: str) -> List[Dict]:
        """Get stock data for a symbol."""
        try:
            data = self._alphavantage({"function": "TIME_SERIES_DAILY", "symbol": symbol})
            if data and "Time Series (Daily)" in data:
                return self._daily_to_pair(data["Time Series (Daily)"], symbol, symbol,
                                           10_000_000, (5000, 2500))
        except Exception as e:
            logger.error(f"Failed to get stock data for {symbol}: {e}")
        return []

    # --------------------------------------------------------
    # SOL / USD price (used to convert DexScreener USD prices into
    # SOL, which is the unit positions are sized and costed in)
    # --------------------------------------------------------
    def sol_usd_price(self, max_age: float = 60.0) -> float:
        price, ts = self._sol_usd
        if price > 0 and time.time() - ts < max_age:
            return price
        new_price = 0.0
        try:
            r = self.session.get("https://api.coingecko.com/api/v3/simple/price",
                                 params={"ids": "solana", "vs_currencies": "usd"}, timeout=8)
            if r.ok:
                new_price = float(r.json().get("solana", {}).get("usd", 0) or 0)
        except Exception:
            pass
        if new_price <= 0:
            try:
                data = self.get_json(f"https://api.dexscreener.com/tokens/v1/solana/{SOL_MINT}",
                                     use_cache=False) or []
                prices = sorted(
                    float(p.get("priceUsd") or 0) for p in data
                    if (p.get("baseToken") or {}).get("address") == SOL_MINT
                    and float((p.get("liquidity") or {}).get("usd", 0) or 0) > 100_000
                )
                prices = [p for p in prices if p > 0]
                if prices:
                    new_price = prices[len(prices) // 2]
            except Exception:
                pass
        if new_price > 0:
            self._sol_usd = (new_price, time.time())
            return new_price
        return price  # last known (may be 0 if never fetched)

    def price_in_sol(self, token: Dict[str, Any], allow_fetch: bool = True) -> float:
        """Token price denominated in SOL."""
        native = float(token.get("price_native", 0) or 0)
        if native > 0 and token.get("quote_symbol", "").upper() in ("SOL", "WSOL"):
            return native
        usd = float(token.get("price", 0) or 0)
        sol_usd = self.sol_usd_price() if allow_fetch else self._sol_usd[0]
        return usd / sol_usd if usd > 0 and sol_usd > 0 else 0.0

    def analyze_batch(self, addresses: List[str]) -> List[Dict]:
        """Analyze many tokens quickly.

        Crypto uses DexScreener's batch endpoint (30 tokens per call)
        instead of 200 single requests, which the old 30/min rate
        limiter made take several minutes and then time out.
        """
        results = []
        addresses = addresses[:200]

        if self.asset_class == "CRYPTO":
            grouped = self.get_pairs_batch(addresses)
            for address in addresses:
                pairs = grouped.get(address)
                if not pairs:
                    continue
                try:
                    pair = self.best_pair(pairs)
                    token = self.analyze(pair) if pair else None
                    if token:
                        results.append(token)
                except Exception as e:
                    logger.error(f"Failed to analyze {address}: {e}")
            return results

        # Forex / stocks: few symbols, Alpha Vantage is the bottleneck
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as executor:
            futures = {executor.submit(self._analyze_single, a): a for a in addresses}
            try:
                for future in concurrent.futures.as_completed(futures, timeout=90):
                    try:
                        result = future.result()
                        if result:
                            results.append(result)
                    except Exception as e:
                        logger.error(f"Failed to analyze {futures[future]}: {e}")
            except concurrent.futures.TimeoutError:
                logger.warning("Some symbols timed out; returning partial results")

        return results

    def _analyze_single(self, address: str) -> Optional[Dict]:
        """Analyze a single token (used in parallel processing)."""
        try:
            pairs = self.get_pairs(address)
            if not pairs:
                return None

            pair = self.best_pair(pairs)
            if not pair:
                return None

            token = self.analyze(pair)
            return token
        except Exception as e:
            logger.error(f"Error analyzing {address}: {e}")
            return None

    def best_pair(self, pairs):

        if not pairs:
            return None

        def liquidity_value(pair):
            try:
                return float(
                    pair.get("liquidity", {}).get("usd", 0) or 0
                )
            except Exception:
                return 0

        def volume_value(pair):
            try:
                return float(
                    pair.get("volume", {}).get("h24", 0) or 0
                )
            except Exception:
                return 0

        return max(
            pairs,
            key=lambda p: (
                liquidity_value(p) * 0.7
                + volume_value(p) * 0.3
            )
        )

    def analyze(self, pair):

        base = pair.get("baseToken", {})

        symbol = base.get("symbol", "UNKNOWN")
        name = base.get("name", symbol)
        address = base.get("address", "")

        try:
            price = float(pair.get("priceUsd", 0) or 0)
        except Exception:
            price = 0
        try:
            price_native = float(pair.get("priceNative", 0) or 0)
        except Exception:
            price_native = 0
        quote_symbol = (pair.get("quoteToken") or {}).get("symbol", "") or ""

        liquidity = float(
            pair.get("liquidity", {}).get("usd", 0) or 0
        )

        volume_24h = float(
            pair.get("volume", {}).get("h24", 0) or 0
        )

        txns = pair.get("txns", {}).get("h24", {})

        buys = int(txns.get("buys", 0) or 0)
        sells = int(txns.get("sells", 0) or 0)

        total_txns = buys + sells

        price_change = pair.get("priceChange", {})

        change_5m = float(price_change.get("m5", 0) or 0)
        change_1h = float(price_change.get("h1", 0) or 0)
        change_6h = float(price_change.get("h6", 0) or 0)
        change_24h = float(price_change.get("h24", 0) or 0)

        created_at = pair.get("pairCreatedAt")

        age_hours = 999

        if created_at:

            try:
                created_ms = int(created_at)

                current_ms = int(time.time() * 1000)

                age_hours = (
                    current_ms - created_ms
                ) / 1000 / 60 / 60

            except Exception:
                pass

        # ====================================================
        # AGE FILTER (skip tokens older than the user-configured cap)
        # ====================================================
        if (self.asset_class == "CRYPTO" and self.max_token_age_hours
                and age_hours > self.max_token_age_hours):
            return None

        # ====================================================
        # SCORING
        # ====================================================

        score = 0
        risk_flags = []

        # Liquidity (gates against the user-configured floor)
        if liquidity >= 500_000:
            score += 25
        elif liquidity >= 100_000:
            score += 20
        elif liquidity >= self.min_liquidity_usd:
            score += 12
        else:
            score -= 15
            risk_flags.append("LOW LIQUIDITY")

        # Volume
        if volume_24h >= 1_000_000:
            score += 20
        elif volume_24h >= 100_000:
            score += 15
        elif volume_24h >= self.min_volume_usd:
            score += 10
        else:
            score -= 10
            risk_flags.append("LOW VOLUME")

        # Transactions
        if total_txns >= 1000:
            score += 15
        elif total_txns >= 300:
            score += 10
        elif total_txns >= self.min_txns:
            score += 5
        else:
            score -= 10
            risk_flags.append("LOW ACTIVITY")

        # Buy pressure
        buy_ratio = 0
        if total_txns > 0:

            buy_ratio = buys / total_txns

            if buy_ratio >= 0.65:
                score += 15
            elif buy_ratio >= 0.55:
                score += 10
            elif buy_ratio >= 0.50:
                score += 5
            else:
                score -= 10
                risk_flags.append("SELL PRESSURE")

        # Momentum
        if change_1h > 10:
            score += 10
        elif change_1h > 0:
            score += 5
        elif change_1h < -15:
            score -= 10

        if change_6h > 20:
            score += 5

        # Age - heavy weight when "prioritize new memes" is on, because
        # the very-newest tokens are where most of the meme-coin upside
        # historically concentrates.
        if self.prioritize_new_memes:
            if age_hours < 1:
                score += 25    # just-launched
            elif age_hours < 6:
                score += 18    # same-day
            elif age_hours < 24:
                score += 12    # last 24h
            elif age_hours < 72:
                score += 6     # last 3 days
        else:
            if age_hours < 1:
                score += 5
            elif age_hours < 6:
                score += 3

        # Very old tokens aren't necessarily bad,
        # but we don't give them the new-token bonus.

        # Basic risk flags
        if liquidity < 10_000:
            risk_flags.append("VERY LOW LIQUIDITY")

        if volume_24h > liquidity * 20 and liquidity > 0:
            risk_flags.append("EXTREME VOLUME")

        if change_24h > 500:
            risk_flags.append("EXTREME PUMP")

        score = max(0, min(100, score))

        if score >= 80:
            risk = "LOWER"
        elif score >= 65:
            risk = "MEDIUM"
        else:
            risk = "HIGH"

        return {
            "name": name,
            "symbol": symbol,
            "address": address,
            "price": price,
            "price_native": price_native,
            "quote_symbol": quote_symbol,
            "asset_class": self.asset_class,
            "liquidity": liquidity,
            "volume": volume_24h,
            "buys": buys,
            "sells": sells,
            "txns": total_txns,
            "buy_ratio": buy_ratio,
            "change_5m": change_5m,
            "change_1h": change_1h,
            "change_6h": change_6h,
            "change_24h": change_24h,
            "age_hours": age_hours,
            "score": score,
            "risk": risk,
            "risk_flags": risk_flags,
            "pair_address": pair.get("pairAddress", ""),
            "url": pair.get("url", ""),
        }

    def rugcheck_verdict(self, mint: str) -> dict:
        """
        Calls RugCheck.xyz to detect on-chain dangers (mint/freeze authority,
        honeypots, unlocked LP, top-holder concentration).

        Returns {"safe": bool, "flags": list[str], "lp_locked_pct": float}.
        Fails OPEN on any network/parse error so API unavailability never
        silently blocks a trade; the absence of a result is logged instead.
        Results are cached for 10 minutes to avoid hammering the free API.
        """
        if self.asset_class != "CRYPTO" or len(mint) < 32:
            return {"safe": True, "flags": [], "lp_locked_pct": 100.0}
        now = time.time()
        cached = self._rugcheck_cache.get(mint)
        if cached and (now - cached["ts"]) < 600:
            return cached["result"]

        result = {"safe": True, "flags": [], "lp_locked_pct": 100.0}
        try:
            url = f"https://api.rugcheck.xyz/v1/tokens/{mint}/report/summary"
            resp = self.session.get(url, timeout=6)
            if resp.status_code == 200:
                data = resp.json()
                danger_flags = []
                for risk in data.get("risks", []):
                    if risk.get("level") == "danger":
                        name = risk.get("name", "").strip()
                        if name:
                            danger_flags.append(name.upper())
                lp_pct = float(data.get("lpLockedPct") or 0)
                if lp_pct < 50:
                    danger_flags.append(f"LP {lp_pct:.0f}% LOCKED")
                result = {
                    "safe": len(danger_flags) == 0,
                    "flags": danger_flags,
                    "lp_locked_pct": lp_pct,
                }
        except Exception:
            pass  # fail open — treat as safe when API is unreachable

        self._rugcheck_cache[mint] = {"ts": now, "result": result}
        return result


# ============================================================
# SCANNER THREAD
# ============================================================

class ScannerThread(QThread):

    results_ready = Signal(list)
    status = Signal(str)

    def __init__(self, engine, interval=60, enricher: Optional[Callable] = None):
        super().__init__()

        self.engine = engine
        self.interval = interval
        self.running = True
        # Optional callable(list) -> list run in THIS thread so sentiment,
        # ML scoring and listing lookups never block the GUI.
        self.enricher = enricher
        self._wake = threading.Event()

    def scan_now(self):
        self._wake.set()

    def run(self):

        while self.running:

            started = time.time()
            asset_name = ASSET_CLASSES.get(self.engine.asset_class, {}).get("name", self.engine.asset_class)

            try:

                self.status.emit(f"Scanning {asset_name} markets...")

                addresses = self.engine.candidate_addresses()

                results = self.engine.analyze_batch(addresses)

                if self.enricher and results:
                    try:
                        results = self.enricher(results)
                    except Exception as e:
                        logger.error(f"Enrichment failed: {e}")

                results.sort(
                    key=lambda x: x["score"],
                    reverse=True
                )

                if self.running:
                    self.results_ready.emit(results)

                note = ""
                if self.engine.asset_class != "CRYPTO" and self.engine.last_api_notice and not results:
                    note = " • Alpha Vantage limit/key issue - add your API key in Settings"
                self.status.emit(
                    f"Scan complete • {len(results)} candidates • {time.time() - started:.2f}s{note}"
                )

            except Exception as e:

                self.status.emit(
                    f"Scanner error: {e}"
                )

            self._wake.clear()
            for _ in range(int(self.interval)):

                if not self.running or self._wake.is_set():
                    break

                self._wake.wait(1)

    def stop(self):

        self.running = False
        self._wake.set()


# ============================================================
# STAT CARD
# ============================================================

class StatCard(QFrame):

    def __init__(self, title, value="0", accent=None):

        super().__init__()

        self.setObjectName("StatCard")

        self.accent = accent or TEXT

        self.setStyleSheet(
            f"#StatCard {{"
            f" background:{CARD};"
            f" border:1px solid #1e2833;"
            f" border-top:3px solid {self.accent};"
            f" border-radius:12px;"
            f"}}"
        )

        layout = QVBoxLayout(self)

        layout.setContentsMargins(18, 16, 18, 18)

        layout.setSpacing(6)

        self.title = QLabel(title)
        self.title.setStyleSheet(
            f"color:{MUTED}; font-size:11px; font-weight:700;"
        )

        self.value = QLabel(value)
        self._apply_value_style(self.accent)

        layout.addWidget(self.title)
        layout.addWidget(self.value)

    def _apply_value_style(self, color):
        self._color = color
        size = 18 if getattr(self, "_compact", False) else 24
        self.value.setStyleSheet(
            f"""
            color:{color};
            font-size:{size}px;
            font-weight:800;
            """
        )

    def set_value_color(self, color):
        self._apply_value_style(color)

    def set_compact(self, compact: bool) -> None:
        self._compact = compact
        self.layout().setContentsMargins(*((12, 10, 12, 12) if compact else (18, 16, 18, 18)))
        self._apply_value_style(getattr(self, "_color", self.accent))


# ============================================================
# MAIN WINDOW
# ============================================================

class UiBridge(QObject):
    """Runs callables on the GUI thread (Qt widgets are not thread-safe)."""

    invoke = Signal(object)

    def __init__(self):
        super().__init__()
        self.invoke.connect(self._run, Qt.QueuedConnection)

    @staticmethod
    def _run(fn):
        try:
            fn()
        except Exception as e:
            logger.error(f"UI callback failed: {e}")


def _scroll_touch(widget) -> None:
    """Kinetic finger scrolling for scroll areas / tables on phones."""
    if not IS_MOBILE or widget is None:
        return
    try:
        target = widget.viewport() if hasattr(widget, "viewport") else widget
        QScroller.grabGesture(target, QScroller.LeftMouseButtonGesture)
    except Exception:
        pass


class MainWindow(QMainWindow):

    # Columns hidden on phones (index lists per table) so the most
    # important information fits on a ~390px wide screen. Tap a row to
    # see every field.
    COMPACT_HIDDEN_COLUMNS = {
        # Hidden columns are still one tap away in the row details sheet.
        "dashboard": [2, 3, 6],                # Liquidity, Volume, Risk
        "scanner": [1, 2, 3, 4, 5, 7, 9],      # Price, Liq, 24H Vol, Buys, Sells, 24H, Risk
        "portfolio": [1, 2, 3],                # Entry, Current, Amount
        "history": [0, 3],                     # Time, Price
        "listing": [2, 3, 5],                  # Liquidity, Volume, Signals
    }

    ACTION_COLUMN_WIDTH = 88

    PAGE_TITLES = ["Dashboard", "Market Scanner", "Paper Portfolio", "Listing Watch", "Settings"]

    def __init__(self):

        super().__init__()

        self.setWindowTitle(
            "Vertex Terminal • AI-Powered Trading"
        )

        self._fit_to_screen(1400, 850)

        self.ui_bridge = UiBridge()
        self._gui_thread = threading.current_thread()
        self.state_lock = threading.RLock()

        # Load configuration first so the engine starts with the user's filters
        self.config = Config.load()

        self.engine = MarketEngine(asset_class="CRYPTO")

        # Portfolio. Each asset class has its own simulated balance:
        # SOL for crypto, USD for forex / stocks.
        self.asset_class = "CRYPTO"  # Default to crypto
        self.balances: Dict[str, float] = {
            "CRYPTO": STARTING_BALANCE_SOL,
            "FOREX": STARTING_BALANCE_USD,
            "STOCK": STARTING_BALANCE_USD,
        }
        self.positions: Dict[str, Dict[str, Any]] = {}
        self.trade_history: List[Dict[str, Any]] = []
        self._pending_buys: set = set()

        self.results = []
        self.listing_candidates = []
        self._row_tokens: Dict[str, List[Any]] = {}

        self.position_size = DEFAULT_POSITION_SIZE
        self.buy_score = self.config.buy_score
        self.scan_interval = self.config.scan_interval

        self.scanner = None

        # ---------------- Live trading state ----------------
        self.live_mode = False
        self.wallet_manager = WalletManager(session_timeout_min=self.config.wallet_session_timeout_min)
        self.live_trader = LiveTrader(self.wallet_manager)
        self.live_trader.jupiter_api_key = self.config.jupiter_api_key
        self.ml_scorer = MLScorer()
        self.rl_agent = ReinforcementLearningAgent()
        self.rl_agent.load(RL_STATE_FILE)
        self.sentiment_analyzer = SentimentAnalyzer()
        self.listing_watcher = ListingWatcher()
        self.trade_queue = PriorityTradeQueue()
        self.trade_queue.start_worker()

        self.payout_address = self.config.payout_address
        self.profit_withdraw_pct = self.config.profit_withdraw_pct
        self.max_live_position_sol = MAX_LIVE_POSITION_SOL
        self.live_position_size_sol = self.config.live_position_size_sol
        self.usd_position_size = self.config.usd_position_size
        self.sol_price_usd = 0.0
        self.auto_trade = self.config.auto_trade
        self._autopilot_running = False
        self.max_open_live_positions = self.config.max_open_live_positions
        self.max_daily_loss_sol = self.config.max_daily_loss_sol
        self.daily_realized_pnl_sol = 0.0
        self.daily_reset_date = datetime.now().date()

        # ---------------- User-configurable trading rules ----------------
        # Take-profit / stop-loss are fractions (0.30 = +30 %, -0.15 = -15 %)
        # but the UI shows them as %.
        self.take_profit = self.config.take_profit
        self.stop_loss = self.config.stop_loss
        self.prioritize_new_memes = self.config.prioritize_new_memes
        self.max_token_age_hours = self.config.max_token_age_hours
        self.min_liquidity_usd = self.config.min_liquidity_usd
        self.min_volume_usd = self.config.min_volume_usd
        self.min_txns = self.config.min_txns
        self.max_price_impact_pct = self.config.max_price_impact_pct
        self.slippage_bps = self.config.slippage_bps
        self.trailing_stop_pct = self.config.trailing_stop_pct
        self.cooldown_after_loss_min = self.config.cooldown_after_loss_min
        self._last_loss_time = None
        self.max_drawdown_pct = 0.20        # 20% max drawdown from peak equity
        self.peak_equity: Dict[str, float] = dict(self.balances)

        # Push saved filters to the engine (the original only did this
        # after the user pressed SAVE SETTINGS)
        self._push_engine_settings()

        # Restore balances, open positions and trade history
        self.load_portfolio()

        # ---------------- New monitoring features ----------------
        self.connection_status = "unknown"
        self.loading_state = False
        self.performance_metrics = PerformanceMetrics()

        # The streaming poller has no consumer yet; on phones it only
        # burns battery and data, so only run it on desktop.
        if not IS_MOBILE:
            self.engine.data_stream.start_streaming(self._on_stream_data)

        # ---------------- Responsive layout state ----------------
        self.compact = None          # decided on first resize
        self.drawer_open = False

        self.build_ui()

        self._apply_layout_mode(IS_MOBILE or self.width() < COMPACT_BREAKPOINT)

        self.start_scanner()

        # Check network connectivity now and every 60 s
        self._check_connection_status()
        self._conn_timer = QTimer(self)
        self._conn_timer.timeout.connect(self._check_connection_status)
        self._conn_timer.start(60_000)
        self._setup_network_information()

        # Save state when the app is backgrounded (Android/iOS may kill it)
        app = QApplication.instance()
        if app is not None:
            app.applicationStateChanged.connect(self._on_app_state_changed)

        self.update_dashboard()
        self.update_positions()
        self._sync_mode_ui()

    # --------------------------------------------------------
    # Thread helpers
    # --------------------------------------------------------

    def _on_gui_thread(self) -> bool:
        return threading.current_thread() is self._gui_thread

    def ui(self, fn: Callable) -> None:
        """Run `fn` on the GUI thread (immediately if already there)."""
        if self._on_gui_thread():
            fn()
        else:
            self.ui_bridge.invoke.emit(fn)

    def notify(self, title: str, message: str, manual: bool, level: str = "warning") -> None:
        """Log always; pop a dialog only for user-initiated actions."""
        self.log(f"{title}: {message}")
        if not manual:
            return

        def show():
            box = {"critical": QMessageBox.critical,
                   "info": QMessageBox.information}.get(level, QMessageBox.warning)
            box(self, title, message)

        self.ui(show)

    def refresh_views(self) -> None:
        self.ui(self._refresh_views_now)

    def _refresh_views_now(self) -> None:
        self.update_dashboard()
        self.update_positions()
        self.update_history()

    # --------------------------------------------------------
    # Balances (per asset class)
    # --------------------------------------------------------

    @property
    def cash(self) -> float:
        return self.balances.get(self.asset_class, 0.0)

    @cash.setter
    def cash(self, value: float) -> None:
        self.balances[self.asset_class] = value

    @property
    def usd_balance(self) -> float:
        return self.balances.get("FOREX", STARTING_BALANCE_USD)

    def _unit(self, asset_class: Optional[str] = None) -> str:
        return "SOL" if (asset_class or self.asset_class) == "CRYPTO" else "USD"

    def _push_engine_settings(self) -> None:
        self.engine.min_liquidity_usd = self.min_liquidity_usd
        self.engine.min_volume_usd = self.min_volume_usd
        self.engine.min_txns = self.min_txns
        self.engine.max_token_age_hours = self.max_token_age_hours
        self.engine.prioritize_new_memes = self.prioritize_new_memes
        self.engine.alphavantage_api_key = self.config.alphavantage_api_key or "demo"

    # --------------------------------------------------------
    # Persistence
    # --------------------------------------------------------

    def save_portfolio(self) -> None:
        try:
            with self.state_lock:
                positions = {}
                for addr, pos in self.positions.items():
                    p = {k: v for k, v in pos.items() if k not in ("closing", "alerted")}
                    positions[addr] = p
                state = {
                    "version": 2,
                    "balances": self.balances,
                    "positions": positions,
                    "trade_history": self.trade_history[-1000:],
                    "daily_realized_pnl_sol": self.daily_realized_pnl_sol,
                    "daily_reset_date": self.daily_reset_date.isoformat(),
                    "peak_equity": self.peak_equity,
                    "asset_class": self.asset_class,
                }
            tmp = PORTFOLIO_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(state, f, default=str)
            os.replace(tmp, PORTFOLIO_FILE)
        except Exception as e:
            logger.error(f"Failed to save portfolio: {e}")

    def load_portfolio(self) -> None:
        if not os.path.exists(PORTFOLIO_FILE):
            return
        try:
            with open(PORTFOLIO_FILE, "r", encoding="utf-8") as f:
                state = json.load(f)
            for k, v in (state.get("balances") or {}).items():
                if k in self.balances:
                    self.balances[k] = float(v)
            self.positions = {}
            for addr, pos in (state.get("positions") or {}).items():
                if isinstance(pos, dict) and "token" in pos and "cost" in pos:
                    pos.setdefault("asset_class", pos["token"].get("asset_class", "CRYPTO"))
                    self.positions[addr] = pos
            self.trade_history = list(state.get("trade_history") or [])
            saved_date = state.get("daily_reset_date")
            if saved_date == datetime.now().date().isoformat():
                self.daily_realized_pnl_sol = float(state.get("daily_realized_pnl_sol", 0.0))
            for k, v in (state.get("peak_equity") or {}).items():
                if k in self.peak_equity:
                    self.peak_equity[k] = float(v)
            ac = state.get("asset_class")
            if ac in ASSET_CLASSES:
                self.asset_class = ac
                self.engine.set_asset_class(ac)
            logger.info(f"Portfolio restored: {len(self.positions)} open positions")
        except Exception as e:
            logger.error(f"Failed to load portfolio: {e}")

    def _on_app_state_changed(self, state) -> None:
        if state in (Qt.ApplicationSuspended, Qt.ApplicationHidden, Qt.ApplicationInactive):
            self.save_portfolio()
            self.config.save()
            self.rl_agent.save(RL_STATE_FILE)
        if state in (Qt.ApplicationSuspended, Qt.ApplicationHidden):
            self.engine.data_stream.stop_streaming()
        elif state == Qt.ApplicationActive:
            if not IS_MOBILE and not self.engine.data_stream.active_streams.get("main"):
                self.engine.data_stream.start_streaming(self._on_stream_data)
            self._check_connection_status()

    def _fit_to_screen(self, w: int, h: int) -> None:
        screen = QGuiApplication.primaryScreen()
        if screen is not None:
            avail = screen.availableGeometry()
            w = min(w, avail.width())
            h = min(h, avail.height())
        self.resize(w, h)

    def _on_stream_data(self, data: List[Dict]) -> None:
        """Handle real-time streaming data updates."""
        # Process streaming data and update results
        if data and isinstance(data, list):
            logger.debug(f"Received {len(data)} streaming data updates")

    # ========================================================
    # UI
    # ========================================================

    def _setup_network_information(self) -> None:
        if not QTNETWORK_AVAILABLE:
            return
        try:
            if QNetworkInformation.loadDefaultBackend():
                info = QNetworkInformation.instance()
                if info is not None:
                    info.reachabilityChanged.connect(lambda *_: self._check_connection_status())
        except Exception:
            pass

    def _check_connection_status(self) -> None:
        """Check network connectivity (in a thread) and update the label."""
        if getattr(self, "_conn_checking", False):
            return
        self._conn_checking = True
        self.connection_status = "checking"
        if hasattr(self, "connection_label") and not self.connection_label.text().endswith("Connected"):
            self.connection_label.setText("● Checking...")
            self.connection_label.setStyleSheet(f"color:{YELLOW}; font-size:11px;")

        def check():
            connected = check_network_connectivity()

            def apply():
                self._conn_checking = False
                self.connection_status = "connected" if connected else "disconnected"
                if hasattr(self, "connection_label"):
                    if connected:
                        self.connection_label.setText("● Connected")
                        self.connection_label.setStyleSheet(f"color:{GREEN}; font-size:11px;")
                    else:
                        self.connection_label.setText("● Disconnected")
                        self.connection_label.setStyleSheet(f"color:{RED}; font-size:11px;")
                logger.info(f"Network connectivity: {self.connection_status}")

            self.ui(apply)

        threading.Thread(target=check, daemon=True).start()

    def switch_asset_class(self, asset_class: str) -> None:
        """Switch between asset classes (CRYPTO, FOREX, STOCK)."""
        if asset_class == self.asset_class:
            self.asset_buttons[asset_class].setChecked(True)
            return

        if self.live_mode and asset_class != "CRYPTO":
            QMessageBox.information(
                self, "Live Mode",
                "Live trading is only available for Solana crypto. "
                "Switch to PAPER mode to trade forex or stocks (simulated)."
            )
            self.asset_buttons[self.asset_class].setChecked(True)
            return

        current_positions = [a for a, p in self.positions.items()
                             if p.get("asset_class", "CRYPTO") == self.asset_class]

        if current_positions:
            confirm = QMessageBox.warning(
                self,
                "Switch Asset Class",
                f"This will close all current {self.asset_class} positions and switch to {asset_class}. Continue?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )
            if confirm != QMessageBox.Yes:
                self.asset_buttons[self.asset_class].setChecked(True)
                return

        # Close positions of the class we're leaving (each close settles
        # into that position's own asset-class balance)
        for address in current_positions:
            self.close_position(address, manual=False)

        self.asset_class = asset_class
        self.engine.set_asset_class(asset_class)
        self.results = []

        for asset, btn in self.asset_buttons.items():
            btn.setChecked(asset == asset_class)

        asset_name = ASSET_CLASSES[asset_class]["name"]
        self._sync_mode_ui()

        self.start_scanner()
        self.update_dashboard()
        self.update_scanner()
        self.update_listing_watch()

        self.log(f"Switched to {asset_name} trading")
        AuditLogger.log_action("asset_class_switched", {"asset_class": asset_class})
        self.save_portfolio()

    def set_loading_state(self, loading: bool) -> None:
        """Set the loading state for async operations."""
        self.loading_state = loading
        if hasattr(self, "loading_indicator"):
            self.loading_indicator.setVisible(loading)

    def build_ui(self):

        root = QWidget()
        self.root_widget = root

        outer = QVBoxLayout(root)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)

        # ---------------- TOP APP BAR (phones only) ----------------
        # Same colors as the sidebar; hidden on wide screens so the
        # desktop frame is unchanged.
        self.top_bar = QFrame()
        self.top_bar.setObjectName("TopBar")
        self.top_bar.setStyleSheet(
            f"QFrame#TopBar {{ background:{SIDEBAR}; border-bottom:1px solid #1e2833; }}"
        )
        self.top_bar.setFixedHeight(56)
        top_layout = QHBoxLayout(self.top_bar)
        top_layout.setContentsMargins(6, 4, 12, 4)
        top_layout.setSpacing(8)

        self.menu_button = QPushButton("☰")
        self.menu_button.setObjectName("MenuButton")
        self.menu_button.setCursor(Qt.PointingHandCursor)
        self.menu_button.setFixedSize(48, 48)
        self.menu_button.setStyleSheet(
            f"""
            QPushButton#MenuButton {{
                background:transparent; color:{TEXT}; border:none;
                font-size:22px; padding:0px; border-radius:8px;
            }}
            QPushButton#MenuButton:pressed {{ background:{CARD_2}; }}
            """
        )
        self.menu_button.clicked.connect(self.toggle_drawer)
        top_layout.addWidget(self.menu_button)

        self.top_title = QLabel("Dashboard")
        self.top_title.setStyleSheet(f"color:{TEXT}; font-size:17px; font-weight:800;")
        top_layout.addWidget(self.top_title, 1)

        self.top_mode_pill = QLabel("PAPER")
        self.top_mode_pill.setAlignment(Qt.AlignCenter)
        top_layout.addWidget(self.top_mode_pill)

        outer.addWidget(self.top_bar)

        body = QWidget()
        self.body_widget = body
        root_layout = QHBoxLayout(body)
        self.body_layout = root_layout
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)
        outer.addWidget(body, 1)

        # ---------------- SIDEBAR ----------------

        sidebar = QFrame()
        self.sidebar = sidebar

        sidebar.setFixedWidth(220)

        sidebar.setStyleSheet(
            f"background:{SIDEBAR};"
        )

        # The sidebar scrolls on short (landscape phone) screens
        self.sidebar_scroll = QScrollArea()
        self.sidebar_scroll.setWidgetResizable(True)
        self.sidebar_scroll.setFrameShape(QFrame.NoFrame)
        self.sidebar_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.sidebar_scroll.setFixedWidth(220)
        self.sidebar_scroll.setStyleSheet(f"QScrollArea {{ background:{SIDEBAR}; border:none; }}")
        self.sidebar_scroll.setWidget(sidebar)
        sidebar.setMinimumHeight(0)
        _scroll_touch(self.sidebar_scroll)

        side_layout = QVBoxLayout(sidebar)

        side_layout.setContentsMargins(0, 0, 0, 14)

        side_layout.setSpacing(4)

        logo = QLabel("VERTEX TERMINAL")

        logo.setStyleSheet(
            f"""
            color:{TEXT};
            font-size:20px;
            font-weight:800;
            padding:22px 20px 2px 20px;
            """
        )

        side_layout.addWidget(logo)
        self._fit_logo(logo)

        version = QLabel("V5 • SOLANA")

        version.setStyleSheet(
            f"""
            color:{BLUE};
            font-size:11px;
            font-weight:700;
            padding:0px 20px 14px 21px;
            """
        )

        side_layout.addWidget(version)

        divider = QFrame()

        divider.setFixedHeight(1)

        divider.setStyleSheet(
            "background:#1e3a5f; border:none; max-width:1000px;"
        )

        side_layout.addWidget(divider)

        self.nav_buttons = []
        # Exclusive group so exactly one nav item is highlighted
        self.nav_group = QButtonGroup(self)
        self.nav_group.setExclusive(True)

        for text, index in [
            ("⌂  Dashboard", 0),
            ("◈  Scanner", 1),
            ("▣  Portfolio", 2),
            ("◎  Listing Watch", 3),
            ("⚙  Settings", 4),
        ]:

            button = QPushButton(text)

            button.setCheckable(True)

            button.setCursor(Qt.PointingHandCursor)

            button.clicked.connect(
                lambda checked=False, i=index:
                self.navigate(i)
            )

            button.setStyleSheet(
                f"""
                QPushButton {{
                    color:{MUTED};
                    background:transparent;
                    border:none;
                    border-left:3px solid transparent;
                    border-radius:8px;
                    text-align:left;
                    padding:12px 16px;
                    font-size:14px;
                    margin:2px 10px;
                }}

                QPushButton:hover {{
                    background:{CARD};
                    color:{TEXT};
                }}

                QPushButton:checked {{
                    background:{CARD_2};
                    color:{BLUE};
                    font-weight:700;
                    border-left:3px solid {BLUE};
                }}
                """
            )

            self.nav_buttons.append(button)
            self.nav_group.addButton(button, index)

            side_layout.addWidget(button)

        self.nav_buttons[0].setChecked(True)

        side_layout.addStretch()

        self.mode_label = QLabel(
            "●  PAPER MODE"
        )

        self.mode_label.setAlignment(
            Qt.AlignCenter
        )

        self.mode_label.setStyleSheet(
            f"""
            color:{GREEN};
            font-weight:700;
            background:{CARD};
            border:1px solid #1e3a2d;
            border-radius:8px;
            margin:10px 15px 0px 15px;
            padding:10px;
            """
        )

        side_layout.addWidget(self.mode_label)

        self.mode_toggle_button = QPushButton(
            "SWITCH TO LIVE MODE"
        )

        self.mode_toggle_button.setCursor(Qt.PointingHandCursor)

        self.mode_toggle_button.setStyleSheet(
            f"""
            QPushButton {{
                background:{CARD_2};
                color:{RED};
                border:1px solid {RED};
                border-radius:8px;
                margin:10px 15px 15px 15px;
                padding:10px;
                font-weight:700;
            }}

            QPushButton:hover {{
                background:{RED};
                color:white;
            }}
            """
        )

        self.mode_toggle_button.clicked.connect(
            self.on_mode_toggle_clicked
        )

        side_layout.addWidget(self.mode_toggle_button)

        # Asset class selector
        asset_label = QLabel("ASSET CLASS")
        asset_label.setStyleSheet(f"color:{MUTED}; font-size:10px; font-weight:700; padding:0px 20px;")
        side_layout.addWidget(asset_label)

        self.asset_combo = QFrame()
        asset_layout = QVBoxLayout(self.asset_combo)
        asset_layout.setContentsMargins(0, 0, 0, 0)
        asset_layout.setSpacing(2)

        self.asset_buttons = {}
        for asset in ["CRYPTO", "FOREX", "STOCK"]:
            btn = QPushButton(asset)
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            btn.setStyleSheet("""
                QPushButton {
                    color:#8793a1;
                    background:transparent;
                    border:none;
                    border-left:2px solid transparent;
                    text-align:left;
                    padding:8px 20px;
                    font-size:12px;
                }
                QPushButton:hover {
                    background:#151c25;
                    color:#f2f5f7;
                }
                QPushButton:checked {
                    color:#4da3ff;
                    font-weight:700;
                    border-left:2px solid #4da3ff;
                }
            """)
            btn.clicked.connect(lambda checked=False, a=asset: self.switch_asset_class(a))
            if asset == self.asset_class:
                btn.setChecked(True)
            self.asset_buttons[asset] = btn
            asset_layout.addWidget(btn)

        side_layout.addWidget(self.asset_combo)

        # Connection status indicator
        self.connection_label = QLabel("● Checking...")
        self.connection_label.setStyleSheet(f"color:{YELLOW}; font-size:11px;")
        self.connection_label.setAlignment(Qt.AlignCenter)
        side_layout.addWidget(self.connection_label)

        root_layout.addWidget(self.sidebar_scroll)

        # ---------------- PAGES ----------------

        self.pages = QStackedWidget()

        self._page_layouts: List[QBoxLayout] = []
        self._page_titles: List[QLabel] = []
        self._forms: List[QFormLayout] = []
        self._tables: Dict[str, QTableWidget] = {}

        self.dashboard_page = self.create_dashboard()

        self.scanner_page = self.create_scanner_page()

        self.portfolio_page = self.create_portfolio_page()

        self.listing_page = self.create_listing_page()

        self.settings_page = self.create_settings_page()

        self.pages.addWidget(self.dashboard_page)
        self.pages.addWidget(self.scanner_page)
        self.pages.addWidget(self.portfolio_page)
        self.pages.addWidget(self.listing_page)
        self.pages.addWidget(self.settings_page)

        # Keep the nav highlight in sync however the page changes
        self.pages.currentChanged.connect(self._on_page_changed)

        root_layout.addWidget(self.pages, 1)

        # Drawer scrim (phones): tap outside the drawer to close it
        self.scrim = QPushButton(root)
        self.scrim.setObjectName("Scrim")
        self.scrim.setStyleSheet(
            "QPushButton#Scrim { background:rgba(0,0,0,150); border:none; border-radius:0px; }"
            "QPushButton#Scrim:hover { background:rgba(0,0,0,150); }"
        )
        self.scrim.clicked.connect(self.close_drawer)
        self.scrim.hide()

        self.drawer_anim = QPropertyAnimation(self.sidebar_scroll, b"geometry", self)
        self.drawer_anim.setDuration(180)
        self.drawer_anim.setEasingCurve(QEasingCurve.OutCubic)

        self.setCentralWidget(root)

    # --------------------------------------------------------
    # Navigation / responsive layout
    # --------------------------------------------------------

    def navigate(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        if self.compact:
            self.close_drawer()

    def _on_page_changed(self, index: int) -> None:
        if 0 <= index < len(self.nav_buttons):
            self.nav_buttons[index].setChecked(True)
        if hasattr(self, "top_title") and 0 <= index < len(self.PAGE_TITLES):
            title = self.PAGE_TITLES[index]
            if index == 2:
                title = "Portfolio"
            self.top_title.setText(title)

    def _drawer_geometry(self, open_: bool) -> QRect:
        top = self.top_bar.height() if self.top_bar.isVisible() else 0
        h = self.root_widget.height() - top
        w = self.sidebar_scroll.width()
        return QRect(0 if open_ else -w, top, w, h)

    def toggle_drawer(self) -> None:
        if self.drawer_open:
            self.close_drawer()
        else:
            self.open_drawer()

    def open_drawer(self) -> None:
        if not self.compact:
            return
        self.drawer_open = True
        top = self.top_bar.height()
        self.scrim.setGeometry(0, top, self.root_widget.width(), self.root_widget.height() - top)
        self.scrim.show()
        self.scrim.raise_()
        self.sidebar_scroll.show()
        self.sidebar_scroll.raise_()
        self.drawer_anim.stop()
        self.drawer_anim.setStartValue(self._drawer_geometry(False))
        self.drawer_anim.setEndValue(self._drawer_geometry(True))
        self.drawer_anim.start()

    def close_drawer(self) -> None:
        if not self.drawer_open:
            return
        self.drawer_open = False
        self.scrim.hide()
        self.drawer_anim.stop()
        self.drawer_anim.setStartValue(self.sidebar_scroll.geometry())
        self.drawer_anim.setEndValue(self._drawer_geometry(False))
        self.drawer_anim.start()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        compact = IS_MOBILE or self.width() < COMPACT_BREAKPOINT
        if compact != self.compact:
            self._apply_layout_mode(compact)
        elif self.compact:
            if event.oldSize().width() != event.size().width():
                self._wrap_checkboxes()  # rotation
            self.sidebar_scroll.setGeometry(self._drawer_geometry(self.drawer_open))
            if self.drawer_open:
                top = self.top_bar.height()
                self.scrim.setGeometry(0, top, self.root_widget.width(), self.root_widget.height() - top)

    def keyPressEvent(self, event) -> None:
        # Android back button: close drawer -> go to dashboard -> default
        if event.key() in (Qt.Key_Back, Qt.Key_Escape) and self.compact:
            if self.drawer_open:
                self.close_drawer()
                event.accept()
                return
            if self.pages.currentIndex() != 0:
                self.pages.setCurrentIndex(0)
                event.accept()
                return
        super().keyPressEvent(event)

    def _title_css(self, compact: bool) -> str:
        return f"color:{TEXT}; font-size:{22 if compact else 28}px; font-weight:800;"

    def _apply_layout_mode(self, compact: bool) -> None:
        """Switch between the desktop frame and the phone layout.

        Wide screens keep the original layout exactly. Phones get the
        same sidebar as a slide-in drawer, tighter margins, a 2x2 stat
        grid and tables that hide secondary columns.
        """
        if not hasattr(self, "pages"):
            return
        self.compact = compact

        # Sidebar: docked (desktop) vs overlay drawer (phone)
        if compact:
            self.body_layout.removeWidget(self.sidebar_scroll)
            self.sidebar_scroll.setParent(self.root_widget)
            self.sidebar_scroll.setFixedWidth(min(280, max(220, int(self.width() * 0.8))))
            self.sidebar.setFixedWidth(self.sidebar_scroll.width())
            self.top_bar.show()
            self.drawer_open = False
            self.scrim.hide()
            self.sidebar_scroll.setGeometry(self._drawer_geometry(False))
            self.sidebar_scroll.show()
            self.sidebar_scroll.raise_()
        else:
            self.drawer_anim.stop()
            self.drawer_open = False
            self.scrim.hide()
            self.top_bar.hide()
            self.sidebar_scroll.setFixedWidth(220)
            self.sidebar.setFixedWidth(220)
            if self.body_layout.indexOf(self.sidebar_scroll) < 0:
                self.body_layout.insertWidget(0, self.sidebar_scroll)
            self.sidebar_scroll.show()

        m = 14 if compact else 28
        for lay in self._page_layouts:
            lay.setContentsMargins(m, 12 if compact else 28, m, m)
            lay.setSpacing(10 if compact else 14)
        for t in self._page_titles:
            t.setStyleSheet(self._title_css(compact))
            # The top bar already shows the page title on phones
            t.setVisible(not compact)

        # Stat cards: 1x4 row vs 2x2 grid
        cards = [self.balance_card, self.position_card, self.pnl_card, self.candidate_card]
        for c in cards:
            self.stats_grid.removeWidget(c)
        for i, c in enumerate(cards):
            if compact:
                self.stats_grid.addWidget(c, i // 2, i % 2)
            else:
                self.stats_grid.addWidget(c, 0, i)
            c.set_compact(compact)
        self.stats_grid.setSpacing(10 if compact else 14)

        # Tables
        for name, table in self._tables.items():
            hidden = self.COMPACT_HIDDEN_COLUMNS.get(name, [])
            header = table.horizontalHeader()
            for col in range(table.columnCount()):
                table.setColumnHidden(col, compact and col in hidden)
            if compact:
                header.setSectionResizeMode(QHeaderView.ResizeToContents)
                # First visible text column absorbs the remaining width
                first = next(c for c in range(table.columnCount()) if not table.isColumnHidden(c))
                header.setSectionResizeMode(first, QHeaderView.Stretch)
                last = table.columnCount() - 1
                if table.horizontalHeaderItem(last).text() == "Action":
                    header.setSectionResizeMode(last, QHeaderView.Fixed)
                    table.setColumnWidth(last, self.ACTION_COLUMN_WIDTH)
                table.setTextElideMode(Qt.ElideRight)
                table.verticalHeader().setDefaultSectionSize(48)
                table.setMinimumHeight(260)
            else:
                header.setSectionResizeMode(QHeaderView.Stretch)
                table.verticalHeader().setDefaultSectionSize(34 if name == "history" else 40)
                table.setMinimumHeight(0)

        # Forms: labels above fields on phones
        for form in self._forms:
            form.setRowWrapPolicy(QFormLayout.WrapAllRows if compact else QFormLayout.DontWrapRows)

        if hasattr(self, "wallet_buttons_layout"):
            self.wallet_buttons_layout.setDirection(
                QBoxLayout.TopToBottom if compact else QBoxLayout.LeftToRight)

        self.console.setMaximumHeight(140 if compact else 180)
        self.console.setMinimumHeight(110 if compact else 0)
        self.status_label.setMaximumWidth(16777215 if compact else 640)

        # Bigger touch targets on phones
        self.setStyleSheet(
            """
            QPushButton#BuyButton, QPushButton#SellButton, QPushButton#WatchButton { min-height:30px; padding:4px 6px; }
            QPushButton#SaveButton, QPushButton#SaveKeyButton, QPushButton#UnlockButton,
            QPushButton#DeleteKeyButton { min-height:40px; }
            QLineEdit, QSpinBox, QDoubleSpinBox { min-height:30px; }
            QCheckBox::indicator { width:22px; height:22px; }
            """ if compact else ""
        )

        self._wrap_checkboxes()
        self._on_page_changed(self.pages.currentIndex())
        self._sync_mode_ui()

    def _wrap_checkboxes(self) -> None:
        """QCheckBox cannot word-wrap, so on phones break long labels into
        lines that fit the screen (desktop keeps the original one-liners)."""
        for cb in self.findChildren(QCheckBox):
            original = cb.property("_full_text")
            if original is None:
                original = cb.text()
                cb.setProperty("_full_text", original)
            if not getattr(self, "compact", False):
                cb.setText(original)
                continue
            avail = max(160, self.width() - 110)
            fm = QFontMetrics(cb.font())
            lines, cur = [], ""
            for word in original.split():
                trial = f"{cur} {word}".strip()
                if cur and fm.horizontalAdvance(trial) > avail:
                    lines.append(cur)
                    cur = word
                else:
                    cur = trial
            if cur:
                lines.append(cur)
            cb.setText("\n".join(lines))

    def _fit_logo(self, logo: QLabel) -> None:
        """Shrink the logo font if the platform font is wider than Segoe UI
        (Linux/Android fallbacks), so 'VERTEX TERMINAL' never clips."""
        size = 20
        while size > 14:
            f = QFont(logo.font())
            f.setPixelSize(size)
            f.setWeight(QFont.Weight.ExtraBold)
            if QFontMetrics(f).horizontalAdvance(logo.text()) <= 220 - 40:
                break
            size -= 1
        if size != 20:
            logo.setStyleSheet(logo.styleSheet().replace("font-size:20px", f"font-size:{size}px"))

    def _make_page(self, scrollable: bool = True):
        """Page container. Pages scroll vertically on short screens so
        nothing is clipped on phones; on desktop they look identical."""
        page = QScrollArea()
        page.setWidgetResizable(True)
        page.setFrameShape(QFrame.NoFrame)
        page.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        if not scrollable:
            page.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        _scroll_touch(page)
        inner = QWidget()
        page.setWidget(inner)
        layout = QVBoxLayout(inner)
        self._page_layouts.append(layout)
        return page, layout

    def _page_title(self, text: str) -> QLabel:
        title = QLabel(text)
        title.setStyleSheet(self._title_css(False))
        self._page_titles.append(title)
        return title

    # ========================================================
    # DASHBOARD
    # ========================================================

    def create_dashboard(self):

        page, layout = self._make_page()

        layout.setSpacing(14)

        title = self._page_title("Dashboard")

        layout.addWidget(title)

        subtitle = QLabel(
            "Live market scanner • Simulated trading"
        )

        subtitle.setStyleSheet(
            f"color:{MUTED}; font-size:13px;"
        )

        layout.addWidget(subtitle)

        # Stats (1x4 row on desktop, 2x2 grid on phones)
        stats = QGridLayout()
        self.stats_grid = stats

        stats.setSpacing(14)

        self.balance_card = StatCard(
            "WALLET BALANCE",
            f"{STARTING_BALANCE_SOL:.4f} SOL",
            accent=BLUE
        )

        self.position_card = StatCard(
            "OPEN POSITIONS",
            "0",
            accent=PURPLE
        )

        self.pnl_card = StatCard(
            "REALIZED P&L",
            "0.0000 SOL",
            accent=TEXT
        )

        self.candidate_card = StatCard(
            "CANDIDATES",
            "0",
            accent=YELLOW
        )

        stats.addWidget(self.balance_card, 0, 0)
        stats.addWidget(self.position_card, 0, 1)
        stats.addWidget(self.pnl_card, 0, 2)
        stats.addWidget(self.candidate_card, 0, 3)

        layout.addLayout(stats)

        # Candidates
        candidate_title = QLabel(
            "Top Candidates"
        )

        candidate_title.setStyleSheet(
            f"""
            color:{TEXT};
            font-size:18px;
            font-weight:700;
            """
        )

        layout.addWidget(candidate_title)

        self.dashboard_table = self.create_table(
            [
                "Token",
                "Price",
                "Liquidity",
                "Volume",
                "1H",
                "Score",
                "Risk",
            ]
        )

        self._tables["dashboard"] = self.dashboard_table
        self.dashboard_table.cellClicked.connect(
            lambda r, c, n="dashboard": self._on_table_tap(n, r, c)
        )
        layout.addWidget(self.dashboard_table, 1)

        # Console
        console_title = QLabel("Activity")

        console_title.setStyleSheet(
            f"""
            color:{TEXT};
            font-size:16px;
            font-weight:700;
            """
        )

        layout.addWidget(console_title)

        # Loading indicator
        self.loading_indicator = QLabel("Loading...")
        self.loading_indicator.setStyleSheet(f"color:{BLUE}; font-weight:700;")
        self.loading_indicator.setVisible(False)
        layout.addWidget(self.loading_indicator)

        self.console = QTextEdit()

        self.console.setObjectName("Console")

        self.console.setReadOnly(True)

        self.console.setMaximumHeight(180)
        _scroll_touch(self.console)

        layout.addWidget(self.console)

        return page

    # ========================================================
    # SCANNER PAGE
    # ========================================================

    def create_scanner_page(self):

        page, layout = self._make_page()

        layout.setSpacing(14)

        title = self._page_title("Market Scanner")

        layout.addWidget(title)

        self.status_label = QLabel(
            "Waiting for scanner..."
        )

        self.status_label.setWordWrap(True)

        self.status_label.setMaximumWidth(640)

        self.status_label.setStyleSheet(
            f"""
            color:{BLUE};
            background:{CARD};
            border:1px solid #1e2b3d;
            border-radius:8px;
            padding:8px 14px;
            """
        )

        layout.addWidget(self.status_label)

        self.scanner_table = self.create_table(
            [
                "Token",
                "Price",
                "Liquidity",
                "24H Volume",
                "Buys",
                "Sells",
                "1H",
                "24H",
                "Score",
                "Risk",
                "Action",
            ]
        )

        self._tables["scanner"] = self.scanner_table
        self.scanner_table.cellClicked.connect(
            lambda r, c, n="scanner": self._on_table_tap(n, r, c)
        )
        layout.addWidget(self.scanner_table, 1)

        return page

    # ========================================================
    # PORTFOLIO PAGE
    # ========================================================

    def create_portfolio_page(self):

        page, layout = self._make_page()

        layout.setSpacing(14)

        title = self._page_title("Paper Portfolio")

        layout.addWidget(title)

        self.portfolio_table = self.create_table(
            [
                "Token",
                "Entry",
                "Current",
                "Amount",
                "P&L",
                "P&L %",
                "Action",
            ]
        )

        self._tables["portfolio"] = self.portfolio_table
        self.portfolio_table.cellClicked.connect(
            lambda r, c, n="portfolio": self._on_table_tap(n, r, c)
        )
        layout.addWidget(self.portfolio_table, 1)

        history_title = QLabel(
            "Trade History"
        )

        history_title.setStyleSheet(
            f"""
            color:{TEXT};
            font-size:18px;
            font-weight:700;
            """
        )

        layout.addWidget(history_title)

        self.history_table = self.create_table(
            [
                "Time",
                "Side",
                "Token",
                "Price",
                "Amount",
                "P&L",
            ]
        )

        self.history_table.verticalHeader().setDefaultSectionSize(34)

        self._tables["history"] = self.history_table
        self.history_table.cellClicked.connect(
            lambda r, c, n="history": self._on_table_tap(n, r, c)
        )
        layout.addWidget(self.history_table, 1)

        return page

    # ========================================================
    # LISTING WATCH PAGE
    # ========================================================

    def create_listing_page(self):

        page, layout = self._make_page()

        layout.setSpacing(14)

        title = self._page_title("Listing Watch")

        layout.addWidget(title)

        subtitle = QLabel(
            "Tokens showing public momentum/trending signals that "
            "sometimes precede a bigger-exchange listing. Based on "
            "public data only — this is a heuristic, not a guarantee, "
            "and the bot has no access to non-public listing information."
        )

        subtitle.setWordWrap(True)

        subtitle.setStyleSheet(
            f"color:{MUTED}; font-size:13px;"
        )

        layout.addWidget(subtitle)

        self.listing_table = self.create_table(
            [
                "Token",
                "Price",
                "Liquidity",
                "24H Volume",
                "Score",
                "Signals",
                "Action",
            ]
        )

        self._tables["listing"] = self.listing_table
        self.listing_table.cellClicked.connect(
            lambda r, c, n="listing": self._on_table_tap(n, r, c)
        )
        layout.addWidget(self.listing_table, 1)

        return page

    # ========================================================
    # SETTINGS PAGE
    # ========================================================

    def create_settings_page(self):

        page, layout = self._make_page(scrollable=False)

        layout.setSpacing(16)

        title = self._page_title("Settings")

        layout.addWidget(title)

        scroll = QScrollArea()

        scroll.setWidgetResizable(True)

        scroll.setFrameShape(QFrame.NoFrame)

        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        _scroll_touch(scroll)

        content = QWidget()

        content_layout = QVBoxLayout(content)

        content_layout.setContentsMargins(0, 0, 12, 0)

        content_layout.setSpacing(16)

        warning = QLabel(
            "⚠ REAL MONEY IS AT RISK IN LIVE MODE\n\n"
            "This app can execute real on-chain swaps and move real funds "
            "using the wallet key you provide. Memecoin trading is extremely "
            "high risk — most tokens go to zero. Only fund a dedicated hot "
            "wallet with money you can afford to lose. This is not financial "
            "advice, and this app cannot guarantee profit."
        )

        warning.setWordWrap(True)

        warning.setObjectName("WarningBox")

        content_layout.addWidget(warning)

        # ---------------- LIVE TRADING ----------------

        live_card = QFrame()

        live_card.setObjectName("SettingsCard")

        live_layout = QVBoxLayout(live_card)

        live_layout.setContentsMargins(18, 16, 18, 18)

        live_layout.setSpacing(12)

        live_title = QLabel("Live Trading")

        live_title.setObjectName("CardHeader")

        live_layout.addWidget(live_title)

        live_form = QFormLayout()
        self._forms.append(live_form)

        live_form.setSpacing(10)

        live_form.setFieldGrowthPolicy(
            QFormLayout.AllNonFixedFieldsGrow
        )

        self.live_mode_check = QCheckBox(
            "Enable LIVE trading (real funds, real swaps via Jupiter)"
        )
        self.live_mode_check.stateChanged.connect(self.toggle_live_mode)
        live_form.addRow(self.live_mode_check)

        self.auto_trade_check = QCheckBox(
            "Fully autonomous execution (auto-buy qualifying tokens, "
            "auto-sell on TP/SL, no per-trade confirmation)"
        )
        self.auto_trade_check.setChecked(self.auto_trade)
        live_form.addRow(self.auto_trade_check)

        self.private_key_input = QLineEdit()
        self.private_key_input.setEchoMode(QLineEdit.Password)
        self.private_key_input.setPlaceholderText(
            "Pasted here only to encrypt it — never stored in plaintext"
        )
        live_form.addRow(
            "Wallet private key (base58 or JSON array):", self.private_key_input
        )

        self.wallet_password_input = QLineEdit()
        self.wallet_password_input.setEchoMode(QLineEdit.Password)
        live_form.addRow(
            "Encryption password:", self.wallet_password_input
        )

        wallet_buttons = QBoxLayout(QBoxLayout.LeftToRight)
        self.wallet_buttons_layout = wallet_buttons

        wallet_buttons.setSpacing(10)

        save_key_button = QPushButton("SAVE && ENCRYPT KEY")
        save_key_button.setObjectName("SaveKeyButton")
        save_key_button.setCursor(Qt.PointingHandCursor)
        save_key_button.clicked.connect(self.save_wallet_key)
        wallet_buttons.addWidget(save_key_button)

        unlock_button = QPushButton("UNLOCK WALLET")
        unlock_button.setObjectName("UnlockButton")
        unlock_button.setCursor(Qt.PointingHandCursor)
        unlock_button.clicked.connect(self.unlock_wallet)
        wallet_buttons.addWidget(unlock_button)

        clear_key_button = QPushButton("DELETE SAVED KEY")
        clear_key_button.setObjectName("DeleteKeyButton")
        clear_key_button.setCursor(Qt.PointingHandCursor)
        clear_key_button.clicked.connect(self.delete_wallet_key)
        wallet_buttons.addWidget(clear_key_button)

        wallet_buttons.addStretch()

        live_form.addRow(wallet_buttons)

        self.wallet_status_label = QLabel(
            "Wallet: no key saved" if not self.wallet_manager.has_saved_key()
            else "Wallet: key saved (locked)"
        )
        self.wallet_status_label.setStyleSheet(f"color:{MUTED};")
        self.wallet_status_label.setObjectName("WalletStatusLabel")
        live_form.addRow(self.wallet_status_label)

        self.live_size_spin = QDoubleSpinBox()
        self.live_size_spin.setRange(MIN_LIVE_POSITION_SOL, self.max_live_position_sol)
        self.live_size_spin.setSingleStep(0.01)
        self.live_size_spin.setDecimals(3)
        self.live_size_spin.setValue(self.live_position_size_sol)
        live_form.addRow(
            f"Live position size (SOL, min {MIN_LIVE_POSITION_SOL}):",
            self.live_size_spin
        )

        self.max_daily_loss_spin = QDoubleSpinBox()
        self.max_daily_loss_spin.setRange(0.01, 100)
        self.max_daily_loss_spin.setSingleStep(0.05)
        self.max_daily_loss_spin.setDecimals(3)
        self.max_daily_loss_spin.setValue(self.max_daily_loss_sol)
        live_form.addRow(
            "Daily loss limit (SOL) — auto-disables live trading:",
            self.max_daily_loss_spin
        )

        self.payout_input = QLineEdit()
        self.payout_input.setPlaceholderText(
            "Solana address profits are swept to (leave blank to disable)"
        )
        self.payout_input.setText(self.payout_address)
        live_form.addRow(
            "Profit payout wallet address:", self.payout_input
        )

        self.payout_pct_spin = QSpinBox()
        self.payout_pct_spin.setRange(0, 100)
        self.payout_pct_spin.setValue(self.profit_withdraw_pct)
        self.payout_pct_spin.setSuffix(" %")
        live_form.addRow(
            "% of realized profit to sweep:", self.payout_pct_spin
        )

        live_layout.addLayout(live_form)

        dep_note = QLabel(
            "Live trading requires the 'cryptography' package (bundled in the "
            "mobile build). scikit-learn + numpy are optional on desktop."
            + ("" if CRYPTO_AVAILABLE else "  ⚠ cryptography is NOT installed.")
        )
        dep_note.setWordWrap(True)
        dep_note.setObjectName("CardHint")
        live_layout.addWidget(dep_note)

        self.ml_status_label = QLabel(self._ml_status_text())
        self.ml_status_label.setStyleSheet(f"color:{MUTED};")
        self.ml_status_label.setWordWrap(True)
        live_layout.addWidget(self.ml_status_label)

        note = QLabel(
            "Position size above (SOL) is used for both PAPER and LIVE "
            "crypto trades, so paper mode mirrors live mechanics exactly. "
            "Forex/stock paper trades use the USD size under Scanner."
        )
        note.setWordWrap(True)
        note.setObjectName("CardHint")
        live_layout.addWidget(note)

        content_layout.addWidget(live_card)

        # ---------------- SCANNER ----------------

        scanner_card = QFrame()

        scanner_card.setObjectName("SettingsCard")

        scanner_layout = QVBoxLayout(scanner_card)

        scanner_layout.setContentsMargins(18, 16, 18, 18)

        scanner_layout.setSpacing(12)

        scanner_title = QLabel("Scanner")

        scanner_title.setObjectName("CardHeader")

        scanner_layout.addWidget(scanner_title)

        scanner_form = QFormLayout()
        self._forms.append(scanner_form)

        scanner_form.setSpacing(10)

        scanner_form.setFieldGrowthPolicy(
            QFormLayout.AllNonFixedFieldsGrow
        )

        self.score_spin = QSpinBox()

        self.score_spin.setRange(
            0,
            100
        )

        self.score_spin.setValue(
            self.buy_score
        )

        scanner_form.addRow(
            "Minimum buy score:", self.score_spin
        )

        self.interval_spin = QSpinBox()

        self.interval_spin.setRange(
            10,
            3600
        )

        self.interval_spin.setValue(
            self.scan_interval
        )

        self.interval_spin.setSuffix(
            " seconds"
        )

        scanner_form.addRow(
            "Scan interval:", self.interval_spin
        )

        self.usd_size_spin = QDoubleSpinBox()
        self.usd_size_spin.setRange(1.0, 1_000_000.0)
        self.usd_size_spin.setDecimals(2)
        self.usd_size_spin.setSingleStep(10.0)
        self.usd_size_spin.setPrefix("$ ")
        self.usd_size_spin.setValue(self.usd_position_size)
        scanner_form.addRow(
            "Forex/stock paper position size (USD):", self.usd_size_spin
        )

        self.av_key_input = QLineEdit()
        self.av_key_input.setEchoMode(QLineEdit.Password)
        self.av_key_input.setPlaceholderText("Free key from alphavantage.co (default: demo)")
        if self.config.alphavantage_api_key and self.config.alphavantage_api_key != "demo":
            self.av_key_input.setText(self.config.alphavantage_api_key)
        scanner_form.addRow(
            "Alpha Vantage API key (forex/stocks):", self.av_key_input
        )

        self.jup_key_input = QLineEdit()
        self.jup_key_input.setEchoMode(QLineEdit.Password)
        self.jup_key_input.setPlaceholderText("Optional - blank uses the free lite-api.jup.ag")
        self.jup_key_input.setText(self.config.jupiter_api_key)
        scanner_form.addRow(
            "Jupiter API key (optional):", self.jup_key_input
        )

        scanner_layout.addLayout(scanner_form)

        content_layout.addWidget(scanner_card)

        # ============================================================
        # TRADING RULES
        # ============================================================
        rules_card = QFrame()

        rules_card.setObjectName("SettingsCard")

        rules_layout = QVBoxLayout(rules_card)

        rules_layout.setContentsMargins(18, 16, 18, 18)

        rules_layout.setSpacing(12)

        rules_title = QLabel("Trading Rules")

        rules_title.setObjectName("CardHeader")

        rules_layout.addWidget(rules_title)

        rules_form = QFormLayout()
        self._forms.append(rules_form)

        rules_form.setSpacing(10)

        rules_form.setFieldGrowthPolicy(
            QFormLayout.AllNonFixedFieldsGrow
        )

        # Take-profit
        self.tp_spin = QDoubleSpinBox()
        self.tp_spin.setRange(1.0, 1000.0)
        self.tp_spin.setSingleStep(5.0)
        self.tp_spin.setDecimals(1)
        self.tp_spin.setSuffix(" %")
        self.tp_spin.setValue(self.take_profit * 100)
        rules_form.addRow(
            "Take-profit (% gain to auto-sell):", self.tp_spin
        )

        # Stop-loss
        self.sl_spin = QDoubleSpinBox()
        self.sl_spin.setRange(-99.0, 0.0)
        self.sl_spin.setSingleStep(1.0)
        self.sl_spin.setDecimals(1)
        self.sl_spin.setSuffix(" %")
        self.sl_spin.setValue(self.stop_loss * 100)
        rules_form.addRow(
            "Stop-loss (% loss to auto-sell, negative):", self.sl_spin
        )

        # Trailing stop
        self.trail_spin = QDoubleSpinBox()
        self.trail_spin.setRange(0.0, 50.0)
        self.trail_spin.setSingleStep(1.0)
        self.trail_spin.setDecimals(1)
        self.trail_spin.setSuffix(" %")
        self.trail_spin.setValue(self.trailing_stop_pct)
        rules_form.addRow(
            "Trailing stop (0=off, % drop from peak after TP):",
            self.trail_spin
        )

        # Max open positions
        self.max_pos_spin = QSpinBox()
        self.max_pos_spin.setRange(1, 20)
        self.max_pos_spin.setValue(self.max_open_live_positions)
        rules_form.addRow(
            "Max concurrent open positions:", self.max_pos_spin
        )

        # Cooldown after a stop-loss
        self.cooldown_spin = QSpinBox()
        self.cooldown_spin.setRange(0, 1440)
        self.cooldown_spin.setSingleStep(5)
        self.cooldown_spin.setSuffix(" min")
        self.cooldown_spin.setValue(self.cooldown_after_loss_min)
        rules_form.addRow(
            "Pause after a stop-loss (minutes, 0=off):",
            self.cooldown_spin
        )

        rules_layout.addLayout(rules_form)

        content_layout.addWidget(rules_card)

        # ============================================================
        # TOKEN FILTERS
        # ============================================================
        filt_card = QFrame()

        filt_card.setObjectName("SettingsCard")

        filt_layout = QVBoxLayout(filt_card)

        filt_layout.setContentsMargins(18, 16, 18, 18)

        filt_layout.setSpacing(12)

        filt_title = QLabel("Token Filters")

        filt_title.setObjectName("CardHeader")

        filt_layout.addWidget(filt_title)

        filt_form = QFormLayout()
        self._forms.append(filt_form)

        filt_form.setSpacing(10)

        filt_form.setFieldGrowthPolicy(
            QFormLayout.AllNonFixedFieldsGrow
        )

        # Prioritize new memes toggle
        self.prioritize_new_check = QCheckBox(
            "Prioritize newly-launched memes (boost score for fresh tokens)"
        )
        self.prioritize_new_check.setChecked(self.prioritize_new_memes)
        filt_form.addRow(self.prioritize_new_check)

        # Max token age
        self.max_age_spin = QSpinBox()
        self.max_age_spin.setRange(0, 8760)   # up to 1 year
        self.max_age_spin.setSuffix(" h")
        self.max_age_spin.setValue(self.max_token_age_hours)
        filt_form.addRow(
            "Max token age (hours, 0=no limit):", self.max_age_spin
        )

        # Min liquidity
        self.min_liq_spin = QSpinBox()
        self.min_liq_spin.setRange(0, 10_000_000)
        self.min_liq_spin.setSingleStep(5_000)
        self.min_liq_spin.setValue(int(self.min_liquidity_usd))
        self.min_liq_spin.setPrefix("$ ")
        filt_form.addRow("Min liquidity (USD):", self.min_liq_spin)

        # Min volume
        self.min_vol_spin = QSpinBox()
        self.min_vol_spin.setRange(0, 100_000_000)
        self.min_vol_spin.setSingleStep(5_000)
        self.min_vol_spin.setValue(int(self.min_volume_usd))
        self.min_vol_spin.setPrefix("$ ")
        filt_form.addRow("Min 24h volume (USD):", self.min_vol_spin)

        # Min transactions
        self.min_txn_spin = QSpinBox()
        self.min_txn_spin.setRange(0, 100_000)
        self.min_txn_spin.setSingleStep(50)
        self.min_txn_spin.setValue(int(self.min_txns))
        filt_form.addRow("Min 24h transactions:", self.min_txn_spin)

        filt_layout.addLayout(filt_form)

        content_layout.addWidget(filt_card)

        # ============================================================
        # EXECUTION SAFETY
        # ============================================================
        exec_card = QFrame()

        exec_card.setObjectName("SettingsCard")

        exec_layout = QVBoxLayout(exec_card)

        exec_layout.setContentsMargins(18, 16, 18, 18)

        exec_layout.setSpacing(12)

        exec_title = QLabel("Execution Safety")

        exec_title.setObjectName("CardHeader")

        exec_layout.addWidget(exec_title)

        exec_form = QFormLayout()
        self._forms.append(exec_form)

        exec_form.setSpacing(10)

        exec_form.setFieldGrowthPolicy(
            QFormLayout.AllNonFixedFieldsGrow
        )

        # Max price impact
        self.impact_spin = QDoubleSpinBox()
        self.impact_spin.setRange(0.1, 50.0)
        self.impact_spin.setSingleStep(0.5)
        self.impact_spin.setDecimals(2)
        self.impact_spin.setSuffix(" %")
        self.impact_spin.setValue(self.max_price_impact_pct)
        exec_form.addRow(
            "Max Jupiter price impact (refuse above):", self.impact_spin
        )

        # Slippage
        self.slip_spin = QSpinBox()
        self.slip_spin.setRange(10, 5000)
        self.slip_spin.setSingleStep(50)
        self.slip_spin.setSuffix(" bps")
        self.slip_spin.setValue(self.slippage_bps)
        exec_form.addRow("Slippage tolerance (bps):", self.slip_spin)

        exec_layout.addLayout(exec_form)

        content_layout.addWidget(exec_card)

        save_button = QPushButton(
            "SAVE SETTINGS"
        )

        save_button.setObjectName("SaveButton")

        save_button.setCursor(Qt.PointingHandCursor)

        save_button.clicked.connect(
            self.save_settings
        )

        content_layout.addWidget(
            save_button
        )

        content_layout.addStretch()

        scroll.setWidget(content)

        layout.addWidget(scroll)

        return page

    # ========================================================
    # TABLE CREATOR
    # ========================================================

    def create_table(self, headers):

        table = QTableWidget()

        table.setColumnCount(
            len(headers)
        )

        table.setHorizontalHeaderLabels(
            headers
        )

        table.setEditTriggers(
            QTableWidget.NoEditTriggers
        )

        table.setSelectionBehavior(
            QTableWidget.SelectRows
        )

        table.verticalHeader().setVisible(False)

        table.verticalHeader().setDefaultSectionSize(40)

        table.horizontalHeader().setSectionResizeMode(
            QHeaderView.Stretch
        )

        table.horizontalHeader().setHighlightSections(False)

        table.setAlternatingRowColors(True)

        table.setShowGrid(False)

        table.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)

        table.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)

        table.setWordWrap(False)

        _scroll_touch(table)

        return table

    # ========================================================
    # TABLE / CELL PRESENTATION HELPERS
    # ========================================================

    def _cell_item(self, text: str, color: Optional[str] = None, bold: bool = False,
                   align: int = Qt.AlignCenter, tooltip: Optional[str] = None) -> QTableWidgetItem:
        """Create a table cell item with optional styling.

        Args:
            text: Cell text content
            color: Optional text color
            bold: Whether to make text bold
            align: Text alignment (Qt alignment flags)
            tooltip: Optional tooltip text

        Returns:
            Configured QTableWidgetItem
        """
        item = QTableWidgetItem(text)

        item.setTextAlignment(
            align | Qt.AlignVCenter
        )

        if color:
            item.setForeground(
                QBrush(QColor(color))
            )

        if bold:
            font = item.font()
            font.setBold(True)
            item.setFont(font)

        if tooltip:
            item.setToolTip(tooltip)

        return item

    def _token_tooltip(self, token: Dict[str, Any]) -> str:
        """Generate a tooltip string for a token.

        Args:
            token: Dictionary containing token information

        Returns:
            Multi-line tooltip string with key token details
        """
        lines = [
            token.get("name", token["symbol"]),
            f"{token['symbol']} • {token['address']}",
            f"Score {token['score']}/100 • Risk {token['risk']}",
        ]

        if token.get("risk_flags"):
            lines.append("Flags: " + ", ".join(token["risk_flags"]))

        return "\n".join(lines)

    def _action_button(self, text: str, object_name: str, callback: Callable, enabled: bool = True) -> QWidget:
        """Create a button widget wrapped in a container for table cells.

        Args:
            text: Button text
            object_name: Qt object name for styling
            callback: Function to call when button is clicked
            enabled: Whether button is initially enabled

        Returns:
            QWidget container with the button centered
        """
        button = QPushButton(text)

        button.setObjectName(object_name)

        button.setCursor(Qt.PointingHandCursor)

        button.setEnabled(enabled)

        button.clicked.connect(callback)

        container = QWidget()

        row = QHBoxLayout(container)

        row.setContentsMargins(6, 4, 6, 4)

        row.addWidget(button, 0, Qt.AlignCenter)

        return container

    def _score_color(self, score: float) -> str:
        """Get color for a score value.

        Args:
            score: Score value (0-100)

        Returns:
            Color constant (GREEN, YELLOW, or RED)
        """
        if score >= 70:
            return GREEN

        if score >= 50:
            return YELLOW

        return RED

    def _risk_color(self, risk: str) -> str:
        """Get color for a risk level.

        Args:
            risk: Risk level string ("LOWER", "MEDIUM", or "HIGH")

        Returns:
            Color constant (GREEN, YELLOW, or RED)
        """
        if risk == "LOWER":
            return GREEN

        if risk == "MEDIUM":
            return YELLOW

        return RED

    def _pct_color(self, value: float) -> str:
        """Get color for a percentage value.

        Args:
            value: Percentage value (positive, negative, or zero)

        Returns:
            Color constant (GREEN for positive, RED for negative, MUTED for zero)
        """
        if value > 0:
            return GREEN

        if value < 0:
            return RED

        return MUTED

    # ========================================================
    # SCANNER
    # ========================================================

    def start_scanner(self) -> None:
        """Start or restart the market scanner thread."""
        if self.scanner:

            self.scanner.stop()

            # Disconnect so a late result from the old asset class is ignored
            try:
                self.scanner.results_ready.disconnect()
                self.scanner.status.disconnect()
            except Exception:
                pass

            self.scanner.wait(3000)

        self.scanner = ScannerThread(
            self.engine,
            self.scan_interval,
            enricher=self._enrich_results,
        )

        self.scanner.results_ready.connect(
            self.receive_results
        )

        self.scanner.status.connect(
            self.update_status
        )

        self.scanner.start()

    def _enrich_results(self, results: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Runs in the scanner thread: sentiment, ML blend, listing
        signals and SOL pricing - all network/CPU work off the GUI thread."""
        for token in results:
            try:
                self.sentiment_analyzer.add_sentiment_to_token(token)
            except Exception as e:
                logger.error(f"Sentiment analysis failed for {token.get('symbol', 'UNKNOWN')}: {e}")

        if self.ml_scorer.enabled:
            for token in results:
                adjusted, confidence = self.ml_scorer.adjust_score(token, token["score"])
                token["score"] = adjusted
                token["ml_confidence"] = confidence

        try:
            flagged = self.listing_watcher.flag_candidates(results)
            by_addr = {t["address"]: t.get("listing_signals", []) for t in flagged}
            for token in results:
                if token["address"] in by_addr:
                    token["listing_signals"] = by_addr[token["address"]]
        except Exception as e:
            logger.error(f"Listing watch error: {e}")

        if self.engine.asset_class == "CRYPTO":
            sol_usd = self.engine.sol_usd_price()
            self.sol_price_usd = sol_usd
            for token in results:
                token["price_sol"] = self.engine.price_in_sol(token, allow_fetch=False)
        else:
            for token in results:
                token["price_sol"] = 0.0
        return results

    def update_status(self, message: str) -> None:
        """Update the status label and log the message.

        Args:
            message: Status message to display
        """
        self.status_label.setText(
            message
        )

        self.log(message)

    # ========================================================
    # RESULTS
    # ========================================================

    def receive_results(self, results: List[Dict[str, Any]]) -> None:
        """Display scanner results (already enriched in the scanner thread)."""
        # Ignore late results from a previous asset class
        if results and results[0].get("asset_class", self.asset_class) != self.asset_class:
            return

        self.results = results

        self.update_dashboard()

        self.update_scanner()

        self.update_positions()

        self.update_listing_watch()

        self.run_autopilot()

    # ========================================================
    # AUTOPILOT (fully automatic execution)
    # ========================================================

    def _equity(self, asset_class: str) -> float:
        """Cash + mark-to-market value of open paper positions."""
        total = self.balances.get(asset_class, 0.0)
        for address, pos in self.positions.items():
            if pos.get("asset_class", "CRYPTO") != asset_class or pos.get("live"):
                continue
            current = self._current_price(address, pos)
            total += pos.get("qty", 0.0) * current
        return total

    def _disable_auto_trade(self) -> None:
        def apply():
            self.auto_trade = False
            if hasattr(self, "auto_trade_check"):
                self.auto_trade_check.setChecked(False)
        self.ui(apply)

    def run_autopilot(self):

        # Paper mode auto-trades by default (simulated funds, no real risk).
        # Live mode requires the explicit auto-trade toggle AND an unlocked wallet.
        if self.live_mode and not self.auto_trade:
            return

        if self.live_mode and not self.wallet_manager.keypair:
            return

        # Check wallet session validity
        if self.live_mode and not self.wallet_manager.is_session_valid():
            self.log("Wallet session expired. Please unlock again.")
            self.auto_trade = False
            if hasattr(self, "auto_trade_check"):
                self.auto_trade_check.setChecked(False)
            self.set_live_mode(False)
            return

        # Max drawdown protection (paper only). Uses EQUITY - the
        # original compared against cash, so simply buying a token
        # looked like a "drawdown" and halted the bot.
        if not self.live_mode:
            equity = self._equity(self.asset_class)
            peak = max(self.peak_equity.get(self.asset_class, equity), equity)
            self.peak_equity[self.asset_class] = peak
            current_drawdown = (peak - equity) / peak if peak > 0 else 0
            if current_drawdown >= self.max_drawdown_pct:
                if not getattr(self, "_drawdown_logged", False):
                    self.log(
                        f"MAX DRAWDOWN REACHED ({current_drawdown:.1%} below peak equity). "
                        "Paper autopilot paused for safety."
                    )
                    self._drawdown_logged = True
                return
            self._drawdown_logged = False

        # Cooldown after a stop-loss
        if (self.cooldown_after_loss_min > 0
                and self._last_loss_time is not None):
            elapsed_min = (
                (datetime.now() - self._last_loss_time).total_seconds() / 60
            )
            if elapsed_min < self.cooldown_after_loss_min:
                remaining = int(self.cooldown_after_loss_min - elapsed_min) + 1
                self.log(
                    f"Cooldown: waiting {remaining} more min after a "
                    "recent stop-loss before opening new positions."
                )
                return

        self._check_daily_reset()
        if self.asset_class == "CRYPTO" and self.daily_realized_pnl_sol <= -abs(self.max_daily_loss_sol):
            return

        with self.state_lock:
            open_count = len(self.positions) + len(self._pending_buys)

            for token in self.results:

                if open_count >= self.max_open_live_positions:
                    break

                if token["score"] < self.buy_score:
                    continue

                if token["address"] in self.positions or token["address"] in self._pending_buys:
                    continue

                self._pending_buys.add(token["address"])
                open_count += 1
                priority = int(token["score"])
                self.trade_queue.add_trade(dict(token), priority, self._auto_buy_job)

    def _auto_buy_job(self, token: Dict[str, Any]) -> None:
        """Worker thread: RugCheck + RL gate, then buy."""
        address = token["address"]
        try:
            if self.asset_class != token.get("asset_class", "CRYPTO"):
                return
            # ---- RugCheck.xyz gate (crypto only) ----
            if token.get("asset_class", "CRYPTO") == "CRYPTO":
                rug = self.engine.rugcheck_verdict(address)
                if not rug["safe"]:
                    self.log(
                        f"RUG BLOCKED: {token['symbol']} — " + ", ".join(rug["flags"])
                    )
                    for t in self.results:
                        if t["address"] == address:
                            for f in rug["flags"]:
                                if f not in t["risk_flags"]:
                                    t["risk_flags"].append(f)
                    return

            # RL agent decision
            rl_action = self.rl_agent.get_action(token)
            if rl_action == "BUY":
                self._do_buy(token, manual=False)
            elif rl_action == "WAIT":
                self.log(f"RL Agent: WAIT on {token['symbol']}")
            else:
                self.log(f"RL Agent: SKIP {token['symbol']}")
        finally:
            with self.state_lock:
                self._pending_buys.discard(address)

    # ========================================================
    # LISTING WATCH UPDATE
    # ========================================================

    def update_listing_watch(self) -> None:
        """Update the listing watch table (signals computed in the scanner thread)."""
        self.listing_candidates = [t for t in self.results if t.get("listing_signals")]

        table = self.listing_table

        table.setRowCount(len(self.listing_candidates))
        self._row_tokens["listing"] = list(self.listing_candidates)

        for row, token in enumerate(self.listing_candidates):

            tooltip = self._token_tooltip(token)

            items = [
                self._cell_item(
                    token["symbol"], bold=True,
                    align=Qt.AlignLeft, tooltip=tooltip
                ),
                self._cell_item(self.money(token["price"])),
                self._cell_item(self.money(token["liquidity"])),
                self._cell_item(self.money(token["volume"])),
                self._cell_item(
                    str(token["score"]),
                    color=self._score_color(token["score"]),
                    bold=True,
                ),
                self._cell_item(
                    ", ".join(token["listing_signals"]),
                    color=PURPLE,
                ),
            ]

            for col, item in enumerate(items):
                table.setItem(row, col, item)

            buy_button = self._action_button(
                "BUY",
                "BuyButton",
                lambda checked=False, t=token: self.execute_buy(t),
            )

            table.setCellWidget(row, 6, buy_button)

    # ========================================================
    # DASHBOARD UPDATE
    # ========================================================

    def update_dashboard(self) -> None:
        """Update the dashboard with current portfolio and market data."""
        if not hasattr(self, "balance_card"):
            return
        if self.asset_class == "CRYPTO":
            self.balance_card.value.setText(f"{self.cash:.4f} SOL")
        else:
            self.balance_card.value.setText(f"${self.cash:,.2f}")

        self.position_card.value.setText(
            str(len(self.positions))
        )

        # Only sum P&L in the current asset class's unit (SOL vs USD)
        realized = sum(
            trade.get("pnl", 0) or 0
            for trade in self.trade_history
            if trade.get("asset_class", "CRYPTO") == self.asset_class
        )

        if self.asset_class == "CRYPTO":
            self.pnl_card.value.setText(f"{realized:.4f} SOL")
        else:
            self.pnl_card.value.setText(f"${realized:,.2f}")

        if realized > 0:
            self.pnl_card.set_value_color(GREEN)
        elif realized < 0:
            self.pnl_card.set_value_color(RED)
        else:
            self.pnl_card.set_value_color(TEXT)

        self.candidate_card.value.setText(
            str(len(self.results))
        )

        table = self.dashboard_table

        top = self.results[:10]
        self._row_tokens["dashboard"] = list(top)

        table.setRowCount(
            len(top)
        )

        for row, token in enumerate(top):

            tooltip = self._token_tooltip(token)

            items = [
                self._cell_item(
                    token["symbol"], bold=True,
                    align=Qt.AlignLeft, tooltip=tooltip
                ),
                self._cell_item(self.money(token["price"])),
                self._cell_item(self.money(token["liquidity"])),
                self._cell_item(self.money(token["volume"])),
                self._cell_item(
                    f"{token['change_1h']:.2f}%",
                    color=self._pct_color(token["change_1h"]),
                    bold=True,
                ),
                self._cell_item(
                    str(token["score"]),
                    color=self._score_color(token["score"]),
                    bold=True,
                ),
                self._cell_item(
                    token["risk"],
                    color=self._risk_color(token["risk"]),
                    bold=True,
                ),
            ]

            for col, item in enumerate(items):

                table.setItem(
                    row,
                    col,
                    item
                )

    # ========================================================
    # SCANNER UPDATE
    # ========================================================

    def update_scanner(self) -> None:
        """Update the scanner table with current market results."""
        table = self.scanner_table

        top = self.results[:50]
        self._row_tokens["scanner"] = list(top)

        table.setRowCount(
            len(top)
        )

        for row, token in enumerate(top):

            tooltip = self._token_tooltip(token)

            can_buy = token["score"] >= self.buy_score

            items = [
                self._cell_item(
                    token["symbol"], bold=True,
                    align=Qt.AlignLeft, tooltip=tooltip
                ),
                self._cell_item(self.money(token["price"])),
                self._cell_item(self.money(token["liquidity"])),
                self._cell_item(self.money(token["volume"])),
                self._cell_item(
                    str(token["buys"]),
                    color=GREEN,
                ),
                self._cell_item(
                    str(token["sells"]),
                    color=RED,
                ),
                self._cell_item(
                    f"{token['change_1h']:.2f}%",
                    color=self._pct_color(token["change_1h"]),
                    bold=True,
                ),
                self._cell_item(
                    f"{token['change_24h']:.2f}%",
                    color=self._pct_color(token["change_24h"]),
                    bold=True,
                ),
                self._cell_item(
                    str(token["score"]),
                    color=self._score_color(token["score"]),
                    bold=True,
                ),
                self._cell_item(
                    token["risk"],
                    color=self._risk_color(token["risk"]),
                    bold=True,
                ),
            ]

            for col, item in enumerate(items):

                table.setItem(
                    row,
                    col,
                    item
                )

            action_button = self._action_button(
                "BUY" if can_buy else "WATCH",
                "BuyButton" if can_buy else "WatchButton",
                lambda checked=False, t=token: self.execute_buy(t),
                enabled=can_buy,
            )

            table.setCellWidget(row, 10, action_button)

    # ========================================================
    # TAP-FOR-DETAILS (phones show fewer columns)
    # ========================================================

    def _on_table_tap(self, name: str, row: int, col: int) -> None:
        if not self.compact:
            return
        rows = self._row_tokens.get(name) or []
        if not (0 <= row < len(rows)):
            return
        entry = rows[row]
        if name == "portfolio":
            address, pos = entry
            self._show_position_details(address, pos)
        elif name == "history":
            t = entry
            QMessageBox.information(
                self, f"{t.get('symbol', '')} • {t.get('side', '')}",
                f"Time: {t.get('time', '')}\n"
                f"Price: {self.money(t.get('price', 0))}\n"
                f"Amount: {self.money(t.get('amount', 0))} {t.get('unit', self._unit(t.get('asset_class')))}\n"
                f"P&L: {self.money(t.get('pnl', 0))} {t.get('unit', self._unit(t.get('asset_class')))}"
            )
        else:
            self._show_token_details(entry)

    def _show_token_details(self, token: Dict[str, Any]) -> None:
        can_buy = token["score"] >= self.buy_score
        lines = [
            f"{token.get('name', token['symbol'])} ({token['symbol']})",
            f"Price: ${self.money(token['price'])}",
            f"Liquidity: ${self.money(token['liquidity'])}",
            f"24H Volume: ${self.money(token['volume'])}",
            f"Buys / Sells: {token['buys']} / {token['sells']}",
            f"1H: {token['change_1h']:.2f}%   24H: {token['change_24h']:.2f}%",
            f"Score: {token['score']}/100   Risk: {token['risk']}",
        ]
        if token.get("ml_confidence") is not None:
            lines.append(f"Model confidence: {token['ml_confidence']}%")
        if token.get("risk_flags"):
            lines.append("Flags: " + ", ".join(token["risk_flags"]))
        if token.get("listing_signals"):
            lines.append("Signals: " + ", ".join(token["listing_signals"]))
        if token.get("asset_class", "CRYPTO") == "CRYPTO":
            lines.append(f"Address: {token['address']}")

        box = QMessageBox(self)
        box.setWindowTitle(token["symbol"])
        box.setText("\n".join(lines))
        buy_btn = box.addButton("BUY", QMessageBox.AcceptRole) if can_buy else None
        box.addButton("Close", QMessageBox.RejectRole)
        box.exec()
        if buy_btn is not None and box.clickedButton() is buy_btn:
            self.execute_buy(token)

    def _show_position_details(self, address: str, pos: Dict[str, Any]) -> None:
        token = pos["token"]
        unit = self._unit(pos.get("asset_class"))
        current = self._current_price(address, pos)
        value = pos.get("qty", 0) * current
        pnl = value - pos["cost"]
        box = QMessageBox(self)
        box.setWindowTitle(token["symbol"])
        box.setText(
            f"{token.get('name', token['symbol'])} ({'LIVE' if pos.get('live') else 'PAPER'})\n"
            f"Entry: {self.money(pos['entry'])} {unit}\n"
            f"Current: {self.money(current)} {unit}\n"
            f"Quantity: {self.money(pos.get('qty', 0))}\n"
            f"Cost: {self.money(pos['cost'])} {unit}\n"
            f"Value: {self.money(value)} {unit}\n"
            f"P&L: {self.money(pnl)} {unit}"
        )
        sell_btn = box.addButton("SELL", QMessageBox.DestructiveRole)
        box.addButton("Close", QMessageBox.RejectRole)
        box.exec()
        if box.clickedButton() is sell_btn:
            self.close_position(address)

    # ========================================================
    # BUY DISPATCH (paper vs live)
    # ========================================================

    def execute_buy(self, token: Dict[str, Any]) -> None:
        """Manual BUY button (GUI thread): validate + confirm here, then
        hand the network work to the trade worker thread."""
        address = token.get("address", "")
        asset_class = token.get("asset_class", self.asset_class)

        if asset_class != self.asset_class:
            QMessageBox.information(self, "Asset Class Changed",
                                    "This row belongs to a different asset class.")
            return

        if address in self.positions or address in self._pending_buys:
            QMessageBox.information(
                self, "Already Open",
                "You already have a position (or pending order) in this token."
            )
            return

        if token["score"] < self.buy_score:
            QMessageBox.information(
                self, "Score Too Low", f"Token score is {token['score']}."
            )
            return

        if self.live_mode:
            if asset_class != "CRYPTO":
                QMessageBox.information(self, "Live Mode", "Live trading supports Solana crypto only.")
                return
            if not self.wallet_manager.keypair or not self.wallet_manager.is_session_valid():
                QMessageBox.warning(
                    self, "Wallet Locked",
                    "Unlock your wallet in Settings before live trading."
                )
                return
            size_sol = self._live_size_sol()
            if not self.auto_trade:
                confirm = QMessageBox.warning(
                    self,
                    "Confirm LIVE Trade",
                    f"This will swap {size_sol} SOL for {token['symbol']} "
                    f"using REAL funds via Jupiter.\n\nThis cannot be undone. Proceed?",
                    QMessageBox.Yes | QMessageBox.No,
                    QMessageBox.No,
                )
                if confirm != QMessageBox.Yes:
                    return
        elif not self.auto_trade:
            if asset_class == "CRYPTO":
                msg = (f"Simulate swapping about {self._paper_size_sol(token):.4f} SOL for "
                       f"{token['symbol']} using a live Jupiter quote?")
            else:
                msg = (f"Simulate buying about ${self._paper_size_usd():,.2f} of "
                       f"{token['symbol']}?")
            confirm = QMessageBox.question(
                self, "Confirm Paper Trade", msg,
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes,
            )
            if confirm != QMessageBox.Yes:
                return

        with self.state_lock:
            self._pending_buys.add(address)

        def job(t, _addr=address):
            try:
                self._do_buy(t, manual=True)
            finally:
                with self.state_lock:
                    self._pending_buys.discard(_addr)

        self.log(f"Order queued: BUY {token['symbol']}")
        self.trade_queue.add_trade(dict(token), 10_000, job)

    def _do_buy(self, token: Dict[str, Any], manual: bool) -> None:
        """Worker thread: dispatch to the right execution path."""
        asset_class = token.get("asset_class", "CRYPTO")
        if self.live_mode and asset_class == "CRYPTO":
            self.live_buy(token, manual=manual)
        elif asset_class == "CRYPTO":
            self.paper_buy(token, manual=manual)
        else:
            self.paper_buy_usd(token, manual=manual)
        self.save_portfolio()
        self.refresh_views()

    def _live_size_sol(self) -> float:
        # Every trade is clamped between the hard floor and the ceiling
        return max(
            MIN_LIVE_POSITION_SOL,
            min(self.live_position_size_sol, self.max_live_position_sol),
        )

    def _paper_size_sol(self, token: Dict[str, Any]) -> float:
        base_size = self._live_size_sol()
        # Never use more than 20% of the simulated balance per trade
        max_from_balance = self.balances["CRYPTO"] * 0.20
        if max_from_balance > 0:
            base_size = min(base_size, max_from_balance)
        # ML confidence scaling (the original used hasattr() on a dict,
        # which is always False, so this never ran)
        if token.get("ml_confidence"):
            confidence = token["ml_confidence"] / 100.0
            base_size = base_size * (0.5 + confidence)
        return max(MIN_LIVE_POSITION_SOL, min(base_size, self.max_live_position_sol))

    def _paper_size_usd(self) -> float:
        size = self.usd_position_size
        cash = self.balances.get(self.asset_class, 0.0)
        return max(1.0, min(size, cash * 0.20)) if cash > 0 else size

    def _daily_limit_hit(self) -> bool:
        self._check_daily_reset()
        return self.daily_realized_pnl_sol <= -abs(self.max_daily_loss_sol)

    def _resolve_decimals(self, mint: str, raw_out: int = 0, expected_ui: float = 0.0) -> int:
        """Token decimals: on-chain (getTokenSupply), else inferred from a
        quote vs. the DexScreener price, else 6 (pump.fun default)."""
        try:
            return self.live_trader.get_token_decimals(mint)
        except Exception:
            pass
        if raw_out > 0 and expected_ui > 0:
            try:
                dec = int(round(math.log10(raw_out / expected_ui)))
                if 0 <= dec <= 12:
                    return dec
            except Exception:
                pass
        return 6

    # ========================================================
    # LIVE BUY (real money, Jupiter swap)
    # ========================================================

    def live_buy(self, token: Dict[str, Any], manual: bool = False) -> None:
        """Execute a live buy (worker thread). Records the position only
        after the transaction is confirmed on-chain."""
        address = token["address"]
        symbol = token.get("symbol", "UNKNOWN")

        if not validate_solana_address(address):
            self.notify("Live Buy Failed", f"{symbol}: invalid token address", manual)
            return

        if not self.live_mode:
            return

        if self._daily_limit_hit():
            self.log(
                "AUTOPILOT HALTED: daily loss limit reached. "
                "Live trading disabled — re-enable manually in Settings."
            )
            self._disable_auto_trade()
            self.ui(lambda: self.set_live_mode(False))
            return

        with self.state_lock:
            if address in self.positions:
                self.notify("Already Open", "You already have a live position in this token.", manual, "info")
                return
            if not manual and len(self.positions) >= self.max_open_live_positions:
                return

        if not self.wallet_manager.keypair or not self.wallet_manager.is_session_valid():
            self.notify("Wallet Locked", "Unlock your wallet in Settings before live trading.", manual)
            return

        size_sol = self._live_size_sol()

        # Balance check: never spend the fee reserve.
        try:
            balance = self.live_trader.get_sol_balance()
        except Exception as e:
            self.notify("Live Buy Failed", f"Could not check wallet balance: {e}", manual)
            return

        if balance < size_sol + FEE_RESERVE_SOL:
            self.notify(
                "Insufficient Balance",
                f"SKIPPED {symbol}: balance {balance:.4f} SOL too low "
                f"for a {size_sol} SOL trade + {FEE_RESERVE_SOL} SOL fee reserve.",
                manual,
            )
            return

        try:
            lamports = int(size_sol * LAMPORTS_PER_SOL)

            # Fresh quote (never cached) so we can veto bad price impact
            quote = self.live_trader.get_quote(
                SOL_MINT, address, lamports, self.slippage_bps, use_cache=False
            )

            impact = abs(float(quote.get("priceImpactPct", 0) or 0)) * 100

            if impact > self.max_price_impact_pct:
                self.notify(
                    "Trade Skipped",
                    f"{symbol}: price impact {impact:.1f}% exceeds the "
                    f"{self.max_price_impact_pct}% safety limit.",
                    manual, "info",
                )
                return

            try:
                pre_raw, _ = self.live_trader.get_token_balance(address)
            except Exception:
                pre_raw = 0

            swap_tx = self.live_trader.build_swap_transaction(quote)
            signature = self.live_trader.sign_and_send(swap_tx)
            self.log(f"LIVE BUY {symbol}: tx sent {signature[:12]}..., waiting for confirmation")

            confirmed = self.live_trader.confirm_transaction(signature, timeout_s=45)

            # Actual received amount from the chain (can differ from the quote)
            raw_amount = 0
            decimals = -1
            for _ in range(5):
                try:
                    post_raw, decimals = self.live_trader.get_token_balance(address)
                    raw_amount = post_raw - pre_raw
                    if raw_amount > 0:
                        break
                except Exception:
                    pass
                time.sleep(1.5)

            if not confirmed and raw_amount <= 0:
                self.notify(
                    "Live Buy Unconfirmed",
                    f"{symbol}: transaction {signature} was not confirmed within 45 s and no "
                    "tokens arrived. Check a block explorer before retrying.",
                    manual,
                )
                return

            if raw_amount <= 0:
                raw_amount = int(quote.get("outAmount", 0) or 0)
            if decimals is None or decimals < 0:
                decimals = self._resolve_decimals(
                    address, raw_amount,
                    size_sol / token["price_sol"] if token.get("price_sol") else 0)

            qty = raw_amount / (10 ** decimals)
            entry_price = (size_sol / qty) if qty > 0 else token.get("price_sol", 0)

            with self.state_lock:
                self.positions[address] = {
                    "token": token,
                    "asset_class": "CRYPTO",
                    "entry": entry_price,          # SOL per token
                    "qty": qty,                    # UI units
                    "raw_amount": int(raw_amount), # smallest units
                    "decimals": int(decimals),
                    "cost": size_sol,              # SOL
                    "live": True,
                    "entry_time": time.time(),
                    "signature": signature,
                }

                self.trade_history.append({
                    "time": datetime.now().strftime("%H:%M:%S"),
                    "side": "BUY (LIVE)",
                    "symbol": symbol,
                    "price": entry_price,
                    "amount": size_sol,
                    "pnl": 0,
                    "asset_class": "CRYPTO",
                    "unit": "SOL",
                    "tx": signature,
                })

            self.log(
                f"LIVE BUY {symbol} • {size_sol} SOL • {self.money(qty)} tokens • tx {signature[:12]}..."
            )
            AuditLogger.log_action("live_buy", {"symbol": symbol, "sol": size_sol, "tx": signature})

        except Exception as e:
            self.notify("Trade Failed", f"LIVE BUY FAILED for {symbol}: {e}", manual, "critical")
            return

    # ========================================================
    # PAPER BUY (crypto, SOL-denominated)
    # ========================================================

    def paper_buy(self, token: Dict[str, Any], manual: bool = False) -> None:
        """Simulated buy priced with a real Jupiter quote (worker thread)."""
        address = token["address"]
        symbol = token.get("symbol", "UNKNOWN")

        if not validate_solana_address(address):
            self.notify("Paper Buy Failed", f"{symbol}: invalid token address", manual)
            return

        if self._daily_limit_hit():
            self.log(
                "AUTOPILOT PAUSED (paper): daily loss limit reached. "
                "Re-enable auto-trading manually in Settings."
            )
            return

        with self.state_lock:
            if address in self.positions:
                self.notify("Already Open", "You already have a position in this token.", manual, "info")
                return
            if not manual and len(self.positions) >= self.max_open_live_positions:
                return

        size_sol = self._paper_size_sol(token)

        # Same balance + fee-reserve check as live, against the
        # simulated SOL wallet instead of an on-chain one.
        if self.balances["CRYPTO"] < size_sol + FEE_RESERVE_SOL:
            self.notify(
                "Insufficient Simulated Balance",
                f"Simulated balance {self.balances['CRYPTO']:.4f} SOL is too low for a "
                f"{size_sol:.4f} SOL trade + {FEE_RESERVE_SOL} SOL fee reserve.",
                manual,
            )
            return

        lamports = int(size_sol * LAMPORTS_PER_SOL)
        price_sol = token.get("price_sol") or self.engine.price_in_sol(token)

        # Real quote so the simulated fill (price + impact) matches live
        quote = None
        try:
            quote = self.live_trader.get_quote(
                SOL_MINT, address, lamports, self.slippage_bps
            )
        except Exception:
            quote = None

        if quote and int(quote.get("outAmount", 0) or 0) > 0:
            impact = abs(float(quote.get("priceImpactPct", 0) or 0)) * 100

            if impact > self.max_price_impact_pct:
                self.notify(
                    "Paper Trade Skipped",
                    f"{symbol}: price impact {impact:.1f}% exceeds the "
                    f"{self.max_price_impact_pct}% safety limit.",
                    manual, "info",
                )
                return

            raw_amount = int(quote["outAmount"])
            decimals = self._resolve_decimals(
                address, raw_amount, size_sol / price_sol if price_sol > 0 else 0)
            qty = raw_amount / (10 ** decimals)
            source = "live-quote pricing"
        else:
            # No network / no route - fall back to the DexScreener price
            if price_sol <= 0:
                self.notify("Paper Buy Failed", f"{symbol}: no price available", manual)
                return
            decimals = self._resolve_decimals(address)
            qty = size_sol / price_sol
            raw_amount = int(qty * (10 ** decimals))
            source = "DexScreener price fallback"

        if qty <= 0:
            self.notify("Paper Buy Failed", f"{symbol}: invalid amount", manual)
            return

        entry_price = size_sol / qty  # SOL per token

        with self.state_lock:
            if address in self.positions:
                return
            self.balances["CRYPTO"] -= size_sol

            self.positions[address] = {
                "token": token,
                "asset_class": "CRYPTO",
                "entry": entry_price,
                "qty": qty,
                "raw_amount": raw_amount,
                "decimals": decimals,
                "cost": size_sol,
                "live": False,
                "entry_time": time.time(),
            }

            self.trade_history.append({
                "time": datetime.now().strftime("%H:%M:%S"),
                "side": "BUY (PAPER)",
                "symbol": symbol,
                "price": entry_price,
                "amount": size_sol,
                "pnl": 0,
                "asset_class": "CRYPTO",
                "unit": "SOL",
            })

        self.log(
            f"PAPER BUY {symbol} • {size_sol:.4f} SOL (simulated, {source})"
        )

    # ========================================================
    # PAPER BUY (forex / stocks, USD-denominated)
    # ========================================================

    def paper_buy_usd(self, token: Dict[str, Any], manual: bool = False) -> None:
        address = token["address"]
        symbol = token.get("symbol", "UNKNOWN")
        asset_class = token.get("asset_class", self.asset_class)
        price = float(token.get("price", 0) or 0)
        if price <= 0:
            self.notify("Paper Buy Failed", f"{symbol}: no price available", manual)
            return

        with self.state_lock:
            if address in self.positions:
                self.notify("Already Open", "You already have a position in this symbol.", manual, "info")
                return
            if not manual and len(self.positions) >= self.max_open_live_positions:
                return
            size = self._paper_size_usd()
            if self.balances[asset_class] < size:
                self.notify("Insufficient Simulated Balance",
                            f"Simulated balance ${self.balances[asset_class]:,.2f} is too low "
                            f"for a ${size:,.2f} trade.", manual)
                return
            qty = size / price
            self.balances[asset_class] -= size
            self.positions[address] = {
                "token": token,
                "asset_class": asset_class,
                "entry": price,
                "qty": qty,
                "cost": size,
                "live": False,
                "entry_time": time.time(),
            }
            self.trade_history.append({
                "time": datetime.now().strftime("%H:%M:%S"),
                "side": "BUY (PAPER)",
                "symbol": symbol,
                "price": price,
                "amount": size,
                "pnl": 0,
                "asset_class": asset_class,
                "unit": "USD",
            })
        self.log(f"PAPER BUY {symbol} • ${size:,.2f} @ {self.money(price)} (simulated)")

    # ========================================================
    # SELL DISPATCH (paper vs live) + ML feedback
    # ========================================================

    def close_position(self, address: str, manual: bool = True) -> None:
        """Queue a close (GUI thread). The swap/quote runs in the worker."""
        with self.state_lock:
            position = self.positions.get(address)
            if not position or position.get("closing"):
                return
            position["closing"] = True
        self.log(f"Order queued: SELL {position['token'].get('symbol', '')}")
        self.trade_queue.add_trade({"address": address, "symbol": position["token"].get("symbol", "")},
                                   100_000, lambda _t, a=address, m=manual: self._do_close(a, m))
        self.refresh_views()

    def _do_close(self, address: str, manual: bool) -> None:
        """Worker thread: close a position and record the outcome."""
        position = self.positions.get(address)
        if not position:
            return
        token = position["token"]

        try:
            if position.get("live"):
                pnl = self._live_close(address, manual)
            elif position.get("asset_class", "CRYPTO") == "CRYPTO":
                pnl = self._paper_close(address)
            else:
                pnl = self._paper_close_usd(address)
        except Exception as e:
            pnl = None
            self.notify("Sell Failed", f"{token.get('symbol', '')}: {e}", manual, "critical")

        if pnl is None:
            with self.state_lock:
                if address in self.positions:
                    self.positions[address]["closing"] = False
            self.refresh_views()
            return

        # Track stop-loss time so the autopilot can enforce the cooldown.
        if pnl < 0:
            self._last_loss_time = datetime.now()

        # Feed the outcome back into the adaptive model.
        self.ml_scorer.record_outcome(token, won=(pnl > 0))

        # Update RL agent with reward (P&L as a fraction of cost, hold in minutes)
        entry_time = position.get("entry_time", time.time())
        hold_min = (time.time() - entry_time) / 60
        pnl_frac = pnl / position["cost"] if position.get("cost") else 0
        reward = self.rl_agent.calculate_reward(pnl_frac, hold_min)
        self.rl_agent.update_q_value(token, "BUY", reward)
        self.rl_agent.decay_epsilon()
        self.rl_agent.save(RL_STATE_FILE)

        AuditLogger.log_action("position_closed", {
            "address": address[:8] + "...",
            "symbol": token.get("symbol", "UNKNOWN"),
            "pnl": pnl,
            "unit": self._unit(position.get("asset_class")),
            "is_live": position.get("live", False),
            "rl_reward": reward
        })

        self.save_portfolio()

        def after():
            self.ml_status_label.setText(self._ml_status_text())
            self._refresh_views_now()

        self.ui(after)

    def _record_sell(self, address: str, position: Dict[str, Any], proceeds: float,
                     pnl: float, side: str, unit: str, tx: str = "") -> None:
        token = position["token"]
        qty = position.get("qty", 0)
        with self.state_lock:
            self.trade_history.append({
                "time": datetime.now().strftime("%H:%M:%S"),
                "side": side,
                "symbol": token["symbol"],
                "price": proceeds / qty if qty else 0,
                "amount": proceeds,
                "pnl": pnl,
                "asset_class": position.get("asset_class", "CRYPTO"),
                "unit": unit,
                **({"tx": tx} if tx else {}),
            })
            self.positions.pop(address, None)

    def _after_crypto_close(self, pnl_sol: float, live: bool) -> None:
        self._check_daily_reset()
        self.daily_realized_pnl_sol += pnl_sol
        if self.daily_realized_pnl_sol <= -abs(self.max_daily_loss_sol):
            self.log(
                f"DAILY LOSS LIMIT HIT ({self.daily_realized_pnl_sol:.4f} SOL"
                f"{'' if live else ', paper'}). Disabling auto-trading — re-enable manually when ready."
            )
            self._disable_auto_trade()
            if live:
                self.ui(lambda: self.set_live_mode(False))

    def _paper_close(self, address: str) -> Optional[float]:
        """Close a paper crypto position. Returns P&L in SOL."""
        position = self.positions[address]
        token = position["token"]
        qty = position.get("qty", 0)
        raw_amount = int(position.get("raw_amount") or 0)

        # Same exit path as live: a real Jupiter quote for the reverse
        # swap, in the token's smallest units (the original mixed UI
        # amounts and raw units here).
        proceeds_sol = None
        if raw_amount > 0:
            try:
                quote = self.live_trader.get_quote(address, SOL_MINT, raw_amount, self.slippage_bps)
                out = int(quote.get("outAmount", 0) or 0)
                if out > 0:
                    proceeds_sol = out / LAMPORTS_PER_SOL
            except Exception:
                proceeds_sol = None

        if proceeds_sol is None:
            current_price = self._current_price(address, position)
            proceeds_sol = qty * current_price
            self.log(
                f"PAPER {token['symbol']}: live quote unavailable on exit, "
                f"using DexScreener price as a fallback."
            )

        pnl = proceeds_sol - position["cost"]

        with self.state_lock:
            self.balances["CRYPTO"] += proceeds_sol
        self._record_sell(address, position, proceeds_sol, pnl, "SELL (PAPER)", "SOL")

        self.log(
            f"PAPER SELL {token['symbol']} • {proceeds_sol:.4f} SOL | P&L {pnl:+.4f} SOL"
        )

        self._after_crypto_close(pnl, live=False)

        if pnl > 0 and self.payout_address and self.profit_withdraw_pct > 0:
            swept = pnl * (self.profit_withdraw_pct / 100)
            self.log(
                f"PAPER PROFIT SWEEP (simulated): {swept:.4f} SOL -> {self.payout_address[:6]}..."
            )

        return pnl

    def _paper_close_usd(self, address: str) -> Optional[float]:
        position = self.positions[address]
        token = position["token"]
        asset_class = position.get("asset_class", "FOREX")
        current = self._current_price(address, position)
        proceeds = position["qty"] * current
        pnl = proceeds - position["cost"]
        with self.state_lock:
            self.balances[asset_class] += proceeds
        self._record_sell(address, position, proceeds, pnl, "SELL (PAPER)", "USD")
        self.log(f"PAPER SELL {token['symbol']} • ${proceeds:,.2f} | P&L ${pnl:+,.2f}")
        return pnl

    # ========================================================
    # LIVE SELL (real money, Jupiter swap back to SOL) + auto profit sweep
    # ========================================================

    def _live_close(self, address: str, manual: bool = False) -> Optional[float]:
        """Sell the tokens actually held on-chain back to SOL. Returns P&L in SOL."""
        position = self.positions[address]
        token = position["token"]

        if not self.wallet_manager.keypair or not self.wallet_manager.is_session_valid():
            self.notify("Wallet Locked", f"Unlock the wallet to sell {token['symbol']}.", manual)
            return None

        try:
            # Use the real on-chain balance: what arrived can be less than
            # the quote, and the original guessed 6 decimals.
            onchain_raw, decimals = self.live_trader.get_token_balance(address)
            if onchain_raw <= 0:
                raise RuntimeError("no tokens of this mint found in the wallet")
            raw_amount = onchain_raw
            signature, quote = self.live_trader.swap(
                address, SOL_MINT, raw_amount, self.slippage_bps
            )
        except Exception as e:
            self.notify("Sell Failed", f"LIVE SELL FAILED for {token['symbol']}: {e}", manual, "critical")
            return None

        proceeds_sol = int(quote.get("outAmount", 0) or 0) / LAMPORTS_PER_SOL
        pnl_sol = proceeds_sol - position["cost"]

        self._record_sell(address, position, proceeds_sol, pnl_sol, "SELL (LIVE)", "SOL", signature)

        self.log(
            f"LIVE SELL {token['symbol']} • ~{proceeds_sol:.4f} SOL "
            f"| P&L {pnl_sol:+.4f} SOL • tx {signature[:12]}..."
        )

        self._after_crypto_close(pnl_sol, live=True)

        if pnl_sol > 0 and self.payout_address and self.profit_withdraw_pct > 0:
            self._withdraw_profit(pnl_sol)

        return pnl_sol

    def _check_daily_reset(self) -> None:
        """Reset daily P&L tracking when the date changes."""
        today = datetime.now().date()
        if today != self.daily_reset_date:
            self.daily_reset_date = today
            self.daily_realized_pnl_sol = 0.0
            logger.info("Daily P&L tracking reset for new day")

    def _withdraw_profit(self, pnl_sol: float) -> None:
        """Sweep a percentage of profit to the payout wallet (worker thread)."""
        amount = pnl_sol * (self.profit_withdraw_pct / 100)

        # Below ~0.001 SOL a transfer to a new account fails (rent minimum)
        # and the fee eats a large share of the amount.
        if amount < 0.001:
            self.log(f"PROFIT SWEEP skipped: {amount:.6f} SOL is below the 0.001 SOL minimum.")
            return

        try:
            signature = self.live_trader.send_sol(
                self.payout_address, amount
            )
            self.log(
                f"PROFIT SWEEP: {amount:.4f} SOL -> {self.payout_address[:6]}... "
                f"• tx {signature[:12]}..."
            )
        except Exception as e:
            self.log(f"PROFIT SWEEP FAILED: {e}")

    # ========================================================
    # CURRENT PRICE
    # ========================================================

    def find_current_price(self, address: str) -> float:
        """Latest USD price of a token from the scan results (0 if absent)."""
        for token in self.results:

            if token["address"] == address:

                return token["price"]

        return 0

    def _current_price(self, address: str, position: Dict[str, Any]) -> float:
        """Current price in the position's own unit (SOL for crypto, USD otherwise)."""
        latest = None
        for token in self.results:
            if token["address"] == address:
                latest = token
                break
        if position.get("asset_class", "CRYPTO") == "CRYPTO":
            if latest is not None:
                p = latest.get("price_sol") or self.engine.price_in_sol(latest, allow_fetch=False)
                if p > 0:
                    position["last_price"] = p
                    return p
            return position.get("last_price") or position["entry"]
        if latest is not None and latest.get("price", 0) > 0:
            position["last_price"] = latest["price"]
            return latest["price"]
        return position.get("last_price") or position["entry"]

    # ========================================================
    # POSITION UPDATE
    # ========================================================

    def update_positions(self) -> None:
        """Refresh the portfolio table and trigger TP / SL / trailing exits."""
        table = self.portfolio_table

        with self.state_lock:
            items_list = list(self.positions.items())

        table.setRowCount(len(items_list))
        self._row_tokens["portfolio"] = items_list

        pending_closes = []

        for row, (address, position) in enumerate(items_list):

            token = position["token"]

            current = self._current_price(address, position)

            entry = position["entry"]

            quantity = position.get("qty", 0)

            value = quantity * current

            pnl = value - position["cost"]

            pnl_percent = (
                (current - entry) / entry * 100
            ) if entry and entry > 0 else 0

            # Trailing-stop bookkeeping: track the highest price seen.
            peak_price = position.get("peak", entry)
            if current > peak_price:
                peak_price = current
                position["peak"] = peak_price

            peak_pnl_percent = (
                (peak_price - entry) / entry * 100
            ) if entry and entry > 0 else 0
            drawdown_from_peak = (
                (peak_price - current) / peak_price * 100
            ) if peak_price and peak_price > 0 else 0

            unit = self._unit(position.get("asset_class"))
            symbol_text = token["symbol"] + (" ●" if position.get("live") else "")
            if position.get("closing"):
                symbol_text += " …"

            items = [
                self._cell_item(
                    symbol_text, bold=True,
                    align=Qt.AlignLeft,
                    tooltip=self._token_tooltip(token),
                    color=RED if position.get("live") else None,
                ),
                self._cell_item(self.money(entry)),
                self._cell_item(self.money(current)),
                self._cell_item(f"{self.money(value)} {unit}"),
                self._cell_item(
                    self.money(pnl),
                    color=self._pct_color(pnl),
                    bold=True,
                ),
                self._cell_item(
                    f"{pnl_percent:.2f}%",
                    color=self._pct_color(pnl_percent),
                    bold=True,
                ),
            ]

            for col, item in enumerate(items):

                table.setItem(
                    row,
                    col,
                    item
                )

            sell_button = self._action_button(
                "SELL",
                "SellButton",
                lambda checked=False,
                a=address:
                self.close_position(a),
                enabled=not position.get("closing"),
            )

            table.setCellWidget(
                row,
                6,
                sell_button
            )

            if position.get("closing"):
                continue

            # Auto risk management. When a trailing stop is configured the
            # TP level ARMS the trail instead of selling outright (the
            # original sold at TP first, so the trail could never fire).
            hit_sl = pnl_percent <= self.stop_loss * 100
            hit_tp = False
            hit_trail = False
            if self.trailing_stop_pct > 0:
                if peak_pnl_percent >= self.take_profit * 100:
                    hit_trail = drawdown_from_peak >= self.trailing_stop_pct
            else:
                hit_tp = pnl_percent >= self.take_profit * 100

            if hit_tp or hit_sl or hit_trail:

                if hit_sl:
                    label = "STOP LOSS"
                elif hit_trail:
                    label = "TRAILING STOP"
                else:
                    label = "TAKE PROFIT"

                is_live = position.get("live")

                if (not is_live) or self.auto_trade:
                    self.log(f"{label} reached: {token['symbol']}")
                    pending_closes.append(address)
                elif position.get("alerted") != label:
                    # Live without autopilot: alert once, user sells manually
                    position["alerted"] = label
                    self.log(f"{label} reached: {token['symbol']} (live — tap SELL to exit)")

        for address in pending_closes:
            self.close_position(address, manual=False)

        self.update_history()

    # ========================================================
    # HISTORY
    # ========================================================

    def update_history(self) -> None:
        """Update the trade history table with all completed trades."""
        table = self.history_table

        with self.state_lock:
            history = list(reversed(self.trade_history[-500:]))

        table.setRowCount(
            len(history)
        )
        self._row_tokens["history"] = history

        for row, trade in enumerate(history):

            side_color = (
                GREEN if trade["side"].startswith("BUY") else RED
            )
            unit = trade.get("unit") or self._unit(trade.get("asset_class"))

            items = [
                self._cell_item(
                    trade["time"], color=MUTED
                ),
                self._cell_item(
                    trade["side"],
                    color=side_color,
                    bold=True,
                ),
                self._cell_item(
                    trade["symbol"], bold=True
                ),
                self._cell_item(self.money(trade["price"])),
                self._cell_item(f"{self.money(trade['amount'])} {unit}"),
                self._cell_item(
                    self.money(trade["pnl"]),
                    color=self._pct_color(trade["pnl"]),
                    bold=True,
                ),
            ]

            for col, item in enumerate(items):

                table.setItem(
                    row,
                    col,
                    item
                )

    # ========================================================
    # SETTINGS
    # ========================================================

    def save_settings(self):

        if not hasattr(self, "score_spin") or not hasattr(self, "interval_spin"):
            self.log("Settings not available yet.")
            return

        payout = self.payout_input.text().strip()
        if payout and not validate_solana_address(payout):
            QMessageBox.warning(self, "Invalid Payout Address",
                                "The profit payout address is not a valid Solana address.")
            return
        if payout and self.wallet_manager.pubkey() == payout:
            QMessageBox.warning(self, "Invalid Payout Address",
                                "The payout address must be different from the trading wallet.")
            return

        old_interval = self.scan_interval
        old_filters = (self.min_liquidity_usd, self.min_volume_usd, self.min_txns,
                       self.max_token_age_hours, self.prioritize_new_memes,
                       self.config.alphavantage_api_key)

        self.buy_score = self.score_spin.value()
        self.scan_interval = self.interval_spin.value()

        self.live_position_size_sol = max(MIN_LIVE_POSITION_SOL, self.live_size_spin.value())
        self.payout_address = payout
        self.profit_withdraw_pct = self.payout_pct_spin.value()
        self.auto_trade = self.auto_trade_check.isChecked()
        self.max_daily_loss_sol = self.max_daily_loss_spin.value()
        self.usd_position_size = self.usd_size_spin.value()

        # ----- Trading rules -----
        self.take_profit = self.tp_spin.value() / 100.0
        self.stop_loss = self.sl_spin.value() / 100.0
        self.trailing_stop_pct = self.trail_spin.value()
        self.max_open_live_positions = self.max_pos_spin.value()
        self.cooldown_after_loss_min = self.cooldown_spin.value()

        # ----- Token filters -----
        self.prioritize_new_memes = self.prioritize_new_check.isChecked()
        self.max_token_age_hours = self.max_age_spin.value()
        self.min_liquidity_usd = self.min_liq_spin.value()
        self.min_volume_usd = self.min_vol_spin.value()
        self.min_txns = self.min_txn_spin.value()

        # ----- Execution safety -----
        self.max_price_impact_pct = self.impact_spin.value()
        self.slippage_bps = self.slip_spin.value()

        # ----- API keys -----
        self.config.alphavantage_api_key = self.av_key_input.text().strip() or "demo"
        self.config.jupiter_api_key = self.jup_key_input.text().strip()
        self.live_trader.jupiter_api_key = self.config.jupiter_api_key

        self._push_engine_settings()

        # Update and save configuration
        c = self.config
        c.buy_score = self.buy_score
        c.scan_interval = self.scan_interval
        c.live_position_size_sol = self.live_position_size_sol
        c.payout_address = self.payout_address
        c.profit_withdraw_pct = self.profit_withdraw_pct
        c.auto_trade = self.auto_trade
        c.max_daily_loss_sol = self.max_daily_loss_sol
        c.take_profit = self.take_profit
        c.stop_loss = self.stop_loss
        c.trailing_stop_pct = self.trailing_stop_pct
        c.max_open_live_positions = self.max_open_live_positions
        c.cooldown_after_loss_min = self.cooldown_after_loss_min
        c.prioritize_new_memes = self.prioritize_new_memes
        c.max_token_age_hours = self.max_token_age_hours
        c.min_liquidity_usd = self.min_liquidity_usd
        c.min_volume_usd = self.min_volume_usd
        c.min_txns = self.min_txns
        c.max_price_impact_pct = self.max_price_impact_pct
        c.slippage_bps = self.slippage_bps
        c.usd_position_size = self.usd_position_size

        if c.save():
            self.log("Settings saved to configuration file.")
            AuditLogger.log_action("settings_saved", {
                "buy_score": self.buy_score,
                "auto_trade": self.auto_trade,
                "live_mode": self.live_mode
            })
        else:
            self.log("Warning: Failed to save settings to file.")

        new_filters = (self.min_liquidity_usd, self.min_volume_usd, self.min_txns,
                       self.max_token_age_hours, self.prioritize_new_memes,
                       self.config.alphavantage_api_key)
        if self.scanner and self.scan_interval == old_interval:
            self.scanner.interval = self.scan_interval
            if new_filters != old_filters:
                self.scanner.scan_now()
        else:
            self.start_scanner()

        self.update_scanner()

        if self.compact:
            QMessageBox.information(self, "Settings", "Settings saved.")

    # ========================================================
    # LIVE MODE / WALLET CONTROLS
    # ========================================================

    def toggle_live_mode(self, state: int) -> None:
        """Toggle live mode from checkbox in Settings."""
        self.set_live_mode(bool(state))

    def on_mode_toggle_clicked(self) -> None:
        """Toggle live mode from sidebar button."""
        if self.compact:
            self.close_drawer()
        self.set_live_mode(not self.live_mode)

    def set_live_mode(self, enable: bool) -> None:
        """Enable or disable live trading mode."""
        if enable == self.live_mode:
            self._sync_mode_ui()
            return

        if enable:

            if not CRYPTO_AVAILABLE:
                QMessageBox.critical(
                    self, "Missing Dependencies",
                    "Install: pip install cryptography"
                )
                self._sync_mode_ui()
                return

            if self.asset_class != "CRYPTO":
                QMessageBox.information(
                    self, "Live Mode",
                    "Live trading is only available for Solana crypto. "
                    "Switch the asset class to CRYPTO first."
                )
                self._sync_mode_ui()
                return

            if not self.wallet_manager.keypair:
                QMessageBox.warning(
                    self, "Wallet Locked",
                    "Unlock your wallet with its password before enabling live mode."
                )
                self._sync_mode_ui()
                return

            if not self.wallet_manager.is_session_valid():
                QMessageBox.warning(
                    self, "Session Expired",
                    "Wallet session has expired. Please unlock again."
                )
                self._sync_mode_ui()
                return

            confirm = QMessageBox.warning(
                self,
                "Enable LIVE Trading",
                "You are about to enable trading with REAL funds. "
                "This bot will be able to spend from the unlocked wallet.\n\n"
                "Are you sure?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No,
            )

            if confirm != QMessageBox.Yes:
                self._sync_mode_ui()
                return

            self.live_mode = True
            self.log("LIVE MODE ENABLED — trading with real funds.")
            AuditLogger.log_action("live_mode_enabled", {})

        else:
            self.live_mode = False
            self.log("Live mode disabled. Back to paper trading.")
            AuditLogger.log_action("live_mode_disabled", {})

        self._sync_mode_ui()

    def _sync_mode_ui(self) -> None:
        """Synchronize window title, sidebar label/button, top-bar pill
        and the Settings checkbox with the current trading mode."""
        if not hasattr(self, "mode_label"):
            return

        asset_name = ASSET_CLASSES[self.asset_class]["name"]

        if self.live_mode:
            self.setWindowTitle("Vertex Terminal • LIVE TRADING")

            self.mode_label.setText("●  LIVE MODE")
            self.mode_label.setStyleSheet(
                f"""
                color:{RED};
                font-weight:700;
                background:{CARD};
                border:1px solid #4a1f27;
                border-radius:8px;
                margin:10px 15px 0px 15px;
                padding:10px;
                """
            )

            if hasattr(self, "mode_toggle_button"):
                self.mode_toggle_button.setText("SWITCH TO PAPER MODE")

        else:
            self.setWindowTitle(f"Vertex Terminal • {asset_name} • Paper Trading")

            self.mode_label.setText("●  PAPER MODE")
            self.mode_label.setStyleSheet(
                f"""
                color:{GREEN};
                font-weight:700;
                background:{CARD};
                border:1px solid #1e3a2d;
                border-radius:8px;
                margin:10px 15px 0px 15px;
                padding:10px;
                """
            )

            if hasattr(self, "mode_toggle_button"):
                self.mode_toggle_button.setText("SWITCH TO LIVE MODE")

        if hasattr(self, "top_mode_pill"):
            color, border = (RED, "#4a1f27") if self.live_mode else (GREEN, "#1e3a2d")
            self.top_mode_pill.setText("● LIVE" if self.live_mode else "● PAPER")
            self.top_mode_pill.setStyleSheet(
                f"color:{color}; font-weight:700; font-size:12px; background:{CARD};"
                f" border:1px solid {border}; border-radius:12px; padding:5px 10px;"
            )

        if hasattr(self, "live_mode_check"):
            self.live_mode_check.blockSignals(True)
            self.live_mode_check.setChecked(self.live_mode)
            self.live_mode_check.blockSignals(False)

    def save_wallet_key(self):

        key = self.private_key_input.text().strip()
        password = self.wallet_password_input.text()

        if not key or not password:
            QMessageBox.warning(
                self, "Missing Info",
                "Enter both the private key and an encryption password."
            )
            return

        is_strong, message = validate_password_strength(password)
        if not is_strong:
            QMessageBox.warning(
                self, "Weak Password",
                f"{message}\n\nPlease use a stronger password for wallet security."
            )
            return

        try:
            pubkey = self.wallet_manager.save_private_key(key, password)

            self.private_key_input.clear()
            self.wallet_password_input.clear()

            self.wallet_status_label.setText(
                f"Wallet: key saved (encrypted, locked) — {pubkey[:6]}...{pubkey[-6:]}"
            )

            self.log(f"Wallet key saved and encrypted locally ({pubkey[:6]}...).")
            AuditLogger.log_action("wallet_key_saved", {"pubkey": pubkey[:6] + "..."})

        except Exception as e:
            logger.error(f"Failed to save wallet key: {e}")
            QMessageBox.critical(self, "Save Failed", str(e))

    def unlock_wallet(self) -> None:
        """Unlock the wallet using the encryption password (PBKDF2 runs in a thread)."""
        password = self.wallet_password_input.text()

        if not password:
            QMessageBox.warning(
                self, "Missing Password", "Enter the encryption password."
            )
            return

        self.wallet_status_label.setText("Wallet: unlocking...")

        def work():
            try:
                pubkey = self.wallet_manager.unlock(password)
            except Exception as e:
                err = str(e) or e.__class__.__name__
                logger.error(f"Failed to unlock wallet: {err}")

                def fail():
                    self.wallet_status_label.setText("Wallet: key saved (locked)")
                    QMessageBox.critical(self, "Unlock Failed", err)

                self.ui(fail)
                return

            def ok():
                self.wallet_password_input.clear()
                self.wallet_status_label.setText(
                    f"Wallet: unlocked — {pubkey[:6]}...{pubkey[-6:]}"
                )
                self.log(f"Wallet unlocked: {pubkey}")

            self.ui(ok)

        threading.Thread(target=work, daemon=True).start()

    def delete_wallet_key(self) -> None:
        """Delete the saved encrypted wallet key from disk."""
        confirm = QMessageBox.warning(
            self, "Delete Saved Key",
            "This permanently deletes the locally saved encrypted key. Continue?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )

        if confirm == QMessageBox.Yes:
            if self.live_mode:
                self.set_live_mode(False)
            self.wallet_manager.clear()
            self.wallet_status_label.setText("Wallet: no key saved")
            self.log("Saved wallet key deleted.")
            AuditLogger.log_action("wallet_key_deleted", {})

    def _ml_status_text(self) -> str:
        """Status text for the adaptive model."""
        return (
            f"Adaptive model ({self.ml_scorer.backend}): {self.ml_scorer.samples_seen} "
            f"closed trades learned from (rules-only until "
            f"{AdvancedMLScorer.MIN_SAMPLES_TO_PREDICT} trades, then blends in gradually)"
        )

    # ========================================================
    # LOG
    # ========================================================

    def log(self, message: str) -> None:
        """Log to the logger and the on-screen console (thread-safe)."""
        logger.info(message)

        timestamp = datetime.now().strftime("%H:%M:%S")
        line = f"[{timestamp}] {message}"

        def append():
            if hasattr(self, "console"):
                self.console.append(line)
                doc = self.console.document()
                # Keep the console bounded on long sessions
                if doc.blockCount() > 1000:
                    cursor = self.console.textCursor()
                    cursor.movePosition(cursor.MoveOperation.Start)
                    cursor.movePosition(cursor.MoveOperation.Down, cursor.MoveMode.KeepAnchor, 200)
                    cursor.removeSelectedText()

        self.ui(append)

    # ========================================================
    # MONEY
    # ========================================================

    @staticmethod
    def money(value: float) -> str:
        """Format a value with sensible precision, including micro-cap
        prices like 0.000000012 (the original printed 0.00000001)."""
        try:

            value = float(value)

            if value == 0:
                return "0.00"

            a = abs(value)

            if a < 1e-9:
                return f"{value:.2e}"

            if a < 1:
                # 4 significant digits
                decimals = min(12, max(2, 3 - int(math.floor(math.log10(a)))))
                return f"{value:.{decimals}f}"

            return f"{value:,.2f}"

        except Exception:

            return "0.00"

    # ========================================================
    # CLOSE
    # ========================================================

    def closeEvent(self, event) -> None:
        """Stop threads and persist everything before quitting."""
        if self.scanner:
            self.scanner.stop()
            self.scanner.wait(3000)

        self.engine.data_stream.stop_streaming()

        if hasattr(self, "trade_queue"):
            self.trade_queue.stop_worker()

        self.save_portfolio()
        self.config.save()

        if hasattr(self, "rl_agent"):
            self.rl_agent.save(RL_STATE_FILE)

        if hasattr(self, "ml_scorer"):
            self.ml_scorer._save()

        logger.info("Application closing")
        event.accept()

    def get_ml_statistics(self) -> Dict[str, Any]:
        """Get comprehensive ML and RL statistics for display."""
        stats = {
            "ml_scorer": self.ml_scorer.get_statistics(),
            "rl_agent": self.rl_agent.get_statistics(),
            "performance": self.performance_metrics.get_stats("trade_success") or {},
        }
        return stats


# ============================================================
# DARK THEME
# ============================================================

def apply_theme(app):

    app.setStyleSheet(
        f"""
        QWidget {{
            background:{BG};
            color:{TEXT};
            font-size:13px;
        }}

        QLabel {{
            background:transparent;
        }}

        QToolTip {{
            background:{CARD_2};
            color:{TEXT};
            border:1px solid #293441;
            border-radius:4px;
            padding:6px 8px;
        }}

        QFrame#StatCard {{
            background:{CARD};
            border:1px solid #1e2833;
            border-radius:12px;
        }}

        QFrame#SettingsCard {{
            background:{CARD};
            border:1px solid #1e2833;
            border-radius:12px;
        }}

        QLabel#CardHeader {{
            color:{TEXT};
            font-size:15px;
            font-weight:700;
            background:transparent;
        }}

        QLabel#CardHint {{
            color:{MUTED};
            font-size:11px;
            background:transparent;
        }}

        QLabel#WarningBox {{
            color:{YELLOW};
            background:#211b0d;
            border:1px solid #514626;
            border-radius:10px;
            padding:18px;
        }}

        QTableWidget {{
            background:{CARD};
            alternate-background-color:#121924;
            border:1px solid #1e2833;
            border-radius:12px;
            gridline-color:transparent;
            selection-background-color:#1d2b3d;
            selection-color:{TEXT};
        }}

        QTableWidget::item {{
            padding:4px 8px;
        }}

        QHeaderView::section {{
            background:{CARD_2};
            color:{MUTED};
            padding:10px 8px;
            border:none;
            border-right:1px solid #1e2833;
            border-bottom:1px solid #293441;
            font-weight:700;
            font-size:12px;
        }}

        QPushButton {{
            background:{BLUE};
            color:white;
            border:none;
            border-radius:8px;
            padding:9px 16px;
            font-weight:700;
        }}

        QPushButton:hover {{
            background:#6bb4ff;
        }}

        QPushButton:pressed {{
            background:#3d88d1;
        }}

        QPushButton:disabled {{
            background:#232d3a;
            color:#5c6b7d;
        }}

        QPushButton#BuyButton {{
            background:{GREEN};
            color:#06281a;
        }}

        QPushButton#BuyButton:hover {{
            background:#4ee0aa;
        }}

        QPushButton#BuyButton:disabled {{
            background:#1e3a2d;
            color:#4c7c63;
        }}

        QPushButton#SellButton {{
            background:{RED};
            color:white;
        }}

        QPushButton#SellButton:hover {{
            background:#ff7889;
        }}

        QPushButton#WatchButton {{
            background:transparent;
            color:{MUTED};
            border:1px solid #293441;
        }}

        QPushButton#WatchButton:hover {{
            color:{TEXT};
            border-color:#3a4a5d;
        }}

        QPushButton#SaveButton {{
            background:{GREEN};
            color:#06281a;
            padding:12px;
            font-size:14px;
        }}

        QPushButton#SaveButton:hover {{
            background:#4ee0aa;
        }}

        QPushButton#SaveKeyButton {{
            background:{BLUE};
            color:white;
        }}

        QPushButton#UnlockButton {{
            background:{GREEN};
            color:#06281a;
        }}

        QPushButton#UnlockButton:hover {{
            background:#4ee0aa;
        }}

        QPushButton#DeleteKeyButton {{
            background:transparent;
            color:{RED};
            border:1px solid {RED};
        }}

        QPushButton#DeleteKeyButton:hover {{
            background:{RED};
            color:white;
        }}

        QSpinBox,
        QDoubleSpinBox {{
            background:{BG};
            border:1px solid #293441;
            border-radius:8px;
            padding:7px 10px;
            color:{TEXT};
            font-weight:600;
        }}

        QSpinBox:focus,
        QDoubleSpinBox:focus {{
            border-color:{BLUE};
        }}

        QSpinBox::up-button,
        QDoubleSpinBox::up-button {{
            background:transparent;
            border:none;
            width:22px;
        }}

        QSpinBox::down-button,
        QDoubleSpinBox::down-button {{
            background:transparent;
            border:none;
            width:22px;
        }}

        QSpinBox::up-arrow,
        QDoubleSpinBox::up-arrow {{
            border-left:4px solid transparent;
            border-right:4px solid transparent;
            border-bottom:5px solid {MUTED};
            width:0;
            height:0;
        }}

        QSpinBox::down-arrow,
        QDoubleSpinBox::down-arrow {{
            border-left:4px solid transparent;
            border-right:4px solid transparent;
            border-top:5px solid {MUTED};
            width:0;
            height:0;
        }}

        QLineEdit {{
            background:{BG};
            border:1px solid #293441;
            border-radius:8px;
            padding:9px 12px;
            color:{TEXT};
            selection-background-color:{BLUE};
        }}

        QLineEdit:focus {{
            border-color:{BLUE};
        }}

        QCheckBox {{
            background:transparent;
            spacing:10px;
        }}

        QCheckBox::indicator {{
            width:18px;
            height:18px;
            border-radius:5px;
            border:1px solid #33414f;
            background:{BG};
        }}

        QCheckBox::indicator:hover {{
            border-color:{BLUE};
        }}

        QCheckBox::indicator:checked {{
            background:{BLUE};
            border-color:{BLUE};
        }}

        QTextEdit {{
            background:#0a0e13;
            border:1px solid #1e2833;
            border-radius:10px;
            color:{MUTED};
            padding:10px 14px;
            font-family:Consolas, Courier New, monospace;
            font-size:12px;
        }}

        QScrollArea {{
            background:transparent;
            border:none;
        }}

        QScrollArea > QWidget > QWidget {{
            background:transparent;
        }}

        QScrollBar:vertical {{
            background:transparent;
            width:10px;
            margin:0;
        }}

        QScrollBar::handle:vertical {{
            background:#2a3644;
            border-radius:5px;
            min-height:30px;
        }}

        QScrollBar::handle:vertical:hover {{
            background:#3a4a5d;
        }}

        QScrollBar:horizontal {{
            background:transparent;
            height:10px;
            margin:0;
        }}

        QScrollBar::handle:horizontal {{
            background:#2a3644;
            border-radius:5px;
            min-width:30px;
        }}

        QScrollBar::handle:horizontal:hover {{
            background:#3a4a5d;
        }}

        QScrollBar::add-line,
        QScrollBar::sub-line {{
            height:0;
            width:0;
        }}

        QScrollBar::add-page,
        QScrollBar::sub-page {{
            background:transparent;
        }}

        QMessageBox {{
            background:{CARD};
        }}

        QMessageBox QLabel {{
            color:{TEXT};
            background:transparent;
            font-size:13px;
        }}

        QProgressBar {{
            background:{CARD};
            border:none;
            border-radius:5px;
        }}

        QProgressBar::chunk {{
            background:{GREEN};
            border-radius:5px;
        }}
        """
    )


# ============================================================
# MAIN
# ============================================================

def main():

    # Crisp scaling on high-DPI phone screens
    try:
        QGuiApplication.setHighDpiScaleFactorRoundingPolicy(
            Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    except Exception:
        pass

    app = QApplication(sys.argv)
    app.setApplicationName("Vertex Terminal")
    app.setOrganizationName("Vertex")

    # "Segoe UI" only exists on Windows - fall back to each platform's UI font
    font = QFont()
    font.setFamilies(["Segoe UI", "Roboto", "Helvetica Neue", "Arial"])
    app.setFont(font)

    # Set application icon (next to main.py, not the working directory)
    here = os.path.dirname(os.path.abspath(__file__))
    for name in ("app_icon.png", "app_icon.ico"):
        icon_path = os.path.join(here, name)
        if os.path.exists(icon_path):
            app.setWindowIcon(QIcon(icon_path))
            break

    apply_theme(app)

    global _MAIN_WINDOW_UP
    window = MainWindow()

    if IS_MOBILE:
        window.showMaximized()
    else:
        window.show()
    _MAIN_WINDOW_UP = True

    # Errors in background threads go to the same reporter.
    import threading as _th
    _th.excepthook = lambda a: _crash_hook(a.exc_type, a.exc_value, a.exc_traceback)

    if _PREVIOUS_NATIVE_CRASH:
        QTimer.singleShot(800, lambda: _show_crash_text(
            "Vertex Terminal - previous crash",
            "The app closed unexpectedly last time:\n\n" + _PREVIOUS_NATIVE_CRASH,
            fatal=False))

    sys.exit(
        app.exec()
    )


if __name__ == "__main__":
    main()


# ============================================================
# REQUIREMENTS
# ------------------------------------------------------------
# Desktop:  pip install PySide6 requests cryptography
# Optional: pip install numpy scikit-learn   (bigger ML ensemble)
#
# The app runs in PAPER mode with only PySide6 + requests.
# LIVE mode and wallet encryption need `cryptography`.
# Android / iOS: see README.md (pyside6-android-deploy / -ios-deploy).
# ============================================================
